package com.einfochips.AdapterDesignPattern;

public class AndroidCharger {
    public void charge(AndroidPhone androidPhone) {
        androidPhone.charge();
    }
}
