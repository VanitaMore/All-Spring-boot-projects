package com.einfochips.AdapterDesignPattern;

public interface AndroidPhone {
    void charge();
}
