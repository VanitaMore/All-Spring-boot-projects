package com.einfochips.AdapterDesignPattern;

public interface IPhone {
    void charge();
}
