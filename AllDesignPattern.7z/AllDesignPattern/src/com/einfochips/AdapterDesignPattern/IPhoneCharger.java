package com.einfochips.AdapterDesignPattern;

public class IPhoneCharger {

    public void charge(IPhone iPhone){
        iPhone.charge();
    }
}
