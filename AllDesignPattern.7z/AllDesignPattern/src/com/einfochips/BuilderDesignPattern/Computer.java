package com.einfochips.BuilderDesignPattern;

public class Computer {
	private int id;
	private String name;
	private String addr;

	

	private int salary;
	private int pincode;

	private Computer(Builder builder) {
		this.id=builder.id;
		this.name=builder.name;
		this.addr=builder.addr;
		this.salary=builder.salary;
		this.pincode=builder.pincode;
	}

	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public String getAddr() {
		return addr;
	}

	public int getSalary() {
		return salary;
	}

	public int getPincode() {
		return pincode;
	}
	@Override
	public String toString() {
		return "Computer [id=" + id + ", name=" + name + ", addr=" + addr + ", salary=" + salary + ", pincode="
				+ pincode + "]";
	}
	
	public static class Builder {
		private int id;
		private String name;
		private String addr;

		private int salary;
		private int pincode;

		public Builder(int id, String name, String addr) {
			this.id = id;
			this.name = name;
			this.addr = addr;
		}

		public Builder setSalary(int salary) {
			this.salary = salary;
			return this;
		}

		public Builder setPincode(int pincode) {
			this.pincode = pincode;
			return this;
		}

		public Computer build() {
			return new Computer(this);
		}
		
		
	}


}
