package com.einfochips.BuilderDesignPattern;

public class ComputerClient {

	public static void main(String[] args) {
		Computer com=new Computer.Builder(2, "vanita", "pune").build();
        System.out.println(com);
        Computer com1=new Computer.Builder(2, "vanita", "pune").setPincode(5).build();
        System.out.println(com1);
	}

}
