package com.einfochips.FactoryDesignpattern;

public interface Mobile {
	public static final String IPHONE="IPHONE";
	public static final String SONY="sony";
	public static final String SAMSUNG="samsung";
}
