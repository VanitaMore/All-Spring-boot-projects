package com.einfochips.PrototypeDesignPattern;

import java.util.List;

public class PrototypePatternExample {

	public static void main(String[] args) throws CloneNotSupportedException {

		Vehicle a = new Vehicle();
		a.insertData();
		//System.out.println("original list"+a);

		Vehicle b = (Vehicle) a.clone();
		List<String> newList = b.getVehicleList();
		newList.add("Honda new Amaze");
		//System.out.println("clone list"+newList);
		
		b.getVehicleList().remove("BMW");
	    System.out.println(newList);
	    System.out.println(a.getVehicleList());
		
		
	}

}
