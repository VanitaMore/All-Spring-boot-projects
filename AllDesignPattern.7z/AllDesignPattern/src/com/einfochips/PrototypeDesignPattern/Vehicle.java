package com.einfochips.PrototypeDesignPattern;

import java.util.ArrayList;
import java.util.List;

public class Vehicle implements Cloneable{
	
	private List<String> vehicleList;

	public Vehicle() {
		this.vehicleList=new ArrayList<String>();
	}

	public Vehicle(List<String> list) {
		super();
		this.vehicleList = list;
	}
	
	public void insertData() {
		vehicleList.add("honda");
		vehicleList.add("audi");
		vehicleList.add("maruti");
		vehicleList.add("innova");
		vehicleList.add("BMW");
		vehicleList.add("mercy");
	}

	public List<String> getVehicleList() {
		return vehicleList;
	}
	@Override
	public Object clone() throws CloneNotSupportedException {
		List<String> tempList=new ArrayList<String>();
		for(String s:this.getVehicleList()) {
			tempList.add(s);
		}
		return new Vehicle(tempList);
	}

	@Override
	public String toString() {
		return "Vehicle [vehicleList=" + vehicleList + "]";
	}
	

}
