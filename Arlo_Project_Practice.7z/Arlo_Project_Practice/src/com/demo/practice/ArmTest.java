package com.demo.practice;

public class ArmTest {

	public static void main(String[] args) {
		/*int num=163;
		int t1=num;
		int len=0;
		
		while(t1!=0) {
			t1=t1/10;
			len=len+1;
		}
		
		int t2=num,arm=0;
		int rem;
		while(t2!=0) {
			rem=t2%10;
			int mul=1;
			for(int i=1;i<=len;i++) {
				mul=mul*rem;
			}
			arm=arm+mul;
			t2=t2/10;
		}
		if(num==arm) {
			System.out.println("num is armstrong");
		}else {
			System.out.println("num isnot armstrong");
		}
	}*/

		
		int a[]= {2,3,4,5,6};
		for(int i=0;i<a.length;i++) {
			System.out.println(a[10]);
		}
	}
}
