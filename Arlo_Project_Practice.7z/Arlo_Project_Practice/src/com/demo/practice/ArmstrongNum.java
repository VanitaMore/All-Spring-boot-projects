package com.demo.practice;

public class ArmstrongNum {

	public static void main(String[] args) {
		int num=157;
		int t1=num;
		int len=0;
		
		while(t1!=0) {
			t1=t1/10;
			len=len+1;
		}
		
		int t2=num;
		int rem;
		int arm=0;
		while(t2!=0) {
			int mul=1;
			rem=t2%10;
			
			for(int i=1;i<=len;i++) {
				mul=mul*rem;
			}
			arm=arm+mul;
			t2=t2/10;
		}
		if(num==arm) {
			System.out.println("num is armstrong");
		}else {
			System.out.println("num isnot armstrong");
		}
	}

}
