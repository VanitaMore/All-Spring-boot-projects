package com.demo.practice;

import java.util.ArrayList;

public class Array {

	public static void main(String[] args) {
		ArrayList<String> list = new ArrayList<String>();
		list.add("john");
		list.add("ram");
		list.add("sham");
		list.add("Adam");
		list.add("grey");
		list.forEach(a->System.out.println(a));
		
	}

}
