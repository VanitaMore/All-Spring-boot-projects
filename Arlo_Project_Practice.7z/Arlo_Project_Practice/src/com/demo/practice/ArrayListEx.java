package com.demo.practice;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

public class ArrayListEx {

	public static void main(String[] args) {
		/*
		 * List<Integer> arrlstobj = new ArrayList(20); arrlstobj.add(2);
		 * System.out.println(arrlstobj);
		 */
		
		HashSet<String> h = new HashSet<String>();
		h.add("C");
		h.add("D");
		//h.add("D");
		System.out.println(h.add("R"));
		System.out.println(h.add("D"));
		//System.out.println(h);
		
		Iterator<String> itr=h.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
	}

}
