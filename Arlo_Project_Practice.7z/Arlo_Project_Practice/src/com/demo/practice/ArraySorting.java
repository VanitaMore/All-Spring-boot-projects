package com.demo.practice;

public class ArraySorting {

	public static void sortingArray(int a[]){

		for(int i=0;i<a.length;i++){

			for(int j=i+1;j<a.length;j++){
				int temp;

				if(a[i]>a[j]){
					temp=a[i];
					a[i]=a[j];
					a[j]=temp;
				}
			}
			if(i==1) {
				break;
			}
		}
       System.out.print(a[1]+" ");

	}
	public static void main(String args[])
	{

		int a[]={2,5,3,4,6,1};
		sortingArray(a);
	}
}
