package com.demo.practice;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class ConcurrentModificationException {

	public static void main(String[] args) {
		Map<String, Integer> map=new ConcurrentHashMap<String, Integer>();
		map.put("vanita", 6);
		map.put("fdgrdg", 7);
		map.put("jk", 1);
		map.put("awf", 5);
		map.put("yuk", 3);
		map.put("etgrj", 69);
		
		for(Map.Entry obj:map.entrySet()) {
			System.out.println(obj.getKey()+" "+obj.getValue());
			map.put("ttj", 9);
		}
	}

}
