package com.demo.practice;

public class DefaultExample implements I1,I2{

	public static void main(String[] args) {
		
		DefaultExample obj= new DefaultExample();
		obj.say();
		
	}

	@Override
	public void say() {
		I1.super.say();
	}

	
}
