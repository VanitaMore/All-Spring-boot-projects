package com.demo.practice;

public class Demo {

	public static void main(String[] args) {
		int num=1;
		
		for(int i=1;i<=10;num++) {
			System.out.println(num);
		}
		
	}

}
