package com.demo.practice;

import java.util.ArrayList;

public class DemoToday {

	public static void main(String[] args) {
		ArrayList<String> al=new ArrayList<String>();
		al.add("vanita");
		al.add("abhi");
		al.add("poo");
		al.add("anu");
		//System.out.println(al);
		/*
		 * for(String result:al) { System.out.println(result); }
		 */
		al.forEach(a->System.out.println(a));
	}

}
