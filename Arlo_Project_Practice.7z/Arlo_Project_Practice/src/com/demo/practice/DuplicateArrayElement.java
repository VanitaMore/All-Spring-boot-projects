package com.demo.practice;

public class DuplicateArrayElement {

	public static void main(String[] args) {
		int a[]= {3,5,8,3,12,5,8,2,12,53,89,5};
		
		for(int i=0;i<a.length-1;i++) {
			
			for(int j=i+1;j<a.length;j++) {
				
				if((a[i]==a[j])&&(i!=j)) {
					
					System.out.print(a[j]+" ");
				}
			}
		}
		
	}

}
