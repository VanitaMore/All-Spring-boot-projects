package com.demo.practice;

public class Employee1 {

	String firstname;
	String lastname;
	String address;


	@Override
	public String toString() {
	return "Employee1 [firstname=" + firstname + ", lastname=" + lastname + ", address=" + address + "]";
	}

	Employee1(Builder builder) {
	firstname = builder.firstname;
	lastname = builder.lastname;
	address = builder.lastname;
	}

	static class Builder {
	String firstname;
	String lastname;
	String address;

		/*
		 * Builder(String firstname) { this.firstname = firstname; }
		 */

	Builder() {
		
		}
	
	public Builder firstname(String firstname) {
	this.firstname = firstname;
	return this;
	}

	public Builder lastname(String lastname) {
	this.lastname = lastname;
	return this;
	}

	public Builder address(String address) {
	this.address = address;
	return this;
	}

	public Employee1 build() {
	return new Employee1(this);
	}
	}
	
}
