package com.demo.practice;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class ExecuterExample implements Callable<String>{

	 private String message;

	    public ExecuterExample(String message) {
	        this.message = message;
	    }

	    @Override
	    public String call() throws Exception {
	        return "Hello " + message + "!";
	    }
	    public static void main(String[] args) {
			
		
	    ExecuterExample task = new ExecuterExample("World");

        ExecutorService executorService = Executors.newFixedThreadPool(4);
        Future<String> result = executorService.submit(task);

        try {
            System.out.println(result.get());
        } catch (InterruptedException | ExecutionException e) {
            System.out.println("Error occured while executing the submitted task");
            e.printStackTrace();
        }

        executorService.shutdown();
    }

}

