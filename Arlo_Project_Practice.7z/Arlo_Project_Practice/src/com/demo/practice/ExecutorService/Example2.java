package com.demo.practice.ExecutorService;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class Example2 {

	public static void main(String[] args) throws InterruptedException, ExecutionException {
		Callable<String> c=new Callable<String>() {

			@Override
			public String call() throws Exception {
				System.out.println("hj");
				return "hii";
			}
		};
		
		ExecutorService exService=Executors.newFixedThreadPool(5);
		Future f=exService.submit(c);
		System.out.println(f.get());
		
	}

}
