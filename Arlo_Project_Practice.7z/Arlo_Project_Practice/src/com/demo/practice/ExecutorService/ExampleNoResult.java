package com.demo.practice.ExecutorService;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class ExampleNoResult {

	public static void main(String[] args) throws InterruptedException, ExecutionException {
		ExecutorService exService=Executors.newFixedThreadPool(5);
		Future future=exService.submit(new Runnable() {
			
			@Override
			public void run() {
				System.out.println("no result");
			}
		});
		exService.shutdown();
		System.out.println(future.get());
	}

}
