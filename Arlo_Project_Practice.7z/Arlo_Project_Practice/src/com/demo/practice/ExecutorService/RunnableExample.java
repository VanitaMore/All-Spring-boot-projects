package com.demo.practice.ExecutorService;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class RunnableExample {

	public static void main(String[] args) {
		ExecutorService exService=Executors.newFixedThreadPool(5);
		exService.execute(new Runnable() {
			
			@Override
			public void run() {
				System.out.println("task1 executed");
			}
		});
		
     exService.execute(new Runnable() {
			
			@Override
			public void run() {
				System.out.println("task2 executed");
			}
		});
    
		exService.shutdown();
	}

}
