package com.demo.practice;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.function.Consumer;

public class ForEachExample {

	public static void main(String[] args) {
		/*HashMap<String, Integer> map = new HashMap<>();
		map.put("A", 1);
		map.put("B", 2);
		map.put("C", 3);
		Consumer<Map.Entry<String, Integer>> action = entry -> {
		System.out.println("Key is : " + entry.getKey());
		System.out.println("Value is : " + entry.getValue());
		};
		map.entrySet().forEach(action);
		
	
	*/
		
		  ArrayList<String> al=new ArrayList<String>();  
		  al.add("Ravi");  
		  al.add("Vijay");  
		  al.add("Ravi");  
		  al.add("Ajay"); 
		  al.forEach(a->{ //Here, we are using lambda expression  
              System.out.println(a);  
            }); 

		  Iterator itr=al.iterator();  
		  while(itr.hasNext()){  
		   System.out.println(itr.next());  
		  } 
	}
}
