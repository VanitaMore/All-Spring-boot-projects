package com.demo.practice;

import java.util.HashMap;
import java.util.Map;

public class HashMapExample {

	public static void main(String[] args) {
		HashMap<Integer,String> hm=new HashMap<>();    
	     
	      hm.put(100,"Amit");    
	      hm.put(101,"Vijay");    
	      hm.put(102,"Rahul");  
	     
		
		/*
		 * for(Map.Entry s:hm.entrySet()) {
		 * System.out.println(s.getKey()+" "+s.getValue()); }
		 */
		 
	      
	      hm.forEach((a,b)->System.out.println(a+":"+b));
	    	  
	      hm.entrySet().stream().forEach(System.out::println);
	}

}
