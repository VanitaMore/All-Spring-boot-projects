package com.demo.practice;

public interface I1 {

	 default void say(){  
	        System.out.println("Hi1");  
	    }
}
