package com.demo.practice;

public interface I2 {

	 default void say(){  
	        System.out.println("Hello, this is default method");  
	    }
}
