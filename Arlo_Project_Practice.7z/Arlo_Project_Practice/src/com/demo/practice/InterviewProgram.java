package com.demo.practice;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class InterviewProgram {

	public static void main(String[] args) {
		int capacity = 4;
		List<Integer> list = new ArrayList<Integer>(Arrays.asList(6,5,7,2));
		System.out.println(list);
		Scanner s = new Scanner(System.in);

		for (int i = 1; i <= 10; i++) {

			System.out.print("enter num : ");
			int num = s.nextInt();

			if (list.size() >= capacity) {
				list.remove(0);
			}
			list.add(num);
			System.out.print(list);
		}
		
		
	}

	}
