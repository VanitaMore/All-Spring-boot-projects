package com.demo.practice;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Optional;
import java.util.Scanner;

public class KevinProgram {

	public static void main(String[] args) {
		int capacity=5;
		ArrayList<Integer> list=new ArrayList<Integer>(Arrays.asList(1,2,3,4,5));
		System.out.println(list.size());
		Scanner sc=new Scanner(System.in);
		System.out.println("enter num");
		int n=sc.nextInt();
		
		if(list.size()>=capacity) {
			Optional<Integer> e=list.stream().findFirst();
			list.remove(e.get());
			list.add(n);
		}else {
			list.add(n);
		}
		System.out.println(list);
	}

}
