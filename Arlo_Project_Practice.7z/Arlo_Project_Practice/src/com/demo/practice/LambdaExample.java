package com.demo.practice;

interface Employee{  
	public String draw();  
}  

public class LambdaExample {

	public static void main(String[] args) {
		
		/*
		 * int width=10;
		 * 
		 * //without lambda, Drawable implementation using anonymous class Drawable
		 * d=new Drawable(){ public void draw(){System.out.println("Drawing "+width);}
		 * }; d.draw(); }
		 */
	
		/*
		 * int width=10; Employee s=()->{ System.out.println("Drawing "+width); };
		 * s.draw();
		 */
		
		Employee e=()->{
			return "hello";
			
		};
		System.out.println(e.draw());
		   
		}  

}
