package com.demo.practice;

public class LargestAndSmallestElementFromArray {

	public static void main(String[] args) {

     int a[]= {4,5,7,2,77,4,89,23};
     int max=a[0],min=a[0];
     
     for(int i=1;i<a.length;i++) {
    	 if(a[i]>max) {
    		 max=a[i];
    	 }else if(a[i]<min) {
    		 min=a[i];
    	 }
     }
     
     System.out.println("max element is "+max);
     System.out.println("max element is "+min);
	}

}
