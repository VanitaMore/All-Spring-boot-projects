package com.demo.practice;

public class MainClass {

	public static void main(String[] args) {
		Employee1 emplyee = new Employee1.Builder()
				.firstname("vanita")
				.lastname("more")
				.address("pune").build();
		
	
		System.out.println(emplyee);
	
	}

}
