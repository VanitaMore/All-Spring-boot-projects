package com.demo.practice;

public interface MyFunctionalInterface {

	public void show();
		
	
}
