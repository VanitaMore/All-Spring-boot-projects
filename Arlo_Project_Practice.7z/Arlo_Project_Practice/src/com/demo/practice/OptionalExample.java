package com.demo.practice;

import java.util.Optional;

public class OptionalExample {

	public static void main(String[] args) {
		Optional<Integer> i=Optional.ofNullable(5);
		//System.out.println(i.get());
		System.out.println(i.isPresent());
	}

}
