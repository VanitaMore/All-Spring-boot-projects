package com.demo.practice;

import java.util.Scanner;

public class PalindromeNumber {

	public static void main(String[] args) {
      Scanner sc=new Scanner(System.in);
      System.out.println("enter a number");
      int num=sc.nextInt();
      int temp=num;
      int rem;
      int rev=0;
      
      while(temp!=0) {
    	  
    	  rem=temp%10;
    	  rev=rev*10+rem;
    	  temp=temp/10;
      }
      
      if(num==rev) {
    	  System.out.println("num is palindrome");
      }else {
    	  System.out.println("num is not palindrome");
      }
	}

}
