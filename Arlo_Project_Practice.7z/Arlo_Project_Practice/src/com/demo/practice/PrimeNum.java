package com.demo.practice;

import java.util.Scanner;

public class PrimeNum {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter num");
		int num=sc.nextInt();
		int temp=0;
		
		
			for(int i=2;i<=num-1;i++) {
				
				if(num%i==0) {
					temp=temp+1;
				}
			}
			if(temp>0) {
				System.out.print("num is not prime ");
			}else {
				System.out.print("num is prime ");
			}
		}
	}


