package com.demo.practice;

public class PrimeNumFromSeries {

	public static void main(String[] args) {

		int temp = 0;
		int num;
		for (num = 1; num <= 100; num++) {

			for (int i = 2; i <= num - 1; i++) {
				if (num % i == 0) {
					temp = temp + 1;
				}

			}
			if (temp == 0) {
				// these are prime numbers
				System.out.print(num + " ");
			} else {
				temp = 0;
			}
		}
	}
}
