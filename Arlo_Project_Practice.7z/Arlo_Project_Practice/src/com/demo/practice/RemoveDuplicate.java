package com.demo.practice;

import java.util.HashSet;

public class RemoveDuplicate {

	public static void getDistinct(int a[]) {
    HashSet<Integer> hashSet= new HashSet<>();
		
		for (int i = 0; i < a.length; i++) {
			if(!hashSet.contains(a[i])) {
				hashSet.add(a[i]);
				System.out.print(a[i]+" ");
			}
	}
	}
	public static void main(String[] args) {
		int a[]= {5,7,8,9,2,33,8,2};
		getDistinct(a);
	}

}
