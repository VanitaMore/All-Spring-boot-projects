package com.demo.practice;

public class SecondLargestFromArray {

	public static void main(String[] args) {
		
	}

}
