package com.demo.practice.Singleton;

public class DoubleLocking {
 private static DoubleLocking obj=null;
 
 private DoubleLocking() {
	 
 }
 
 //synchronized blk -double locking
   public static DoubleLocking getInstance() {
	  if(obj==null) {
		  synchronized (DoubleLocking.class) {
			if(obj==null) {
				obj=new DoubleLocking();
			}
		}
	  }
	return obj;
	}
   
	public static void main(String[] args) {
		System.out.println(getInstance().hashCode());
		System.out.println(getInstance().hashCode());
	}

}
