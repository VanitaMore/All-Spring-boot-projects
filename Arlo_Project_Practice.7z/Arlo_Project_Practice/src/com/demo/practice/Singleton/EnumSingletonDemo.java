package com.demo.practice.Singleton;

public class EnumSingletonDemo {

	public static void main(String[] args) {
		System.out.println(SingletonEnum.INSTANCE);

	}

}

enum SingletonEnum{
	INSTANCE;
	SingletonEnum(){
		System.out.println("singleton contr");
	}
}