package com.demo.practice.Singleton;

public class ExamplePractice {

	private static ExamplePractice obj=new ExamplePractice();
	
	private ExamplePractice(){
		
		  if(obj!=null)
		  { 
			  throw new InstantiationError("alredy exist");
			  //System.err.println("already exist....");
			 // System.exit(0);
			  }
		 
	}
	
	public static ExamplePractice getInstance() {
		return obj;
	}
	public static void main(String[] args) throws Exception {
		System.out.println(getInstance().hashCode());
		System.out.println(getInstance().hashCode());
		
		Class c=Class.forName("com.demo.practice.Singleton.ExamplePractice");
		System.out.println(c.getDeclaredConstructors()[0].newInstance().hashCode());
	}

}
