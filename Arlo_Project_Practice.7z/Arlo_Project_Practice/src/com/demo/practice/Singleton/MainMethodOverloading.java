package com.demo.practice.Singleton;

public class MainMethodOverloading {

	public static void main(String[] args) {
		System.out.println("String[] main method");
		main(100);
	}

	public static void main(int a) {
		main('r');
		System.out.println("int main method");
	}

	public static void main(char ch) {
		System.out.println("char main method");
	}
}