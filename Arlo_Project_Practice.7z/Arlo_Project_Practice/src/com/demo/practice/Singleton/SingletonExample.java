package com.demo.practice.Singleton;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

public class SingletonExample {

	private static SingletonExample obj = null;

	private SingletonExample() {

		/*
		 * if (obj != null) { throw new InstantiationError("Already there"); }
		 */

	}

	/*
	 * static SingletonExample getInstance() { return obj == null ? obj = new
	 * SingletonExample() : obj; }
	 */

	public static SingletonExample getInstance() {
		if (obj == null) {
			obj = new SingletonExample();
		}
		return obj;
	}

	public static void main(String[] args) throws NoSuchMethodException, SecurityException, InstantiationException,
			IllegalAccessException, IllegalArgumentException, InvocationTargetException {

		System.out.println(getInstance().hashCode());
		System.out.println(getInstance().hashCode());

		try {
			Class c = Class.forName("com.demo.practice.Singleton.SingletonExample");

			System.out.println(c.getDeclaredConstructors()[0].newInstance().hashCode());

		} catch (Exception e) {
			e.printStackTrace();
		}
		
		/*
		 * Constructor constructor=SingletonExample.class.getDeclaredConstructor();
		 * constructor.setAccessible(true); obj=(SingletonExample)
		 * constructor.newInstance(); System.out.println(obj.hashCode());
		 */

	}

}
