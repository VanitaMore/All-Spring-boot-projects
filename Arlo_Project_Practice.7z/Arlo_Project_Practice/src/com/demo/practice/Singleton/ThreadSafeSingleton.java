package com.demo.practice.Singleton;

public class ThreadSafeSingleton {

	private static ThreadSafeSingleton obj=null;
	
	private ThreadSafeSingleton() {
		
	}
	
	public static synchronized ThreadSafeSingleton getInstance() {
		if(obj==null) {
			obj=new ThreadSafeSingleton();
			
		}return obj;
	}
	public static void main(String[] args) {
		System.out.println(getInstance().hashCode());
		System.out.println(getInstance().hashCode());
		
	}

}
