package com.demo.practice;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StramExample {

	public static void main(String[] args) {
		
		 List<Integer> l=new ArrayList<Integer>();
		 l.add(6);
		 l.add(88);
		 l.add(3);
		 l.add(2);
		 l.add(12);
		 
		 List<Integer> l1=l.stream().filter(a->a%2==0).collect(Collectors.toList());
		System.out.println(l1);
		
		List<Integer> l2=l.stream().sorted((a,b)->-a.compareTo(b)).collect(Collectors.toList());
		System.out.println(l2);
		
		Integer min =l.stream().min((a,b)->a.compareTo(b)).get();
		System.out.println(min);
		
		 List<Integer> l4=l.stream().filter(a->a>10).collect(Collectors.toList());
			System.out.println(l4);
	}

}
