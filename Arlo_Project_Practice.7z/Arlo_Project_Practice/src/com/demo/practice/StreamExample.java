package com.demo.practice;

import java.util.Arrays;
import java.util.stream.Stream;

public class StreamExample {

	public static void main(String[] args) {
		String[] names = {"Al", "Ankit", "Kushal", "Brent", "sarika", "amanda", "Hans", "Shivika", "Sarah"};
		Stream.of(names)
		.filter(x->x.startsWith("s"))
		//.sorted()
		.forEach(System.out::println);
		
		//.collect(Collectors.toList()).forEach(System.out::println);
	}
}
