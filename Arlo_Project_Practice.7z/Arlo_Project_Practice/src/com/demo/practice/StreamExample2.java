package com.demo.practice;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class StreamExample2 {

	public static void main(String[] args) {
		List<String> list=new ArrayList<String>();
		list.add("vanita");
		list.add("Sandeep");
		list.add("aanita");
		list.add("svDFGhine");
		list.add("pooja");
		list.add("survan");
		
		//list.stream().map(String::toLowerCase).filter(x->x.startsWith("s")).sorted().collect(Collectors.toList()).forEach(System.out::println);
		
		list.stream().map(String::toLowerCase).filter(x->x.startsWith("s")).sorted().collect(Collectors.toList()).forEach(System.out::println);
		list.parallelStream().map(String::toUpperCase).filter(a->a.startsWith("p")).collect(Collectors.toList()).forEach(System.out::println);
		list.stream().filter(a->a.startsWith("p")).forEach(System.out::println);
		int a[]= {65,2,8,35,9};
		//IntStream.of(a).min().ifPresent(System.out::println);
		
		Stream<Integer> stream = Stream.of(54,63,6,2,5,6,7,8,9);
		//stream.sorted().forEach(System.out::print);
		
		//list.stream().collect(Collectors.toList()).forEach(System.out::println);
		//list.stream().forEach(b->System.out.println(b));
		
		
	}

}
