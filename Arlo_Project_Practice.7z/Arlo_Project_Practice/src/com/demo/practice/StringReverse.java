package com.demo.practice;

public class StringReverse {

	public static void main(String[] args) {
	    String s="vanita";
	    int length=s.length();
	    String rev="";
	    for(int i=length-1;i>=0;i--) {
	    	rev=rev+s.charAt(i);   //charAt start at 0th index
	    }
		System.out.println(rev);
		
	}

}
