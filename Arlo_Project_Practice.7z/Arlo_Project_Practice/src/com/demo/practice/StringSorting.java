package com.demo.practice;

public class StringSorting {

	public static void main(String[] args) {
		String a[]= {"sdsadf","vanita","sandeep","vishal","abhi"};
		sortArray(a);
		
		
	}
	static void sortArray(String a[]) {
		for(int i=0;i<a.length;i++)
		{
			for(int j=i+1;j<a.length;j++) {
				
				String temp;
				
				if(a[i].compareTo(a[j])>0) {
					temp=a[i];
					a[i]=a[j];
					a[j]=temp;
				}
			}
		}
		for(int i=0;i<a.length;i++) {
			System.out.print(" "+a[i]);
		}
	
	}

}
