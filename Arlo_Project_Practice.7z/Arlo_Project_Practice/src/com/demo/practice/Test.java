package com.demo.practice;
@FunctionalInterface
interface Square 
{ 
   public void calculate(); 
} 
  
class Test 
{ 
    public static void main(String args[]) 
    { 
         
        Square s = ()->System.out.println("hello");
  
        // parameter passed and return type must be 
        // same as defined in the prototype 
       s.calculate(); 
    } 
} 
