package com.demo.practice;

public class TimeComplexity {

	public static void main(String[] args) {
		int num=6;
		
			num=num*num;
			
		
		System.out.println(num);
		
	}

}
