package com.demo.practice;

import java.util.HashSet;
import java.util.Map;
import java.util.TreeMap;
import java.util.TreeSet;

public class TreeSetEx {

	public static void main(String[] args) {
		/*
		 * TreeSet t=new TreeSet();
		 * 
		 * t.add("ratan"); t.add("anu"); t.add("sravya");
		 * 
		 * t.add(12); t.add(4); t.add("sada"); System.out.println(t);
		 */
		
		/*
		 * HashSet<Integer> h= new HashSet<Integer>(); h.add(5); h.add(6); h.add(null);
		 * h.add(null); System.out.println(h);
		 */
		
		TreeMap<String,String> tmain = new TreeMap<String,String>();
		tmain.put("ratan","no1");
		tmain.put("anu","no2");
		
		for(Map.Entry<String, String> h:tmain.entrySet()) {
			System.out.println(h.getKey()+" "+h.getValue());
		}
	}

}
