package com.demo.practice;

public class XYZ {

	static void sortArray(int b[]) {
		
		for(int i=0;i<b.length;i++) {
			for(int j=i+1;j<b.length;j++) {
				int temp;
				if(b[i]>b[j]) {
					temp=b[i];
					b[i]=b[j];
					b[j]=temp;
				}
			}
		}
		
		for(int i=0;i<b.length;i++) {
			System.out.print(b[i]+" ");
		}
	}
	public static void main(String[] args) {
		int a[]= {66,34,7,22,5,76,32};
		sortArray(a);
	}

}
