package com.demo.practice.comparable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Simple {

	public static void main(String[] args) {
		List<Integer> i=new ArrayList<Integer>();
		i.add(5);
		i.add(6);
		i.add(22);
		i.add(34);
		Collections.sort(i,(a,b)->(a>b)?-1:(a<b)?1:0);
		System.out.println(i);
	}

}
