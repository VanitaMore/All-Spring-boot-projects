package com.demo.practice.comparable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class StudentTest {

	public static void main(String[] args) {
		ArrayList<Student> s=new ArrayList<Student>();
		s.add(new Student(4, "vanita", 2000));
		s.add(new Student(1, "sandy", 55000));
		s.add(new Student(9, "poo", 1000));
		s.add(new Student(22, "munni", 28000));
		s.add(new Student(55, "mouu", 100));
		
		Comparator<Student> a=(Student s1, Student s2)->()
	}

}
