package com.demo.practice.comparable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class TestComparable {

	public static void main(String[] args) {

   List<EmployeeComparable> empList=new ArrayList<EmployeeComparable>();
   empList.add(new EmployeeComparable(6, "vanita", 3400));
   empList.add(new EmployeeComparable(1, "anita", 122));
   empList.add(new EmployeeComparable(4, "sandeep", 7622));
   empList.add(new EmployeeComparable(5, "pooja", 100));
   Collections.sort(empList);
		/*
		 * for(EmployeeComparable e:empList) { System.out.println(e.getName()); }
		 */
   
   empList.forEach(e->
	   System.out.println(e.getId()+" "+e.getName()+" "+e.getSalary()));
   
	}

}
