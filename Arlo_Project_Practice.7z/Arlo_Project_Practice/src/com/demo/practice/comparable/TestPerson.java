package com.demo.practice.comparable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class TestPerson {

	public static void main(String[] args) {
		 List<Person> list=new ArrayList<Person>();
		 list.add(new Person(5,"sandeep",32000));
		 list.add(new Person(4,"abhi",242000));
		 list.add(new Person(1,"sdff",320090));
		 list.add(new Person(9,"okihj",320050));
		 
		 Collections.sort(list);
		System.out.println("comparable example is"+list);
		  Collections.sort(list,new Comparator<Person>() {
		  
		  @Override public int compare(Person o1, Person o2)
		  {
			  return o1.getName().compareTo(o2.getName()); 
		  
		  } });
		 
		  // for(EmployeeComparable e:empList)
		   
		  list.forEach(e->{
			   System.out.println(e.getId()+" "+e.getName()+" "+e.getSalary());
		   });
		 
		  
		  System.out.println("by Id");
		 Collections.sort(list, new SortComparatorById());
		 
		 list.forEach(e->{
			   System.out.println("sort by id"+ e.getId()+" "+e.getName()+" "+e.getSalary());
		   });
		 
		 System.out.println("by name");
		 Collections.sort(list, (e1,e2)-> (e1
		 
		/*
		 * list.forEach(e->{
		 * System.out.println(e.getId()+" "+e.getName()+" "+e.getSalary()); });
		 */
		 
		 
	}

}
