package com.demo.practice.comparable;

import java.util.Collections;
import java.util.TreeSet;

public class TreeSetExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      TreeSet<Person> set=new TreeSet<Person>();
         set.add(new Person(5,"sandeep",32000));
		 set.add(new Person(4,"abhi",242000));
		 set.add(new Person(1,"sdff",320090));
		 set.add(new Person(9,"okihj",320050));
		 
		 Collections.sort(set);
		 set.forEach(e->{
			   System.out.println(e.getId()+" "+e.getName()+" "+e.getSalary());
		   });
      
	}

}
