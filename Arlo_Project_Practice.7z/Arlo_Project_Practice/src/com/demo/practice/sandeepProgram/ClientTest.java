package com.demo.practice.sandeepProgram;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class ClientTest {

	public static void main(String[] args) {
		ArrayList<Employee> list=new ArrayList<Employee>();
		list.add(new Employee(1,"john","CS"));
		list.add(new Employee(2,"sham","EE"));
		list.add(new Employee(3,"ram","Mech"));
		list.add(new Employee(4,"adam","CS"));
		list.add(new Employee(5,"salman","EE"));
		list.add(new Employee(6,"shilpa","CS"));
		list.add(new Employee(7,"jolly","Mech"));
		list.add(new Employee(8,"shital","CS"));
		list.add(new Employee(9,"Vanita","Mech"));
		list.add(new Employee(10,"aniket","CS"));
		
		long start=System.currentTimeMillis();
		//System.out.println(start);
		
		Map<String, List<Employee>> map=list.stream().collect(Collectors.groupingBy(Employee::getDeptName));
		System.out.println(map);
		
		long end=System.currentTimeMillis();
		System.out.println(end);
		
		long timetakenByFirst=end-start;
		System.out.println(timetakenByFirst);
		
		Map<String, List<Employee>> map1 = new HashMap<String, List<Employee>>();
		int countMech = 0;
		int countEE = 0;
		int count = 0;
		List<Employee> e2 = new ArrayList<Employee>();
		List<Employee> e4 = new ArrayList<Employee>();
		List<Employee> e3 = new ArrayList<Employee>();
		for (Employee employee : list) {

			if (employee.getDeptName().equals("EE")) {
				Employee e2list = new Employee(employee.getEid(), employee.getEname(), employee.getDeptName());
				e2.add(e2list);

				map1.put(employee.getDeptName(), e2);
			} else if (employee.getDeptName().equals("Mech")) {

				Employee e3list = new Employee(employee.getEid(), employee.getEname(), employee.getDeptName());
				e3.add(e3list);
				map1.put(employee.getDeptName(), e3);
			} else {

				Employee e4list = new Employee(employee.getEid(), employee.getEname(), employee.getDeptName());
				e4.add(e4list);
				map1.put(employee.getDeptName(), e4);

			}

		}
		System.out.println(map1);

	}

}
