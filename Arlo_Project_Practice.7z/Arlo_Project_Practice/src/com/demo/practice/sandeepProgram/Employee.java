package com.demo.practice.sandeepProgram;

public class Employee {
	
	private int eid;
	private String ename;
	private String deptName;
	
	public Employee(int id, String name, String deptName) {
		this.eid=id;
		this.ename=name;
		this.deptName=deptName;
	}
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	@Override
	public String toString() {
		return "Employee [eid=" + eid + ", ename=" + ename + ", deptName=" + deptName + "]";
	}
	
	

}
