package com.demo.practice.sandeepProgram;

import java.util.ArrayList;

public class Test {

	public static void main(String[] args) {
		ArrayList<Employee> list=new ArrayList<Employee>();
		list.add(new Employee(1,"john","CS"));
		list.add(new Employee(2,"sham","EE"));
		list.add(new Employee(3,"ram","Mech"));
		list.add(new Employee(4,"adam","CS"));
		list.add(new Employee(5,"salman","EE"));
		list.add(new Employee(6,"shilpa","CS"));
		list.add(new Employee(7,"jolly","Mech"));
		list.add(new Employee(8,"shital","CS"));
		list.add(new Employee(9,"Vanita","Mech"));
		list.add(new Employee(10,"aniket","CS"));
		
		for(Employee e:list) {
			if(e.getDeptName().equals("EE"))
			System.out.println(e);
		}
	}

}
