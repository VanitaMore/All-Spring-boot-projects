package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.User;
import com.example.demo.repo.Auth2Repo;
import com.example.demo.service.UserService;

@RestController
@RequestMapping("/user")

public class UserController {
	@Autowired	Auth2Repo repoDao;
	 @Autowired private UserService userService;

	    @RequestMapping(value="/getuser", method = RequestMethod.GET)
	    public List<User> listUser(){
	        return userService.findAll();
	    }

	    @RequestMapping(value = "/createuser", method = RequestMethod.POST)
	    public String  create(){
	         userService.save();
	         return "Data Saved Successfully";
	    }

	    @RequestMapping(value = "/deleteUser/{id}", method = RequestMethod.DELETE)
	    public String delete(@PathVariable(value = "id") Integer id){
	        userService.delete(id);
	        return "Data deleted successfully";
	    }
}
