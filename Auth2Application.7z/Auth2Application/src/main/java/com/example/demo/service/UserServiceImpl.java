package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.example.demo.model.User;
import com.example.demo.repo.Auth2Repo;

@Service(value = "userService")
@Component
public class UserServiceImpl implements UserService {
	@Autowired
	Auth2Repo repoDao;

	public void save() {
		/*
		 * User user= new User();
		 * 
		 * user.setUserName("vanita"); 
		 * user.setPassword("1234"); repoDao.save(user);
		 */

		ArrayList<User> list = new ArrayList<>();
        User user1 = new User();
		user1.setUserName("Salman Khan");
		user1.setPassword("1234");
		
		User user2 = new User();
		user2.setUserName("Shah Rukh Khan");
		user2.setPassword("1312321");

		list.add(user1);
		list.add(user2);
		for (User user : list) {
			repoDao.save(user);
			
		}

	}

	@Override
	public List<User> findAll() {
		return (List<User>) repoDao.findAll();

	}

	@Override
	public void delete(int id) {
		repoDao.deleteById(id);
	}

}
