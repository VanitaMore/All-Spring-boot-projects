package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.BatchDetail;
import com.example.demo.model.DeviceDetail;
import com.example.demo.repo.BatchDetailRepo;
import com.example.demo.repo.DeviceDetailRepo;
import com.example.demo.service.BatchService;

@RestController
@RequestMapping("/batchservice")
public class BatchController {
	
	@Autowired BatchDetailRepo batchDetail;
	@Autowired DeviceDetailRepo deviceDetail;
	@Autowired  BatchService batchService;
	
	@GetMapping(value="/getdetails")
    public List<BatchDetail> getBatchList(){
        List<BatchDetail> findAll = batchService.findAll();
      
		return findAll;
    }

	 @PostMapping(value = "/insertBatchDetails")
	    public String  create(){
		 batchService.save();
	         return "Data Saved Successfully";
	    }
	 
	 @GetMapping("/fetchDeviceList/{chunkID}")
		public List<DeviceDetail> fetchDeviceListById(@PathVariable(value ="chunkID") String chunkID) {
		return batchService.fetchDeviceListByChunkId(chunkID);
		 
		}
	 
	 @PutMapping("/updateDevice/{chunkID}")
		public List<DeviceDetail> updateByChunkId(@PathVariable(value ="chunkID") String chunkID) {
		return  batchService.updateByChunkId(chunkID);
			

		}
	
}
