package com.example.demo.controller;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpMethod;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.example.demo.model.BusinessMaster;
import com.example.demo.service.CompanyService;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.slf4j.LoggerFactory;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(value="/cs")
@Api(value="CompanyController end points",description = "show master details")
public class CompanyController {
	private static final Logger LOG =Logger.getLogger(CompanyController.class.getName());

	
	
	@Autowired CompanyService companyService;
	
	@ApiOperation(value="first method")
	@GetMapping(value="/allCompanyServiceDetail")
	public List<BusinessMaster> getAllBusinessMasterDetail(){
		return companyService.getAllBusinessMasterDetail();
	}

	@GetMapping(value="/companyServiceDetailById/{businessId}")
	public Optional<BusinessMaster> getMasterDetailById(@PathVariable(value="businessId")String businessId) {
		return companyService.getMasterDetailById(businessId);
	}
	
	@GetMapping(value = "/exception")
	public String exception() {
		String response = "";
		try {
			throw new Exception("Exception has occured....");
		} catch (Exception e) {
			e.printStackTrace();
			LOG.error(e);

			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String stackTrace = sw.toString();
			LOG.error("Exception - " + stackTrace);
			response = stackTrace;
		}

		return response;
	}
	
}
