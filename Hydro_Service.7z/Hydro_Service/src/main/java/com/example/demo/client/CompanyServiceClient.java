package com.example.demo.client;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.example.demo.CallClient;
import com.example.demo.model.BusinessMaster;

@Component
public class CompanyServiceClient {

	private final Logger LOG = LoggerFactory.getLogger(CompanyServiceClient.class);
	@Autowired
	RestTemplate restTemplate;

	@Autowired
	CallClient callClient;

	public ResponseEntity<BusinessMaster> getCompanyServiceDetailById(String businessId) {
		LOG.info("Inside company service");
		String url = "http://companyService/cs/companyServiceDetailById/" + businessId;
		ResponseEntity<BusinessMaster> restExchange = restTemplate.exchange(url, HttpMethod.GET, null,
				BusinessMaster.class);
		LOG.info("The response received by company service " + restExchange);
		return restExchange;
	}

	/*
	 * public ResponseEntity<BusinessMaster> getCompanyServiceDetailById(String
	 * businessId) {
	 * 
	 * ResponseEntity<BusinessMaster> restExchange =
	 * callClient.allServiceDetails(businessId); return restExchange; }
	 */

	public List<BusinessMaster> getAllCompanyServiceDetail() {

		String url = "http://companyService/cs/allCompanyServiceDetail";
		BusinessMaster[] result = restTemplate.getForObject(url, BusinessMaster[].class);
		List<BusinessMaster> list = new ArrayList<BusinessMaster>(Arrays.asList(result));
		return list;
	}
	
	
}
