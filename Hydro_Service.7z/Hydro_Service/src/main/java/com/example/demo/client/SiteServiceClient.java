package com.example.demo.client;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.example.demo.model.SiteMaster;


@Component
public class SiteServiceClient {

	@Autowired
	RestTemplate restTemplate;

	//SiteServiceDetail
	public ResponseEntity<SiteMaster> getSiteServiceDetailById(String siteId) {

		String url = "http://siteService/ss/siteServiceDetailById/" + siteId;
		ResponseEntity<SiteMaster> restExchange = restTemplate.exchange(url, HttpMethod.GET, null,SiteMaster.class);
		System.out.println(restExchange.getBody());
		return restExchange;
	}

	public List<SiteMaster> getAllSiteServiceDetail() {

		String url="http://siteService/ss/allSiteServiceDetail";
	
		SiteMaster[] result = restTemplate.getForObject(url, SiteMaster[].class);
		List<SiteMaster> list=new ArrayList<SiteMaster>(Arrays.asList(result));
		return list;
	}
}
