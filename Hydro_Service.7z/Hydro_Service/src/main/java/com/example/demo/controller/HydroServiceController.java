package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.CompanyAndSiteServiceDetails;
import com.example.demo.service.HydroService;

@RestController
@RequestMapping(value = "/hs")
public class HydroServiceController {

	
	@Autowired
	HydroService hydroService;

	@GetMapping(value = "/allSiteDetails")
	public CompanyAndSiteServiceDetails getDetails() {
		return hydroService.getAllServicedetail();

	}

	@GetMapping(value = "/siteDetailById/{siteId}/{businessId}")
	public CompanyAndSiteServiceDetails getDetailById(@PathVariable(value = "siteId") String siteId,
			@PathVariable(value = "businessId") String businessId) {
		return hydroService.getDetailById(siteId,businessId);

	}
	
}
