package com.example.demo.model;

import java.io.Serializable;
import java.util.List;

public class CompanyAndSiteServiceDetails implements Serializable {

	private static final long serialVersionUID = 1L;

	List<SiteMaster> siteMasters;
	List<BusinessMaster> businessMasters;

	public List<SiteMaster> getSiteMasters() {
		return siteMasters;
	}

	public void setSiteMasters(List<SiteMaster> siteMasters) {
		this.siteMasters = siteMasters;
	}

	public List<BusinessMaster> getBusinessMasters() {
		return businessMasters;
	}

	public void setBusinessMasters(List<BusinessMaster> businessMasters) {
		this.businessMasters = businessMasters;
	}

}
