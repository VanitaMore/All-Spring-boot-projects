package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.example.demo.client.CompanyServiceClient;
import com.example.demo.client.SiteServiceClient;
import com.example.demo.model.BusinessMaster;
import com.example.demo.model.CompanyAndSiteServiceDetails;
import com.example.demo.model.SiteMaster;

@Service
public class HydroService {

	@Autowired
	SiteServiceClient siteServiceClient;
	
	@Autowired
	CompanyServiceClient companyServiceClient;

	public CompanyAndSiteServiceDetails getAllServicedetail() {
		CompanyAndSiteServiceDetails bothServiceDetail = new CompanyAndSiteServiceDetails();

		List<SiteMaster> siteServiceList = siteServiceClient.getAllSiteServiceDetail();

		// List<SiteMasterDtl> list=new ArrayList<SiteMasterDtl>();
		// list.add(siteServiceList.getBody());

		// List<SiteMaster> siteMasterList = siteMasterDtl.getSiteMasterList();
		// SiteMasterDtl sdt = new SiteMasterDtl();
		// sdt.setSiteMasterList(siteMasterList);
		bothServiceDetail.setSiteMasters(siteServiceList);

		List<BusinessMaster> businessMasterlist = companyServiceClient.getAllCompanyServiceDetail();

		// List<BusinessMasterDtl> blist=new ArrayList<BusinessMasterDtl>();
		// blist.add(businessMasterlist.getBody());
		bothServiceDetail.setBusinessMasters(businessMasterlist);
		return bothServiceDetail;

	}

	public CompanyAndSiteServiceDetails getDetailById(String siteId, String businessId) {

		CompanyAndSiteServiceDetails bothServiceDetail = new CompanyAndSiteServiceDetails();

		ResponseEntity<SiteMaster> siteMaster = siteServiceClient.getSiteServiceDetailById(siteId);
		SiteMaster siteMasterList = siteMaster.getBody();
		List<SiteMaster> siteList = new ArrayList<SiteMaster>();
		siteList.add(siteMasterList);
		bothServiceDetail.setSiteMasters(siteList);

		ResponseEntity<BusinessMaster> businessMaster = companyServiceClient.getCompanyServiceDetailById(businessId);
		BusinessMaster businessMasterList = businessMaster.getBody();
		List<BusinessMaster> businessList = new ArrayList<BusinessMaster>();
		businessList.add(businessMasterList);
		bothServiceDetail.setBusinessMasters(businessList);

		return bothServiceDetail;
	}

}
