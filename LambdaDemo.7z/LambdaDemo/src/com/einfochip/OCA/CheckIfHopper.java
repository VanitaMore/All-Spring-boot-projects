package com.einfochip.OCA;

public class CheckIfHopper implements CheckTrait {
	
	 public boolean test(Animal a) {
	 return a.canHop();
	 
	 }
	}
