package com.einfochip.OCA;

public interface CheckTrait {
	 boolean test(Animal a);

}
