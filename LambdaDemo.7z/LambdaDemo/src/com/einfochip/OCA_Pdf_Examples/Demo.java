package com.einfochip.OCA_Pdf_Examples;

/*public class Demo {

	public static void main(String[] args) {
		int x = 6;
		boolean y = (x >= 6) || (++x <= 7);
		System.out.println(x);
	}*/
class A{  
      private Integer get(){return 1;}  
    }  
  
class Demo extends A{  
	public Float get() { 
		return 1.0f;
		
		}  
void message()
{System.out.println("welcome to covariant return type");
}  
  
public static void main(String args[]){  
	Demo d=new Demo();
    System.out.println(d.get());  
}  

}
