package com.einfochip.OCA_Pdf_Examples;

public class Exampleif_then {

	public static void main(String[] args) {
		int hourOfDay = 11;
		if(hourOfDay = 11) {
			 System.out.println("Good Morning");
			}  {
			 System.out.println("Good Afternoon");
			}
	}

}
