package com.einfochip.OCA_Pdf_Examples;

public class TernaryExample {

	public static void main(String[] args) {
		/*int y = 10;
		System.out.println((y > 5) ? 21 : "Zebra");
		//int animal = (y < 91) ? 9 : "Horse";
		
		*/
		/*int dayOfWeek = 6;
		switch(dayOfWeek) {
		 case 0:
		 System.out.println("Sunday");
		 default:
		 System.out.println("Weekday");
		 case 6:
		 System.out.println("Saturday");
		 break;*/
		
		/*
		 * int x = 2; int y = 5; while(x < 10) y++; System.out.println(y);
		 */
		
		  /*int x = 0; 
	         while(x++ < 5) {} 
	        String message = x > 5 ? "Greater than" : false; 
	      System.out.println(message+","+x); 
	       } */
	
		/*
		 * final String[] names = new String[3]; names[0] = "Lisa"; names[1] = "Kevin";
		 * names[2] = "Roger"; for(String name : names) { System.out.print(name + ", ");
		 * }
		 */
		
		/*
		 * String names = "Lisa"; System.out.print(names + " ");
		 */
		
		/*
		 * java.util.List<String> values = new java.util.ArrayList<String>();
		 * values.add("Lisa"); values.add("Kevin"); values.add("Roger"); for(String
		 * value : values) { System.out.print(value + ", "); }
		 */
		
		int values[] = new int[3];

}
}