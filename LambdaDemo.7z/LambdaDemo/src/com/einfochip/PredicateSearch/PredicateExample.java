package com.einfochip.PredicateSearch;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;


  public class PredicateExample {
	  public static void main(String[] args) {
  
		
		  List<String> progLanguages = new ArrayList<>();
		  progLanguages.add("Java");
		  progLanguages.add("PHP"); 
		  progLanguages.add("Angular");
		  System.out.println(progLanguages); //[Java , PHP, Angular]
		  progLanguages.removeIf(s -> s.charAt(0) != 'J');
		  System.out.println(progLanguages); // [Java]
		   
	  }
  
  
  }
 

/*
 * public class PredicateExample {
 * 
 * private static int $; public static void main(String... args) { String a_b;
 * System.out.print($); //System.out.print(a_b);
 * 
 * private String brand; private boolean empty; public static void main(String[]
 * args) { PredicateExample wb = new PredicateExample();
 * System.out.print("Empty = " + wb.empty); System.out.print(", Brand = " +
 * wb.brand); } }
 */
