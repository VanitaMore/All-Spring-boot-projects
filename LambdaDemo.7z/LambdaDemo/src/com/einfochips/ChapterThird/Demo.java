package com.einfochips.ChapterThird;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Demo {

	String name;
	public static void main(String... args) {
		/*
		 * String s1 = "vanita";
		 * 
		 * String s2 = s1.concat("2"); s2.concat("3"); System.out.println(s2);
		 */
		 
		/*
		 * String s3= new String("abc"); String s4=new String (s3.concat("de"));
		 * System.out.println(s4);
		 */
		
		/*
		 * StringBuilder sb = new StringBuilder().append(1).append('c');
		 * sb.append("-").append(true); System.out.println(sb);
		 */ 
		
		/*
		 * System.out.println("abc".trim()); // abc
		 * System.out.println("\t a b c\n".trim());
		 */
		
		/*
		 * String start = "animal "; String result = start.replace('a', 'A'); //
		 * "Animal" System.out.println(result);
		 */
		
		/*
		 * String alpha = ""; for(char current = 'a'; current <= 'z'; current++) alpha
		 * += current; System.out.println(alpha);
		 */
		
		/*
		 * StringBuilder alpha = new StringBuilder(); for(char current = 'a'; current <=
		 * 'z'; current++) alpha.append(current); System.out.println(alpha);
		 */
		
		/*
		 * StringBuilder sb = new StringBuilder("abcdef");
		 * System.out.println(sb.delete(1, 3)); // sb = adef //sb.deleteCharAt(5);
		 */	
		
		/*
		 * StringBuilder one = new StringBuilder(); StringBuilder two = new
		 * StringBuilder(); StringBuilder three = one.append("a");
		 * System.out.println(one == two); // false System.out.println(one == three); //
		 * true
		 */		
		
		/*
		 * String x = "Hello World"; String y = "Hello World"; System.out.println(x ==
		 * y); // true
		 */
	
		/*
		 * String x = "Hello World"; String y = "Hello World"; System.out.println(x ==
		 * y); // false
		 */	
		
		/*
		 * Demo t1 = new Demo(); Demo t2 = new Demo(); Demo t3 = t1;
		 * System.out.println(t1 == t1); // true System.out.println(t1 == t2); // false
		 * System.out.println(t1.equals(t2)); // false
		 */	
	
		//int[] numbers1 = new int[3];
		/*
		 * int[] numbers2 = new int[] {42, 55, 99,89};
		 */
		
		/*
		 * String [] bugs = { "cricket", "beetle", "ladybug" }; String [] alias = bugs;
		 * System.out.println(bugs.equals(alias)); // true
		 * System.out.println(bugs.toString()); // [Ljava.lang.String;@160bc7c0
		 */	
		
		/*
		 * String [] bugs = { "cricket", "beetle", "ladybug" }; String [] alias = bugs;
		 * System.out.println(bugs.equals(alias)); // true
		 * System.out.println(bugs.toString()); // [Ljava.lang.String;@160bc7c0
		 */
	
		/*
		 * String[] strings = { "stringValue" }; Object[] objects = strings; String[]
		 * againStrings = (String[]) objects; // againStrings[0] = new StringBuilder();
		 * // DOES NOT COMPILE objects[0] = new StringBuilder(); // careful!
		 */	
		
		/*
		 * String[] strings = { "stringValue" }; Object[] objects = strings; // String[]
		 * againStrings = (String[]) objects; // againStrings[0] = new StringBuilder();
		 * // DOES NOT COMPILE objects[0] = new String();
		 * 
		 * String[] mammals = {"monkey", "chimp", "donkey"};
		 * System.out.println(mammals.length);
		 */
		
		/*
		 * int[] numbers = new int[10]; for (int i = 0; i < numbers.length; i++)
		 * System.out.println(numbers[i] = i + 5);
		 */
		 
		int[] numbers = { 6, 9, 1 };
		
		/*
		 * for (int i = 0; i < numbers.length; i++) System.out.print (numbers[i] + " ");
		 */
		
		//System.out.println(Arrays.sort(numbers));
		
		/*
		 * String[] strings = { "10", "9", "100" }; Arrays.sort(strings); for (String
		 * string : strings) System.out.print(string + " ");
		 */
		
		/*
		 * ArrayList list1 = new ArrayList(); ArrayList list2 = new ArrayList(10);
		 * ArrayList list3 = new ArrayList(list2);
		 */
		
		/*
		 * List<String> list6 = new ArrayList<>(); ArrayList<String> list7 = new
		 * List<>(); // DOES NOT COMPILE
		 */	
	
		/*
		 * ArrayList list = new ArrayList(); //list.add("hawk"); // [hawk]
		 * 
		 * list.add(Boolean.TRUE); // [hawk, true] System.out.println(list); // [hawk,
		 * true]
		 */	
		
		
		/*
		 * List<String> birds = new ArrayList<>(); birds.add("hawk"); // [hawk]
		 * birds.add(1, "robin"); // [hawk, robin] birds.add(0, "blue jay"); // [blue
		 * 
		 * birds.add(1, "cardinal"); // [blue jay, cardinal, hawk, birds.clear();
		 * System.out.println(birds); // [blue jay, cardinal, hawk, robin]
		 */
	
		/*
		 * int primitive = Integer.parseInt("123"); Integer wrapper =
		 * Integer.valueOf("123"); System.out.println(primitive);
		 */
		
		/*
		 * List<Integer> heights = new ArrayList<>(); heights.add(null);
		 * System.out.println(heights);
		 */
		
	/*	
		List<String> st= new ArrayList<String>();
		st.add("aa");
	    st.add("robin");
		Object[] objectArray = st.toArray();
		System.out.println(objectArray); // 2
		String[] stringArray = st.toArray(new String[0]);
		System.out.println(stringArray); */
		 
		String[] array = { "hawk", "robin" }; // [hawk, robin]
		List<String> list = Arrays.asList(array); // returns fixed size list
		System.out.println(list.size()); // 2
		list.set(1, "test"); // [hawk, test]
		array[0] = "new"; // [new, test]
		for (String b : array) 
			System.out.print(b + " "); // new test
		//list.remove(1); 
	}
	

}
