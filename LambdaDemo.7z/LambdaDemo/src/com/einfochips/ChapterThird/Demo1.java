package com.einfochips.ChapterThird;

public class Demo1 {

	/*
	 * public void walk1() { return;} public void walk2() { return; } public String
	 * walk3() { return ""; } public String walk4() { } // DOES NOT COMPILE public
	 * walk5() { } // DOES NOT COMPILE String walk6(int a) { if (a == 4) return "";
	 * return ""; } // DOES NOT COMPILE public static void main(String[] args) {
	 * 
	 * }
	 */
	
	public static void main(String[] args) {
		int sum=0;
		
		for(int x=0;x<=10;x++)
			sum+=x;
		System.out.println("sum for 0 to "+sum);
		System.out.println("="+sum);
	}
	

}
