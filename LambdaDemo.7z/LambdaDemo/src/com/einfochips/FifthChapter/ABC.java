package com.einfochips.FifthChapter;

public abstract class Animal {
	 public abstract String getName();
	}
	public class Bird extends Animal { // DOES NOT COMPILE
	}
	public class Flamingo extends Bird {
	 public String getName() {
	 return "Flamingo";
	 }
	}public abstract class Whale {
	 public abstract String getName(); // DOES NOT COMPILE
	}

	public class ABC extends Whale {
	 
	}
