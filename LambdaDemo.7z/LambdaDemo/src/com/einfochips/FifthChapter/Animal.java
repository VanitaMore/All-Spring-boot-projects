package com.einfochips.FifthChapter;

public class Animal {

	 public Animal(int age)
	 {
		 
	 }
	 
}
