package com.einfochips.FifthChapter;
 interface Herbivore {
	 public int eatPlants(int quantity);
	}

 interface Omnivore {
	 public void eatPlants();
	}
 
	public class Bear11 implements Herbivore, Omnivore {
		
	 public int eatPlants(int quantity) {
	 System.out.println("Eating plants: "+quantity);
	 return quantity;
	 }
	 
	 public void eatPlants() {
	 System.out.println("Eating plants");
	 }
	 
	 public static void main(String[] args) {
		 Bear11 v = new Bear11();
		 v.eatPlants(1);
	}
	}
