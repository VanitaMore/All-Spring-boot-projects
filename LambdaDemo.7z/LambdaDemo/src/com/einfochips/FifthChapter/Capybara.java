package com.einfochips.FifthChapter;
 class Rodent1 {
}
public class Capybara extends Rodent1 {
	 
 public static void main(String[] args) {
 Rodent1 rodent = new Rodent1();
 Capybara capybara = (Capybara)rodent; // Throws ClassCastException at runtime
 }
}