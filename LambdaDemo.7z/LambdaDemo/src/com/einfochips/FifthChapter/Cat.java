package com.einfochips.FifthChapter;

 interface Walk {
	 public default int getSpeed() {
	 return 5;
	 }
	}
	 
	public class Cat implements Walk { // DOES NOT COMPILE
		
	 public static void main(String[] args) {
	 System.out.println(new Cat().getSpeed());
	 }
	}
	
