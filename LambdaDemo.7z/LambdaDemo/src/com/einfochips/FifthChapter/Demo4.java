package com.einfochips.FifthChapter;

public class Demo4 {
	public static void main(String[] args) {
		/*
		 * Object obj = new Integer(3); String str = (String) obj;
		 * System.out.println(str);
		 */
		try {
			int a=1/0;
		}catch(Exception e)
		{
			System.out.println("catch");
			
		}
		
		finally  {
			System.out.println("hi");
		}
		System.out.println("jk");
	}

}
