package com.einfochips.FifthChapter;

public class ExceptionHandlingEx2 {
	
	
	
public static void main(String[] args) {
	catch (Exception e) {
		// TODO: handle exception
	}finally {
		
	}
}
}
