package com.einfochips.FifthChapter;
 
public class Lion extends Animal {
   
	public Lion()
	{
	  	
	}
    
}
