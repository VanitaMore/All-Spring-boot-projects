package com.einfochips.FifthChapter;

 abstract class Animal22 {
	 public abstract String getName();
	}
 
	abstract class BigCat extends Animal22 {
	 public String getName() {
		 return "BigCat";
	 }
	 public abstract void roar();
	}
	public class Lion1 extends BigCat {
	 public void roar() {
	 System.out.println("The Lion lets out a loud ROAR!");
	 }
	 public String getName() {
		 return "BigCat";
	 }
	}