package com.einfochips.FifthChapter;

public abstract interface MyInterface {
	
	static  int show();
	

}
