package com.einfochips.FifthChapter;

public interface MyInterface2 {


	 static int getRequiredFoodAmount() { // DOES NOT COMPILE
	 return 13;
	 }
}
