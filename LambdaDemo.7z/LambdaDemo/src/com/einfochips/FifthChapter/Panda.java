package com.einfochips.FifthChapter;

 class Bear {
	 public static void sneeze() {
	 System.out.println("Bear is sneezing");
	 }
	 public void hibernate() {
	 System.out.println("Bear is hibernating");
	 }
	}
	 class Panda extends Bear11 {
	 public void sneeze() { // DOES NOT COMPILE
	 System.out.println("Panda bear sneezes quietly");
	 }
	 public static void hibernate() { // DOES NOT COMPILE
	 System.out.println("Panda bear is going to sleep");
	 }
	}
