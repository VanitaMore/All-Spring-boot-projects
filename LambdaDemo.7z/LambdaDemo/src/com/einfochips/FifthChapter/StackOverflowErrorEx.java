package com.einfochips.FifthChapter;

public class StackOverflowErrorEx {
	
		public static void doNotCodeThis(int num) {
			 doNotCodeThis(1);
			}
	

}
