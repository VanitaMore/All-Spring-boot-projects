package com.einfochips.FifthChapter;

final interface WalksOnTwoLegs {
	
}
 class TestClass {
	
	 public static void main(String[] args) {
		 WalksOnTwoLegs example = new WalksOnTwoLegs(); 
	 }
}
