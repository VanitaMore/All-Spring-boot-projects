package com.einfochips.FourthChapter;

public class BadDuckling {

	public void makeNoise() {
		 FatherDuck duck = new FatherDuck();
		 duck.quack(); // DOES NOT COMPILE
		 System.out.println(duck.noise); 
}
}
