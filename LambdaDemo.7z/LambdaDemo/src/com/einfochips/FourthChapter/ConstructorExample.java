package com.einfochips.FourthChapter;

public class ConstructorExample {

	 private String color;
	 private int weight;
	 
	 public ConstructorExample(int weight) { // first constructor
		// first constructor
			//this.weight = weight;
		this(weight, "red"); 
	 }
	
	 public ConstructorExample(int weight, String color) { // second constructor
	 this.weight = weight;
	 this.color = "red";
	 }
	 
	 public static void main(String[] args) {
		 ConstructorExample b = new ConstructorExample( 2);
	      System.out.println( b.weight + " " + b.color);
		  } 
}
