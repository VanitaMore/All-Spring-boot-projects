package com.einfochips.FourthChapter;

public class Demo2 {

	 private static int count;
	 public Demo2() { count++; }
	 
	 public static void main(String[] args) {
		 Demo2 c1 = new Demo2();
		 Demo2 c2 = new Demo2();
		 Demo2 c3 = new Demo2();
		 Demo2 c4 = new Demo2();
		 System.out.println(count); 
}
}