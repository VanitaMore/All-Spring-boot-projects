package com.einfochips.FourthChapter;

import java.util.ArrayList;

public class Demo3 {

	/*
	 * private static final int NUM_BUCKETS = 45; public static void main(String[]
	 * args) { NUM_BUCKETS = 5; // DOES NOT COMPILE }
	 */
	
	/*
	 * private static final ArrayList<String> values = new ArrayList<>(); public
	 * static void main(String[] args) { values.add("changed"); }
	 */
	
	private static int one;
 private static final int two;
	 private static final int three ;
	 private static final int four; // DOES NOT COMPILE
	 static {
	 one = 1;
	 two = 2;
	 three = 3; // DOES NOT COMPILE
	 two = 4; // DOES NOT COMPILE
	 }
}

