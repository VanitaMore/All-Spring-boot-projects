package com.einfochips.FourthChapter;

public class DuckTeacher {

	public String name = "helpful"; // public access
	 public void swim() { // public access
	 System.out.println("swim");
	 } 
}
