package com.einfochips.FourthChapter;

public class FinalExample {
	public	static final int  a=6;
	public static void main(String[] args) {

		
	}

}
