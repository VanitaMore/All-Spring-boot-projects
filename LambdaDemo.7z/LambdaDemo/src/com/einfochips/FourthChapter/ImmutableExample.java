package com.einfochips.FourthChapter;

public class ImmutableExample {

	private StringBuilder builder;
	 public ImmutableExample(StringBuilder b) {
	 builder = b;
	 }
	 public StringBuilder getBuilder() {
	 return builder;
	 } 
	 public static void main(String[] args) {
		 StringBuilder sb = new StringBuilder("initial");
		 ImmutableExample problem = new ImmutableExample(sb);
		 sb.append(" added");
		 StringBuilder gotBuilder = problem.getBuilder();
		 gotBuilder.append(" more");
		 System.out.println(problem.getBuilder());
	}
}
