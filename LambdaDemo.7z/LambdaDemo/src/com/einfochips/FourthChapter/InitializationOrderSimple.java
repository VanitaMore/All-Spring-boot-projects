package com.einfochips.FourthChapter;

public class InitializationOrderSimple {

	private String name = "Torchie";
	 { 
		 System.out.println(name);
     }
	 
	 private static int COUNT = 0;
	 
	 static { 
		 System.out.println(COUNT);
		 }
	 
	 { 
		 COUNT++; System.out.println(COUNT); 
	}
	 
	public InitializationOrderSimple() 
	{
	 System.out.println("constructor");
	 }
	 public static void main(String[] args) {
	 System.out.println("read to construct");
	 new InitializationOrderSimple();
	 }
}
