package com.einfochips.FourthChapter;

public class LambdaExample {
public static void main(String[] args) {
	int marks = 90; 
    String result = marks > 60 ? "Pass with 1st div."
                    : marks < 50 ? "Pass with 2nd div." :  
                      marks < 40 ? "Pass with 3nd div.":"fail"; 
    System.out.println(result); 
}

}
