package com.einfochips.FourthChapter;

public class LostDuckling {

	public void swim() {
		 DuckTeacher teacher = new DuckTeacher();
		 teacher.swim(); // allowed
		 System.out.println("Thanks " + teacher.name); // allowed
		 } 
	
	public static void main(String[] args) {
		LostDuckling v= new LostDuckling();
		v.swim();
	}
}
