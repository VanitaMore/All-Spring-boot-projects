package com.einfochips.FourthChapter;

public class MethodOverloadingEx {
	
	public void fly(int[] lengths) { System.out.println("safd");}
	public void fly(String lengths) { } 
	
		public static void main(String[] args) {
			MethodOverloadingEx v= new MethodOverloadingEx();
			v.fly(new int[] { 1, 2, 3 });
		
		}
	
}
