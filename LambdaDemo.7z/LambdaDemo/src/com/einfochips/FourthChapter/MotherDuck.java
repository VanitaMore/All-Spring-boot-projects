package com.einfochips.FourthChapter;

public class MotherDuck {

	String noise = "quack";
	
	 void quack() {
	 System.out.println(noise); // default access is ok
	 }
	 
	  void makeNoise() {
	 quack(); 
	 }
}
