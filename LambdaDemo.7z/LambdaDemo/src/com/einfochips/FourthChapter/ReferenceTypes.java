package com.einfochips.FourthChapter;

public class ReferenceTypes {

	/*
	 * public void fly(int i) { System.out.print("int "); }
	 */
	/*
	 * public void fly(long l) { System.out.print("long "); } public static void
	 * main(String[] args) { ReferenceTypes p = new ReferenceTypes(); p.fly(123);
	 * p.fly(123L); }
	 */
	
	 public static void play(Long l) { }
	 public static void play(Object l) { System.out.println("int method");}
	 public static void main(String[] args) {
	 play(4); // DOES NOT COMPILE
	 play(4L); 
}
}