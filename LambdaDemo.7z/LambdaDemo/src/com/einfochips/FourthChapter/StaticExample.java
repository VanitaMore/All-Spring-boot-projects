package com.einfochips.FourthChapter;

public class StaticExample {
	/*
	 * public static int count = 2; public static void main(String[] args) {
	 * 
	 * StaticExample k = new StaticExample(); System.out.println(k.count); // k is a
	 * Koala
	 * 
	 * StaticExample.count=4; StaticExample.count=5; k = null;
	 * System.out.println(k.count); }
	 */
	
	private static String name = "Static class";
	 public static void first() { }
	 public static void second() { }
	 public static void third() { System.out.println(name); }
	 public static void main(String args[]) {
	 first();
	 second();
	 third(); 
	
	 }

}