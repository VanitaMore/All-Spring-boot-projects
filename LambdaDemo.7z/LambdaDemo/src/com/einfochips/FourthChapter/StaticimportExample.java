package com.einfochips.FourthChapter;

import java.util.List;
import static java.util.Arrays.asList; 
public class StaticimportExample {
	public static void main(String[] args) {
		 List<String> list = asList("one", "two"); // no Arrays.
		 System.out.println(list);
	}

}
