package com.einfochips.FourthChapter;

public class YetMoreInitializationOrder {

	/*
	 * static { add(2); }
	 * 
	 * static void add(int num) { System.out.print(num + " "); }
	 * 
	 * YetMoreInitializationOrder() { add(5); }
	 * 
	 * static { add(4); }
	 * 
	 * { add(6); }
	 * 
	 * static { new YetMoreInitializationOrder(); }
	 * 
	 * { add(8); } public static void main(String[] args) { }
	 */
	
	public static void main(String[] args) {
		int a=1000000000;
		System.out.println("a");
	}
}
