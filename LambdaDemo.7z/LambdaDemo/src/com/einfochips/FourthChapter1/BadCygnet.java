package com.einfochips.FourthChapter1;

import com.einfochips.FourthChapter.MotherDuck;

public class BadCygnet {

	 public void makeNoise() {
		 MotherDuck duck = new MotherDuck();
		 duck.quack(); // DOES NOT COMPILE
		 System.out.println(duck.noise); // DOES NOT COMPILE
		 } 
}
