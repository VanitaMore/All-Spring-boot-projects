package com.einfochips.FourthChapter1;

import com.einfochips.FourthChapter.Bird;

public class BirdWatcherFromAfar extends Bird{

	 public void watchBird() {
		 BirdWatcherFromAfar bird = new BirdWatcherFromAfar();
		 bird.floatInWater(); 
		 System.out.println(bird.text);
}
}
