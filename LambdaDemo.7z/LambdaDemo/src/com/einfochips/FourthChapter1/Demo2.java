package com.einfochips.FourthChapter1;

import com.einfochips.FourthChapter.DuckTeacher;
import com.einfochips.FourthChapter.LostDuckling;

public class Demo2 {

	public void swim() {
		 DuckTeacher teacher = new DuckTeacher();
		 teacher.swim(); // allowed
		 System.out.println("Thanks " + teacher.name); // allowed
		 } 
	
	public static void main(String[] args) {
		Demo2 v= new Demo2();
		v.swim();
	}
}
