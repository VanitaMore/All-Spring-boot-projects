package com.einfochips.FourthChapter1;

import com.einfochips.FourthChapter.Bird;

public class Gosling extends Bird{

	public void swim() {
		 floatInWater(); // calling protected member
		 System.out.println(text); // calling protected member
		 }
	public static void main(String[] args) {
		Gosling v= new Gosling();
		v.swim();
	}
	  
}
