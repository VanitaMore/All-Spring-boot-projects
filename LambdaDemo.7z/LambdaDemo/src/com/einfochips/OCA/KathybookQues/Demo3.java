package com.einfochips.OCA.KathybookQues;

public class Demo3 {
	Demo3()
	{
		main("hgi");
	}
public static void main(String[] args) {
	System.out.println("2");
}
public static void main(String args) {
	System.out.println("3" +args);
}
}	
