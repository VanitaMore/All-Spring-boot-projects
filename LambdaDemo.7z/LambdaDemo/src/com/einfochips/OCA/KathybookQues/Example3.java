package com.einfochips.OCA.KathybookQues;

public class Example3{

	/*
	 * public static void main(String[] args) { for(int _x=0; _x<3;_x++); int #lb=7;
	 * long [] x [5]; Boolean []ba[]; }
	 */
	
	public enum Days {MON,TUE,WED};
	public static void main(String[] args) {
		for(Days d:Days.values());
		Days[] d2=Days.values();
		System.out.println(d2[2]);
	}
}
