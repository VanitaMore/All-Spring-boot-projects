package com.einfochips.OCA.KathybookQues;
static import  java.lang.Integer.*;
public class Frodo {
	public static void main(String[] args) {
		System.out.println(Integer.MAX_VALUE);
	}
}
/*extends Hobbit{
	public static void main(String[] args) {
		int myGold=7;
		System.out.println(countGold(myGold,6));
	}

}
class Hobbit{
	static int countGold(int x,int y)
	{
		return x+y;
	}
}*/