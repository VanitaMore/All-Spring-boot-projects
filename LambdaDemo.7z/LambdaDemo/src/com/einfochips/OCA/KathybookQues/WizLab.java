package com.einfochips.OCA.KathybookQues;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.Period;
import java.util.ArrayList;
import java.util.List;

class  WizLab {
	static int x=10;
	public static void main(String[] args) {
		/*
		 * LocalDate date = LocalDate.of(2015, 3, 26); Period p= Period.ofDays(1);
		 * System.out.println(date.plus(p));
		 */
		
		/*
		 * List<Integer> list= new ArrayList<>(); int ints[][]=new int [3][];
		 */
		
		for(x=1;x<3;x++)
		{
			System.out.print(x);
		}
		System.out.println(x);
	}

}
