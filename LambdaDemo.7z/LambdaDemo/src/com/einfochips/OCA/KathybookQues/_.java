package com.einfochips.OCA.KathybookQues;
import static java.lang.System.*;
public class _ {
	
	static public void main(String[] _A_V_) {
		String $=" ";
		for(int x=0;++x< _A_V_.length;)
			$+=_A_V_[x];
		out.println($);
	}
	

}
