package com.einfochips.OCA.OCApdf;


public class Bird {
	private int numberBags;
	 boolean call;
	 public Bird() {
		this(2);
	 // LINE 1
	 call = false;
	 // LINE 2
	 }
	 public Bird(int numberBags) {
	 this.numberBags = numberBags;
	 }
	 public static void main(String[] args) {
	 Bird seed = new Bird();
	 System.out.println(seed.numberBags);
	 } 
	 }


