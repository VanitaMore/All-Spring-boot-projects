package com.einfochips.OCA.OCApdf;

class Vechile{
	String type="4w";
	int maxSpeed=100;
	
	
	
	Vechile(String type, int maxSpeed){
		this.type=type;
		this.maxSpeed=maxSpeed;
	}
}
 class Car extends Vechile {
	 String trans;
	 
   Car(String trans){                    //n1
	   this.trans=trans;
   }
   
   Car(String type, int maxSpeed,String trans){
	   super(type,maxSpeed); 
	   this(trans);             //n2
   }
}
