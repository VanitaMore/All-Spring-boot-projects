package com.einfochips.OCA.OCApdf;

public class Chapter3 {

	public static void main(String[] args) {
		/*
		 * int numFish = 4; String fishType = "tuna"; String anotherFish = numFish +
		 * 1+""; System.out.println(anotherFish + " " + fishType);
		 * System.out.println(numFish + " " + 1);
		 */
		
		/* String s = "Hello";
		 String t = new String(s);
		  if ("Hello".equals(s)) System.out.println("one");
		  if (t == s) System.out.println("two");
		  if (t.equals(s)) System.out.println("three");
		  if ("Hello" == s) System.out.println("four");
		  if ("Hello" == t) System.out.println("five");*/
		  
		/*
		 * String s1 = "java"; StringBuilder s2 = new StringBuilder("java"); if (s1 ==
		 * s2) System.out.print("1"); if (s1.equals(s2)) System.out.print("2");
		 */
		
		String s=new String("java");
		String s2=s.concat("hello");
		System.out.println(s);

	}

}
