package com.einfochips.OCA.OCApdf;

public class Demo11 {

	/*public  void show(boolean time) {
		
		if(time) {
			 String result="done";
		}
		System.out.println(result);*/
		public   static  void main(String[] name) {
			System.out.println(name[1]);
			
		}
	}


