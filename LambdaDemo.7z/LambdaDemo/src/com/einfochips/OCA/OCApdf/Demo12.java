package com.einfochips.OCA.OCApdf;

public class Demo12 {

	public static void main(String[] args) {
	String s="sad.ewrwe";
		//System.out.println(a);
	}

}
