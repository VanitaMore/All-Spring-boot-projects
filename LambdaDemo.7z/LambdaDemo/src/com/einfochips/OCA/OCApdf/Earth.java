package com.einfochips.OCA.OCApdf;

abstract class Planet{
	protected void revolve()        //n1
	{
		
	}
	abstract void rotate();            //n2
}
class Earth extends  Planet {

	
	 void revolve() {                  //n3
		
	}
  public void rotate()               //n4        
  {
	  
  }
	

}
