package com.einfochips.OCA.OCApdf;

import com.einfochips.OCA.pdfChapter3.Rope1;

public class RopeSwing {

	/*
	 * private static Rope1 rope1 = new Rope1(); private static Rope1 rope2 = new
	 * Rope1(); { System.out.println(rope1.length); } public static void
	 * main(String[] args) { rope1.length = 100; rope2.length = 9;
	 * System.out.println(rope1.length); }
	 */
	byte b=9;
	private static final String leftRope;
	private static final String rightRope;
	 private static final String bench;
	 private static final String name = "name";
	 static {
		  leftRope = "left";
		  rightRope = "right";
		  }
		  static {
		  name = "name";
		  rightRope = "right";
		  }
		  public static void main(String[] args) {
		  bench = "bench";
		  }
}
