package com.einfochips.OCA.OCApdf;

import java.io.IOException;

class X{
	public void print() throws IOException
	{
		throw new IOException();
	}
}
public class Test {

	public static void main(String[] args) throws Exception {
		X obj= new X();
	
		try {
			obj.print();
		} catch (Exception e) {
			
		}
		catch(IOException e) {
			
		}
	}

}
