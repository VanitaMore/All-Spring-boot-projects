package com.einfochips.OCA.OCApdf;

public class Test2 {

	public static void main(String[] args) {
		/*
		 * String s[][]=new String [2][]; s[1]= {2,3}[]; s[2]= {7,4};
		 */
		
		/*
		 * byte b=5; byte b2=5; long z=b+b2;
		 */
		
		/*
		 * int x = 0; while(x++ < 10) {} String message = x > 10 ? "Greater than" :
		 * "asd"; System.out.println(message+","+x);
		 */
		
		 /*java.util.List<Integer> list = new java.util.ArrayList<Integer>();
		 list.add(10);
		  list.add(14);
		  for(int x : list) {
		 System.out.print(x + ", ");
		  break;*/
		
		/*
		 * int x = 4; long y = x * 4 - x++; if(y<10) System.out.println("Too Low"); else
		 * System.out.println("Just right"); else System.out.println("Too High");
		 */
		
		int x = 1;
		 System.out.println(x > 2 ? x < 4 ? 10 : 8 : 7);
		  }
	}


