package com.einfochips.OCA.Test4Udemy;

import java.time.*;
import java.time.format.*;
import java.util.ArrayList;
public class DateExample 
{
	public static void main(String[] args) 
	{
		/*
		 * String
		 * date=LocalDate.parse("2014-05-04").format(DateTimeFormatter.ISO_DATE_TIME);
		 * System.out.println(date);
		 * 
		 * LocalDateTime dt=LocalDateTime.parse("2014-05-04T13:45:45.000"); String
		 * s=dt.format(DateTimeFormatter.ISO_DATE_TIME); System.out.println(s);
		 */
		
		/*
		 * LocalDateTime dt=LocalDateTime.of(2014,7,31,1,1); dt.plusDays(30);
		 * dt.plusMonths(1); System.out.println(dt.format(DateTimeFormatter.ISO_DATE));
		 */
		
		/*
		 * String s="HelloWorld "; s.trim(); int i1=s.indexOf(" ");
		 * System.out.println(i1);
		 */
		
		ArrayList l = new ArrayList();
		try
		{
			while(true)
			{
				l.add("MyString");
			}
		}
		catch (RuntimeException e)
		{
			System.out.println("Caught a RuntimeException");
		}
		catch (Exception e)
		{
			System.out.println("Caught an Exception");
		}
		System.out.println("Ready to use");
	}
	}
	
	

