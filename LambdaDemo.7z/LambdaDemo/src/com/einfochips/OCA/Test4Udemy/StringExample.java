package com.einfochips.OCA.Test4Udemy;

public class StringExample {

	/*
	 * public static void main(String[] args) { String str=" "; String
	 * str1=str.trim(); System.out.println(str1.equals("")+" "+str.isEmpty()); }
	 */

		/*
		 * boolean a = new Boolean(Boolean.valueOf(args[0])); boolean b = new
		 * Boolean(args[1]); System.out.println(a+".."+b);
		 */
		
		int count;
		public static void display()
		{
			count++;//Line-1
			System.out.println("Welcome Visit Count:"+count);//Line-2
		}
		public static void main(String[] args)
		{
			StringExample.display();//Line-3
			StringExample.display();//Line-4	
		}
	}

