package com.einfochips.OCA.Test4Udemy;

/*
 * public class Test {
 * 
 * public static void main(String[] args) { String[]
 * names={"Thomas","Bunny","Chinny"}; String[] pwds=new String[3]; int i =0; try
 * { for (String n: names) { pwds[i]=n.substring(2,6); i++; } } catch (Exception
 * e) { System.out.println("Invalid Name"); } for(String p: pwds) {
 * System.out.println(p); } }
 * 
 * }
 */

import java.io.*;
class X 
{
	public void printFileContent() throws IOException
	{
		throw new IOException();//Line-1
	}
}
public class Test
{
	public static void main(String[] args) throws IOException//Line-2
	{
		X x= new X();
		
		try {
			x.printFileContent();//Line-3
		} catch (Exception e) {
			// TODO: handle exception
		}catch(IOException e){
			
		}
		//Line-4
		
	}
}
