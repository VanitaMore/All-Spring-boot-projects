package com.einfochips.OCA.Test4Udemy;

  class Test2 {

	/*
	 * public static void main(String[] args) { String s1="123"; String s2="vbhjg";
	 * Integer i1=Integer.parseInt(s1); Boolean b1= Boolean.parseBoolean(s2);
	 * System.out.println(i1+".."+b1);
	 * 
	 * int i2= Integer.valueOf(s1); boolean b2=Boolean.valueOf(s2);
	 * System.out.println(i2+".."+b2); }
	 */
	 //protected int j=12;
	 // static int x=10;
	  abstract void Test2();
	  public final static void main(String[] args) {
		/*
		 * int x,y=100; System.out.println(x);
		 */
		
		  Double d1=10.0/0.0;
		  System.out.println(d1.isInfinite());
	}
}
