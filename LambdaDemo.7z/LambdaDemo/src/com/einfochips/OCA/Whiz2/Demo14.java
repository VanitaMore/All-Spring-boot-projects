package com.einfochips.OCA.Whiz2;

public class Demo14 {

	 static int y=10;
	public static void main(String[] args) {
		/*
		 * int i=_1000; double d=0.8_42;
		 */
		/*
		 * Integer i=Integer.decode("90"); System.out.println(i);
		 */
		
		/*
		 * int y=9; int x; x=10; System.out.println(x*y);
		 */
		
		Boolean b=new Boolean ("asd");
		System.out.println(b);
	}

}
