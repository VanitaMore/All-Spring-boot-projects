package com.einfochips.OCA.Whiz2;

public class Demo15 {
      static int i;
	public static void main(String[] args) {
		//int i;
		double j=0.25;
		double z=j+i;
		System.out.println(z);
	}

}
