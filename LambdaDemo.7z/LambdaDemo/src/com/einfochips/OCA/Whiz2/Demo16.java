package com.einfochips.OCA.Whiz2;

public class Demo16 {

	public static void main(String[] args) {
		short s=10;
		s+=10;
		s++;
		s=(short) (s+1);
		System.out.println(s);
	}

}
