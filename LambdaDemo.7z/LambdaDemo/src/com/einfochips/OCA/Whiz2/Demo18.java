package com.einfochips.OCA.Whiz2;

public class Demo18 {

	public static void main(String[] args) {
		/*
		 * String s1="vanita"; String s2="vanita";
		 * 
		 * System.out.println(s1.equals(s2)); System.out.println(s1==s2);
		 */
		
		String s="";
		System.out.println(s.length());
		boolean f=true;
		if(f=false)
		{
			
		}
	}

}
