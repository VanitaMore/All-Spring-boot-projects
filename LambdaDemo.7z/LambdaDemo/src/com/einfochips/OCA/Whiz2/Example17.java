package com.einfochips.OCA.Whiz2;

public class Example17 {

	/*
	 * static Integer i; public static void main(String[] args) { Double j=0.25;
	 * Double z=j+i; System.out.println(z); }
	 */
	
	public static void main(String[] args) {
		final int x=0;
		
		final int y=2;
		final int i=(int)(Math.random()*2);
		 System.out.println(i);
		 switch(i) {
		 case x:{System.out.println("A");}break;
		 case 1:System.out.println("B");
		 case 4:System.out.println("D");break;
		 case y:System.out.println("C");
		 
		 }
	}

}
