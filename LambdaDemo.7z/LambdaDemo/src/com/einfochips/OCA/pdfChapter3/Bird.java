package com.einfochips.OCA.pdfChapter3;

class Pelican extends Bird {
	 private void fly() { System.out.println("Pelican is flying"); }
}
public  abstract class Bird {

	protected void fly() 
	{ 
		System.out.println("Bird is flying");
	}
	public static void main(String[] args) 
	{
	 Bird bird = new Pelican();
	 bird.fly();
	}
	 }


	 

