package com.einfochips.OCA.pdfChapter3;

public   class Book {

	double d=9f;
	boolean b=true;
	
}
