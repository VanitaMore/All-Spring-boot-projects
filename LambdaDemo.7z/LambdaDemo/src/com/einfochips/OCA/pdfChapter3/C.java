package com.einfochips.OCA.pdfChapter3;

class A
{
	public A()
	{
		System.out.println("A");
	}
}
class B extends A
{
	public B()
	{
		//line-1
		System.out.println("B");
	}
}
class C extends B
{
	public C()
	{
		//line-2
		System.out.println("C");
	}
	public static void  main(String[] args)
	{
		B c = new B();
	}
}
