package com.einfochips.OCA.pdfChapter3;

class A22
{
	public void test()
	{
		System.out.print("A");
	}
}
class B44 extends A22
{
	public void test()
	{
		System.out.print("B");
	}
}
public class C1 extends A22
{
	public void test()
	{
		System.out.print("C");
	}
	public static void main(String[] args)
	{
		A22 a1 = new A22();
		A22 a2 = new B44();
		A22 a3 = new C1();
		a1.test();
		/*
		 * a2.test(); a3.test();
		 */
	}		
}