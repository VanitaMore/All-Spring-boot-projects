package com.einfochips.OCA.pdfChapter3;

class Vehicle45
{
	String type="4w";
	int maxSpeed=120;
	
	Vehicle45(String type,int maxSpeed)
	{
		this.type=type;
		this.maxSpeed=maxSpeed;
	}
}
class Car1 extends Vehicle45
{
	String trans;
	Car1(String trans)
	{
	        //Line-1
		this.trans=trans;
	}
	Car1(String type,int maxSpeed,String trans)
	{
		super(type,maxSpeed);
		this(trans);//Line-2
	}
}
