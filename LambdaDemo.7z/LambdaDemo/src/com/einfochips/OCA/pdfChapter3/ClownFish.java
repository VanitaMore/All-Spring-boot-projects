package com.einfochips.OCA.pdfChapter3;

interface Aquatic {
	public default int getNumberOfGills(int input)
	{
		return 2; 
	}
}
public class ClownFish implements Aquatic {

	public String getNumberOfGills() 
	{ return "4"; 
	}
	public int getNumberOfGills(int input) 
	{
		return 9;
	}
	public static void main(String[] args) {
		System.out.println(new ClownFish().getNumberOfGills(-1));
	}
}
