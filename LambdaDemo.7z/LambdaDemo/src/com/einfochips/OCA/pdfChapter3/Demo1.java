package com.einfochips.OCA.pdfChapter3;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class Demo1 {
	public static void main(String[] args) {
		/*
		 * String a = ""; a += 2; a += 'c'; a += false; if ( a == "2cfalse")
		 * System.out.println("=="); if ( a.equals("2cfalse"))
		 * System.out.println("equals");
		 */

		/*
		 * int total = 0; StringBuilder letters = new StringBuilder("abcdefg"); total +=
		 * letters.substring(1, 2).length(); // total += letters.substring(6,
		 * 6).length(); // total += letters.substring(6, 5).length();
		 * System.out.println(total);
		 */

		/*
		 * String b = new String("rumble"); b.concat("").deleteCharAt(3).delete(3,
		 * b.length() - 1); System.out.println(b);
		 */

		/*
		 * StringBuffer puzzle = new StringBuffer("Java");
		 * puzzle.append("vaJ$").delete(0, 3).deleteCharAt(puzzle.length());
		 * 
		 * // INSERT CODE HERE System.out.println(puzzle);
		 */

		/*
		 * int[][][] scores = new int[5][][]; Object[][][] cubbies = new
		 * Object[3][0][5]; String beans[] = new String[6]; java.util.Date[] dates[] =
		 * new java.util.Date[2][]; int[][] types = new int[][]; int[][] java = new
		 * int[2][];
		 */

		// char[]c = new char[2];
		// INSERT CODE HERE
		/*
		 * ArrayList l = new ArrayList(); l.remove(0);
		 */

		/*
		 * int[] random = { 6, 8, 9, 20, 12}; int x = 12; int y =
		 * Arrays.binarySearch(random, x); System.out.println(y);
		 */

		/*
		 * String [] names = {"Tom", "Dick", "Harry"}; List<String> list =
		 * Arrays.asList(names); list.set(0, "Sue"); System.out.println(names[0]);
		 */

		/*
		 * List<String> hex = Arrays.asList("30", "8", "3A", "FF");
		 * Collections.sort(hex); System.out.println(hex); int x =
		 * Collections.binarySearch(hex, "8"); int y = Collections.binarySearch(hex,
		 * "3A"); int z = Collections.binarySearch(hex, "4F"); //System.out.println(x +
		 * " " + y + " " + z);
		 */

		/*
		 * List<Integer> ages = new ArrayList<>(); ages.add(Integer.parseInt("5"));
		 * ages.add(Integer.valueOf("6")); ages.add(7); ages.add(null);
		 * System.out.print(ages);
		 */

		/*
		 * LocalDate date = LocalDate.parse("2018-04-30"); date.plusDays(2);
		 * //date.plusHours(3); System.out.println(date.getYear() + " " +
		 * date.getMonth() + " " + date.getDayOfMonth());
		 */

		/*
		 * LocalDate date = LocalDate.of(2018, Month.APRIL, 7);
		 * System.out.println(date.getYear() + " " + date.getMonth() + " " +
		 * date.getDayOfMonth());
		 */

		/*
		 * LocalDate date = LocalDate.of(2018, Month.APRIL, 30); // date.plusDays(2);
		 * LocalDate date2=date.plusYears(3); System.out.println(date2.getYear() + " " +
		 * date2.getMonth() + " " + date2.getDayOfMonth());
		 * 
		 * StringBuffer s= new StringBuffer("java"); s.append("rdsgt");
		 * System.out.println(s);
		 */

		/*
		 * LocalDateTime d = LocalDateTime.of(2015, 5, 10, 11, 22, 33);
		 * 
		 * Period p = Period.of(1, 2, 3); d = d.minus(p);
		 * 
		 * DateTimeFormatter f = DateTimeFormatter.ofLocalizedTime(FormatStyle.SHORT);
		 * System.out.println(d.format(f));
		 */
		
		LocalDateTime d = LocalDateTime.of(2015, 5, 10, 11, 22, 33);
		Period p = Period.ofDays(1).ofYears(2);
		d = d.minus(p);
		DateTimeFormatter f = DateTimeFormatter.ofLocalizedDateTime(FormatStyle
		.SHORT);
		System.out.println(f.format(d));
	}

}
