package com.einfochips.OCA.pdfChapter3;

import java.util.ArrayList;
import java.util.List;

public class Demo4 {

	public static void main(String[] args) {
		List<String> list = new ArrayList<>();
		list.removeIf(s -> {return s.isEmpty();});
		
	}

}
