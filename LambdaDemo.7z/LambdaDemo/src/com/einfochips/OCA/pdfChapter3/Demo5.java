package com.einfochips.OCA.pdfChapter3;

public class Demo5 {
public static int main(String[] args) {
	try {
		int a=0,b=0;
		 return a / b;
		 } catch (ArithmeticException e) {
		 return -1;
		 } catch (RuntimeException e) {
		 return 0;
		 } finally {
		 System.out.print("done");
		 } 
}
	
}
