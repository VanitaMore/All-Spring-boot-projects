package com.einfochips.OCA.pdfChapter3;

import java.io.IOException;

public class Demo6 {

	/*
	 * public void ohNo() throws IOException { //System.out.println("asd"); //throw
	 * new IllegalArgumentException(); //throw new java.io.IOException(); // throw
	 * new RuntimeException(); throw new NullPointerException(); }
	 */
	
public static void main(String[] args) throws RuntimeException,RuntimeException{
	try {
		 System.out.println("work real hard");
		 }  catch (RuntimeException e) {
		 }
}
}
