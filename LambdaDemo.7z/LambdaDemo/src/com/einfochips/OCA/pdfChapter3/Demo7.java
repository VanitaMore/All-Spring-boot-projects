package com.einfochips.OCA.pdfChapter3;

public class Demo7 {
	private static int $;
	 public static void main(String[] main) {
	 String s1="java";
	 String s2="java";
	 System.out.println(s1==s2);
	 
	 }
}
