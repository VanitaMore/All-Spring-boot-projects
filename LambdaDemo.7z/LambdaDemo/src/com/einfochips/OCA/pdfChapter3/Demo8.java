package com.einfochips.OCA.pdfChapter3;

public class Demo8 {
	public static void main(String[] args) {
		String[] s = {"bd","sda"};
		int i =0;
		for(String s1 : s)
		{
			s[i].concat("Element "+i);
			i++;
		}
		for(i=0;i<s.length;i++)
		{
			System.out.println(s[i]);
		}
	}

}
