package com.einfochips.OCA.pdfChapter3;

 class Customer
{
	ElectricAccount acct=new ElectricAccount();
	public void useElectricity(double kwh)
	{
		acct.addKwh(kwh);
	}
}
public class ElectricAccount
{
	private double kwh;
	public double rate=0.09;
	private double bill;
	//Line-1
	private  void addKwh(double kwh)
	{
		if(kwh>0)
		{
			this.kwh+=kwh;
			this.bill=this.kwh*this.rate;
		}
	}
}
