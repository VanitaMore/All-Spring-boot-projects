package com.einfochips.OCA.pdfChapter3;

public interface MyInterface {
	
	 static void fly();

}
