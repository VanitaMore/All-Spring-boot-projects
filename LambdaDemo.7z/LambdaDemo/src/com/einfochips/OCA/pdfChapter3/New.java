package com.einfochips.OCA.pdfChapter3;

public class New {

	public static void main(String[] args) {
		StringBuilder sb1= new StringBuilder("Durga");
		String str1=sb1.toString();
		//insert code here==>Line-1
		System.out.println(str1);
	}

}
