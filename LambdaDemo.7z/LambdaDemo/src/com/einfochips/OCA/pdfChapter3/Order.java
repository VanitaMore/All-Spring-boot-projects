package com.einfochips.OCA.pdfChapter3;

public class Order {
	static String result = "";
	 { result += "c"; 
	 result += "b"; 
	 }
   static
    { result += "u"; }
	 { result += "r"; }

	 public static void main(String[] args) {
		  System.out.print(Order.result + " ");
		  System.out.print(Order.result + " ");
		 new Order();
		 new Order();
		  System.out.print(Order.result + " ");
		 }
}
