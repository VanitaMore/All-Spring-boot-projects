package com.einfochips.OCA.pdfChapter3;

interface Nocturnal {
 default boolean isBlind() 
 { 
	 return true;
	 }
 }
public class Owl implements Nocturnal  {

	public boolean isBlind()
	{
		return false; 
		}
	public static void main(String[] args) 
	{
		Owl nocturnal = new Owl();
	 System.out.println(nocturnal.isBlind());
	 }
	 
}
