package com.einfochips.OCA.pdfChapter3;

public class Person {

	String name;
	int age=25;
	
	public Person() {
		
	}
	public Person(String name)
	{
		this(); //line-1
		setName(name);
	}
	public Person(String name,int age)
	{
		super();//Line-2
		setAge(age);
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	//setter and getter methods go here
	public String show()
	{
		return name+" "+age+" ";
	}
	public static void main(String[] args)
	{
		Person p1= new Person("Durga");
		Person p2= new Person("Ravi",50);
		System.out.println(p1.show());
		System.out.println(p2.show());
	}
}
