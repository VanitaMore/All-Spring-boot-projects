package com.einfochips.OCA.pdfChapter3;

class Mammal{
	public Mammal(int age) {
		System.out.print("Mammal");
	}
	
}
	class Platypus extends Mammal {
		public Platypus() {
			System.out.print("Platypus");
		}
	
		public static void main(String[] args) {
			new Mammal(5);
		}
	}
