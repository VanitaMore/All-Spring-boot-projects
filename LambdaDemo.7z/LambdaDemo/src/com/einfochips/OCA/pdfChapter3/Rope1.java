package com.einfochips.OCA.pdfChapter3;

public class Rope1 {

	 public static int length = 0;
}
