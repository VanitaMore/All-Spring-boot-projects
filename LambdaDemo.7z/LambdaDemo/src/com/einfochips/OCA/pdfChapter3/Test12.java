package com.einfochips.OCA.pdfChapter3;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Test12 {

	public static void main(String[] args) {
		/*
		 * LocalDate date1=LocalDate.now(); LocalDate date2=LocalDate.of(2018,4,15);
		 * LocalDate date3=LocalDate.parse("2018-04-15",DateTimeFormatter.ISO_DATE);
		 * System.out.println("date-1:"+date1); System.out.println("date-2:"+date2);
		 * System.out.println("date-3:"+date3);
		 */
		
		/*
		 * String sb=new String(""); String s=""; if(sb.equals(s)) {
		 * System.out.println("Match 1"); } else if(sb.toString().equals(s.toString()))
		 * { System.out.println("Match 2"); } else { System.out.println("No Match"); }
		 */
		
		/*
		 * LocalDateTime dt=LocalDateTime.of(2014,7,32,1,1); dt.plusDays(30);
		 * dt.plusMonths(1); System.out.println(dt.format(DateTimeFormatter.ISO_DATE));
		 */
		
		void readCard(int cno) throws Exception
		{
			System.out.println("Rearding Card");
		}
		void checkCard(int cno) throws RuntimeException//Line-1
		{
			System.out.println("Checking Card");
		}
		public static void main(String[] args)
		{
			Test t = new Test();
			int cardNo=1234;
			t.checkCard(cardNo);//Line-2
			t.readCard(cardNo);//Line-3
		}
	}

}
