package com.einfochips.OCA.pdfChapter3;

public class Test3 {
	public static void main(String[] args) {
		Short s1 = 200;
		Integer s2= 400;
		Long s3 = (long)s1+s2;//Line-1
		Long s4 = (long)(s3*s2);//Line-2
		System.out.println(s4);
	}

}
