	package com.einfochips.OCA.pdfChapter3;

public class X {

	public void a(){}
	int a;
}
