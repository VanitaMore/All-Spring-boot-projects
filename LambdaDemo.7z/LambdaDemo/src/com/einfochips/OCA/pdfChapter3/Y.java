package com.einfochips.OCA.pdfChapter3;

public interface Y {
 abstract void m() {
	 
 }
	
}
