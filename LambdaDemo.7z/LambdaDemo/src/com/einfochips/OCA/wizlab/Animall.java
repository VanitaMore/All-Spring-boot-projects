package com.einfochips.OCA.wizlab;
interface i1{
	public default int getspeed()
	
	{
		return 5;
	}
}
interface i2{
public default int getspeed()
	
	{
		return 10;
	}
}
public class Animall implements i1,i2{


@Override
public  int getspeed() {

	return 6;
}
public static void main(String[] args) {
	 Animall obj= new Animall();
	 System.out.println(obj.getspeed());
}
}
