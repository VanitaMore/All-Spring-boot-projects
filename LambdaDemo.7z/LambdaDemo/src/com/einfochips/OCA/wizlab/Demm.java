package com.einfochips.OCA.wizlab;

class Demm{
	public static void main(String[] args) {
		i11.getspeed();
	}
	static {
		System.out.println("move");
	}
}
interface i11{
	public static void main(String[] args) {
		System.out.println("move");
	}
	public static String getspeed()
	
	{
		return "hell";
	}
}