package com.einfochips.OCA.wizlab;

import java.util.Arrays;

public class Demo {

	public static void main(String[] args) {
		/*
		 * char[] chars= {'A','B','1','2','@'};
		 * System.out.println(chars[chars.length-1]);
		 */
		
		/*
		 * int a[]= {1,2,053,4 }; int b[][]= {{1,2,4 },{2,2,1},{0,43,2}};
		 * System.out.println(a[3]==b[0][2]); System.out.println((a[2]==b[2][1]));
		 */
		
		/*
		 * int ints[][]=new int[3][]; ints[1]=new int[] {1,2,3}; ints[2]=new int[]
		 * {4,5}; System.out.println(ints[1][1]);
		 */
		
		/*
		 * int []a=new int[0b10101]; int len=a.length; for(int i:a) System.out.print(i);
		 */
		
		/*
		 * String [][] st= {{"A","Z"},{"C","D","S"},{"L"}}; Arrays.sort(st); for(String
		 * []a:st) { for(String s:a) { System.out.println(s); } }
		 */
		
		/*
		 * Object obj=new Double(3); //Number num=(Number)obj; System.out.println(obj);
		 */
		
		/*
		 * //int x=2; for(int x=0;x<3;x++) { System.out.println(x); }
		 */
		
		for(int x=10,y=6;x>y;System.out.println(x--));
		for(int x=10,y=6;x-->y);
		for(;;);
		
}
}
