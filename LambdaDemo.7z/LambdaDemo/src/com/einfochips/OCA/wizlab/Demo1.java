package com.einfochips.OCA.wizlab;

public class Demo1 {

	public static void main(String[] args) {
		/*
		 * int x=10;
		 * 
		 * if(x>10); System.out.println(">");
		 * 
		 * else if(x<10) System.out.println("<");
		 */
		
		final int x=0;
		final int y=2;
		
		switch(x)	
		{
		case x:{System.out.println("A");}
		case 1: System.out.println("B");
		default:System.out.println("default");break;
		case y:System.out.println("C");
		}
		}
	}


