package com.einfochips.OCA.wizlab;

public class Demo11 {
	static {
		x=10;
	}
	public static void main(String[] args) {
		/*
		 * int x=0; if(x) { System.out.println("if"); }else {
		 * System.out.println("else");
		 * 
		 * }
		 */
	}

}
