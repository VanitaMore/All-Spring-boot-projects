package com.einfochips.OCA.wizlab;
/*
 * interface MyInterface { static int show() { return 2; } } public class Demo4
 * implements MyInterface { static int show() { System.out.println("child");
 * return 4; } public static void main(String[] args) { Demo4 od=new Demo4();
 * od.show(); } }
 */
import com.einfochips.OCA.Test4Udemy.*;
class Demo4 extends Test2
{
	public static void main(String[] args) {
		Test2 obj= new Test2();
	}
}
