package com.einfochips.OCA.wizlab;

 class Demo5 {

	/*
	 * public static void main(String[] args) { String s1="abc"; String s2="abc";
	 * System.out.println(s1==s2); }
	 */
	 Demo5 method()
	 {
		 return new Demo5();
	 }
}
 class BB extends Demo5{
	 
 }
