package com.einfochips.OCA.wizlab;

public class Demo6 {
 static int i=2;
	public static void main(String[] args) {
		int aar[]= new int[i];
		aar[0]=66;
		aar[1]=67;
		System.out.println(aar[1]);
	}

}
