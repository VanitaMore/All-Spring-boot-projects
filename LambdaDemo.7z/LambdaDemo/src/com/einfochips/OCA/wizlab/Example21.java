package com.einfochips.OCA.wizlab;

public class Example21 {

	/*
	 * static int x=50; public static void main(String[] args) { int[]a=new int[2];
	 * a[1]=10; for(Integer i:a) System.out.println(i); }
	 */
	
	public static void main(String[] args) {
		/*String s="A";
		final String c1="A";
		String c2="B";
		
		switch(s) {
		case c1:{System.out.println("A");};
		default:{System.out.println("default");};
		//case c2:{System.out.println("B");};
*/	
		/*int a=10;
		int b=20;
		if(a==b)
			System.out.println("1");
		else
			System.out.println("2");
		}*/
	
		for(int j=0,k=5;j<k;k--);
	}
	}


