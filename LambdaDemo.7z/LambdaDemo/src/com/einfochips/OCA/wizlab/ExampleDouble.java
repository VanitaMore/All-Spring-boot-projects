package com.einfochips.OCA.wizlab;

import java.io.CharConversionException;

public class ExampleDouble {
	public static void main(String[] args) {
		/*
		 * Double d= 0.0/0.0; System.out.println(Double.isNaN()+"");
		 * System.out.println(d.isInfinite());
		 */
		
		Character ch=new Character("xcdc");
		System.out.println(Character.isLetterOrDigit(ch));
	}

}
