package com.einfochips.OCA.wizlab;

public class MM {

	static int x=10;
	public static void main(String[] args) {
		/*
		 * boolean b=true; byte b1=128; System.out.println(b1); char c="ads"; char
		 * c2='d'; char c3=68; float f=2.4F;
		 */
		/*
		 * MM obj= new MM(); obj.x=5; int y=x/obj.x; System.out.print("y=");
		 * //System.out.print(6); System.out.print(y);
		 */
		
		/*
		 * int x,y; System.out.println(x);
		 */
		
		Double d=10.0/10.0;
		
		Integer i2=Integer.decode("22");
		short s=10;
		//long l=1000_l;
		int i=_1000;
	}

}
