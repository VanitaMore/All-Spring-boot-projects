package com.einfochips.OCA.wizlab;
/*
 * class Animal{ void run() { System.out.println("animal run"); } } class Dog
 * extends Animal{ void sound() { System.out.println("Bark"); } public void
 * run() { System.out.println("dog run"); }
 * 
 * } class Program { public static void main(String[] args) { Animal dog=new
 * Dog(); Animal a= new Animal(); a.run(); dog.sound(); dog.run();
 * System.out.println(dog); } }
 */

class Animal{
	Animal()
	{
		System.out.println("animal");
	}
}
 class Bird extends Animal{
	 Bird(String name)
	 {
		 super();
		 System.out.println(name);
	 }
	 Bird()
	 {
		 System.out.println("unknown");
	 }
    
}
 class Program {
public static void main(String[] args) {
	new Bird("parrot");
	
}
}

 