package com.einfochips.OCA.wizlab;

 class MyException extends RuntimeException
{
}
 
public class Test
{
	public static void main(String[] args)
	{
		try
		{
			m1();
		}
		catch (MyException e)
		{
			System.out.print("A");
		}
	}
	public static void m1() throws Exception
	{
		try
		{
			throw Math.random() > 0.5 ? new Exception():new MyException();
		}
		catch (RuntimeException e)
		{
			System.out.println("B");
		}
	}
}
