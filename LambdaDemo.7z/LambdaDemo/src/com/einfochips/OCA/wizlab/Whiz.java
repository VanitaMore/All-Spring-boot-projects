package com.einfochips.OCA.wizlab;
class Animal11{
	void eat()
	{
		System.out.println("animal eat");
	}
}
class Bird1 extends Animal11{
	void eat()
	{
		System.out.println("bird eat");
	}
	void print()
	{
		super.eat();
	}
}
public class Whiz {

	public static void main(String[] args) {
		Bird1 obj= new Bird1();
		obj.print();
	}

}
