package com.einfochips.OCA.wizlab;
interface I{
	void meth();
}
class AAA implements I
{
	void AAA(String s)
	{
		
	}

	@Override
	public void meth() {
		System.out.println("A");
	}
}
 class Whiz22 extends AAA{
	 public void meth() {
			System.out.println("C");
		}

}
class Whiz2{
	public static void main(String[] args) {
		AAA obj= new AAA();
		Whiz22 c=(Whiz22)obj;
		c.meth();
	}
}