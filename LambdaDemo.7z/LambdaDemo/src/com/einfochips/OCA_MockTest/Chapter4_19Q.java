package com.einfochips.OCA_MockTest;

import java.util.function.Predicate;

public class Chapter4_19Q {
    
	/*
	 * int age; public static void main(String[] args) { Chapter4_19Q p1 = new
	 * Chapter4_19Q(); p1.age = 1; check(p1, p -> p.age < 5); } private static void
	 * check(Chapter4_19Q main, Predicate<Chapter4_19Q> pred) { String result =
	 * pred.test(main) ? "match" : "not match"; System.out.print(result); }
	 */
	
	 static String result = "";
	  {
	    result += "CCC";
	  }
	  static {
	    result += "UUU";
	  }
	  {
	    result += "RRR";
	  }
	

	  public static void main(String[] args) {
	    System.out.print(Chapter4_19Q.result + " ");
	    System.out.print(Chapter4_19Q.result + " ");
	    new Chapter4_19Q();
	    new Chapter4_19Q();
	    System.out.print(Chapter4_19Q.result + " ");
	  }

}
