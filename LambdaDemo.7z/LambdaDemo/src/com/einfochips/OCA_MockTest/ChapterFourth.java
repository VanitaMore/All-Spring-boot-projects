package com.einfochips.OCA_MockTest;

public class ChapterFourth {

	String value = "AAA";
	  {/*from w  ww .  j av a  2  s  .  c  o  m*/
	    value += "BBB";
	  }
	  {
	    value += "CCC";
	  }

	  public ChapterFourth() {
	    value += "XXX";
	  }

	  public ChapterFourth(String s) {
	    value += s;
	  }

	  public static void main(String[] args) {
		  ChapterFourth m = new ChapterFourth("QQQ");
	     m = new ChapterFourth();
	    System.out.println(m.value);
	  }
}
