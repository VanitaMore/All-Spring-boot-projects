package com.einfochips.OCA_MockTest;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Month;

public class ChapterThree {

	public static void main(String[] args) {
		/*
		 * StringBuilder sb = new StringBuilder(); sb.append("AAA").insert(1,
		 * "BB").insert(4, "CCCC"); System.out.println(sb);
		 */

		/*
		 * System.out.println(LocalDate.now()); System.out.println(LocalTime.now());
		 * System.out.println(LocalDateTime.now());
		 */

		/*
		 * System.out.println(LocalDate.now()); LocalTime time1 = LocalTime.of(6, 15);
		 * System.out.println(time1);
		 */

		/*
		 * LocalDate time1 = LocalDate.of(2015, Month.JANUARY, 20); LocalDate date2 =
		 * LocalDate.of(2015, 1, 20); System.out.println(time1); LocalDate d = new
		 * LocalDate(0, 0, 0);
		 */
		/*
		 * int my = 4; String v2 = "ABC"; String v = my + 1; System.out.println(v + " "
		 * + v2); System.out.println(my + " " + 1);
		 */

		/*
		 * String s = "ABCD"; s.toUpperCase(); 4from w ww .j av a2s.c o m s.trim();
		 * s.substring(1, 3); s += " two"; System.out.println(s);
		 */
		
		/*
		 * String s = "ABC"; String t = new String(s);
		 * 
		 * if ("ABC".equals(s)) System.out.println("A");
		 * 
		 * if (t == s) System.out.println("B");
		 * 
		 * if (t.equals(s)) System.out.println("C");
		 * 
		 * if ("ABC" == s) System.out.println("D");
		 * 
		 * if ("ABC" == t) System.out.println("E");
		 */
		
		
		/*
		 * String numbers = "012345678"; System.out.println(numbers.substring(1, 3));
		 * System.out.println(numbers.substring(7, 7));
		 * System.out.println(numbers.substring(7));
		 */   
		
		  String a = ""; 
		     System.out.println(a); //from ww w.  j  a  v  a  2s  . c  o m
		     a += 2; 
		     System.out.println(a); 
		     a += 'c'; 
		     System.out.println(a); 
		     a += false;            
		     System.out.println(a);  
		     if ( a == "2cfalse") 
		        System.out.println("=="); 
		     if ( a.equals("2cfalse")) 
		        System.out.println("equals"); 
	}

}
