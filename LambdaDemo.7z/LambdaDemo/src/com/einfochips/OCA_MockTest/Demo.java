package com.einfochips.OCA_MockTest;

public class Demo {
	    
	/*1.
	 * public void myMethod(boolean checked) {
	 * 
	 * if (checked) {
	 * 
	 * } System.out.println(result); String result = "java2s.com"; }
	 */
	
	//2.
	/*
	 * public static void main(String[] args) { short myValue = 5; int myValue2 =
	 * 1.2; String myValue3 = "java2s.com"; myValue.length(); myValue2.length();
	 * myValue3.length(); }
	 */
	
	int count; 
      public void Main() { 
          count = 4; 
       } 
       public static void main(String[] args) { 
         Main s = new Main(); 
         System.out.println(s.count); 
      } 
    }


