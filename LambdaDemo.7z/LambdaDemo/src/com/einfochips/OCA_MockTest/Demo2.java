package com.einfochips.OCA_MockTest;

import java.util.Random;
import java.lang.*;
public class Demo2 {

	public static void main(String[] args) {
		/*
		 * int i1 = 1_234; //double d1 = 1_234_.0; //double d2 = 1_234._0; //double d3 =
		 * 1_234.0_; double d4 = 1_234.0;
		 */
		 Random r = new Random();    
		 System.out.println(r.nextInt(10));
	}
}
