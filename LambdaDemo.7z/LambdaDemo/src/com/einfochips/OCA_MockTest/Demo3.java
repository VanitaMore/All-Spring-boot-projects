package com.einfochips.OCA_MockTest;

public class Demo3 {
	
	private Demo3(){
		System.out.println("hi");
	}
	public static void main(String[] args) {
		Demo3 d= new Demo3();
		
	}
	

}
