package com.einfochips.OCA_MockTest;

public class Example27 {

		public void AAA(String v1, StringBuilder v2) {
		    v1.concat(".");
		    v2.append(".");
		  }

		  public static void main(String[] args) {
		    String v1 = "AAA";
		    StringBuilder v2 = new StringBuilder("AAA");
		    new Example27().AAA(v1, v2);
		    System.out.println(v1 + " " + v2);
	}

}
