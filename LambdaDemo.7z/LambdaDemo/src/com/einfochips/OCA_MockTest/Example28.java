package com.einfochips.OCA_MockTest;

import java.time.LocalDate;
import java.time.Month;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

public class Example28 {

	public static void main(String[] args) {
		/*
		 * LocalDate date = LocalDate.of(2016, Month.APRIL, 30); date.plusDays(2);
		 * date.plusYears(3); System.out.println(date.getYear() + " " + date.getMonth()
		 * + " " + date.getDayOfMonth());
		 */
		
		/*
		 * int total = 0; StringBuilder letters = new StringBuilder("abcdefg"); total +=
		 * letters.substring(1, 2).length(); total += letters.substring(6, 6).length();
		 * total += letters.substring(6, 5).length(); System.out.println(total);
		 */
		
		/*
		 * String [] names = {"A", "B", "C"}; List<String> list = Arrays.asList();
		 * list.set(0, "Z"); System.out.println(list);
		 */
		
		/*
		 * LocalDate date = LocalDate.of(2016, 6, 21); LocalDate.of(2016, Month.JUNE,
		 * 21); LocalDate.of(2016, Calendar.JUNE, 21);
		 */
		
		/*
		 * ArrayList<String> a= new ArrayList<String>(); //a.remove(0); a.add("ab");
		 * 
		 * ArrayList<String> a1= new ArrayList<String>(); //a.remove(0); a1.add("ab");
		 * 
		 * System.out.println(a.equals(a1));
		 */
		
		/*
		 * int[] random = { 16, -41, 112, 10, -110 }; int x = 112; int y =
		 * Arrays.binarySearch(random, x); System.out.println(y);
		 */
		
		/*
		 * List<String> list = new ArrayList<String>(); list.add("A"); list.add("B");
		 * list.add(7); for(String s : list) System.out.print(s);
		 */
		
		
		/*
		 * ArrayList l = new ArrayList(); int length = l.size(); int length =
		 * l.capacity; int length = l.capacity(); int length = l.length; int length =
		 * l.length(); int length = l.size;
		 */
		 
		
		
		
		/*
		 * int[][] scores = new int[15][]; Object[][][] cubbies = new
		 * Object[13][10][51]; java.util.Date[] dates[] = new java.util.Date[12][];
		 * int[][] types = new int[]; int[][] java = new int[][]; String myArray[] = new
		 * myArray[61];
		 */
		
		/*
		 * char[]c = new char[2]; int length = c.length; int length = c.length(); int
		 * length = c.size; int length = c.size(); int length = c.capacity; int length =
		 * c.capacity();
		 */
		
		/*
		 * StringBuilder b = "ABCDEF"; b.append(4).deleteCharAt(3).delete(3, b.length()
		 * - 1); System.out.println(b);
		 */
		
		
		  ArrayList list= new ArrayList();
		  String[] array;
		  try { 
			  while(true) 
			  {
		        
				  list.add("my list"); }
			  }catch(RuntimeException re) {
				  
		  System.out.println("caught runtime exception"); 
		  }
		  
		  catch (Exception e)
		  { 
			  System.out.println("caught  exception");
			  
		  }
		  System.out.println("Ready to use");
		 
		
		/*
		 * System.out.println("5 + 2 = " + 3 + 4); //it treat as a string
		 * System.out.println("5 + 2 = " + (3 + 4));
		 */
				
	}

}
