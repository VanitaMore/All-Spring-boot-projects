package com.einfochips.OCA_MockTest;
import java.util.*; 
public class LambdaExample { 
    
	public static long square(int x) { 
	        long y = x * x; 
	         x = -1; 
	        return y; 
	      } 
	
	public LambdaExample(){
		
	}
	       public static void main(String[] args) { 
	        int value = 6; 
	        long result = square(value); 
	         System.out.println(value); 
	       } 
 } 
	


