package com.einfochips.OCA_MockTest;

public class Line {

	 public static int LENGTH = 5; 
      static {  
         LENGTH = 10; 
      } 
       public static void swing() { 
          System.out.print("swing "); 
      } 
      } 

