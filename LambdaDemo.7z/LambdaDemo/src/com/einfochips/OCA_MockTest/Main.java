package com.einfochips.OCA_MockTest;

public class Main {

	int count; 
    public void Main() { 
        count = 4; 
     } 
   
     public static void main(String[] args) { 
       Main s = new Main(); 
       System.out.println(s.count); 
    } 
}
