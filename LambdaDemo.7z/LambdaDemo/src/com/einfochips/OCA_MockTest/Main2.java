package com.einfochips.OCA_MockTest;

public class Main2 {

	     private static final String v1; 
         private static final String v2; 
         private static final String v3; 
        private static final String v4 = "v4"; 
       static { 
        v1 = "left"; 
         v2 = "right"; 
       } 
       static { 
         v4 = "v4"; 
       v2 = "right"; 
      } 
      public static void main(String[] args) { 
        v3 = "v3"; 
       }
}
