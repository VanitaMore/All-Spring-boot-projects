package com.einfochips.OCA_MockTest;

public class MethodChaining {

	public int howMany(boolean b, boolean... b2) { 
		  return b2.length; 
		}
	public static void main(String[] args) {
		MethodChaining v = new MethodChaining();
		
		System.out.println(v.howMany());
	}

}
