package com.einfochips.OCA_MockTest;

import java.time.LocalDateTime;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class StringExample {

	public static void main(String[] args) {
		/*
		 * String a = ""; System.out.println(a); //from ww w. j a v a 2s . c o m
		 * 
		 * a += 2; System.out.println(a);
		 * 
		 * a += 'c'; System.out.println(a);
		 * 
		 * a += false; System.out.println(a);
		 * 
		 * if ( a == "2cfalse") System.out.println("==");
		 * 
		 * if ( a.equals("2cfalse")) System.out.println("equals");
		 */
		/*
		 * String s1 = "java"; StringBuilder s2 = new StringBuilder("java"); if (s1 ==
		 * s2) //line A System.out.print("1"); if (s1.equals(s2)) System.out.print("2");
		 */

		/*
		 * LocalDateTime d = LocalDateTime.of(2015, 5, 10, 10, 33, 44); Period p =
		 * Period.ofDays(1).ofYears(2); d = d.minus(p); DateTimeFormatter f =
		 * DateTimeFormatter.ofLocalizedDateTime(FormatStyle.SHORT);
		 * System.out.println(f.format(d));
		 */

		/*
		 * LocalDateTime d = LocalDateTime.of(2015, 5, 10, 22, 33, 44); Period p =
		 * Period.of(1, 2, 3); d = d.minus(p); DateTimeFormatter f =
		 * DateTimeFormatter.ofLocalizedTime(FormatStyle.SHORT);
		 * System.out.println(d.format(f));
		 */

		/*
		 * List<Integer> myArrayList = new ArrayList<>();
		 * myArrayList.add(Integer.parseInt("5"));
		 * myArrayList.add(Integer.valueOf("6")); myArrayList.add(7);
		 * myArrayList.add(null); for (int age : myArrayList)
		 * System.out.print(myArrayList);
		 */

		/*
		 * List<String> hex = Arrays.asList("10", "8", "4B", "FF");
		 * Collections.sort(hex); from www . j a v a 2 s . co m System.out.println(hex);
		 */

		/*
		 * int x = Collections.binarySearch(hex, "8"); int y =
		 * Collections.binarySearch(hex, "4B"); int z = Collections.binarySearch(hex,
		 * "4F"); System.out.println(x + " " + y + " " + z);
		 */
		
		
	}

}
