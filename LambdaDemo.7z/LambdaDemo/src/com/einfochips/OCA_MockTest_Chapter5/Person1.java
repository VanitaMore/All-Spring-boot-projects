package com.einfochips.OCA_MockTest_Chapter5;

abstract class Person1 { 
	 
    private void walk() { 
    	System.out.println("Person is walking");
    	} 
    
    public static void main(String[] args) { 
         Person1 p = new Employee(); 
         p.walk(); 
      } 
    } 
     class Employee1 extends Person1 { 
    	 
       protected void walk() {
    	   System.out.println("Employee is walking");
    	   } 
       
     }
