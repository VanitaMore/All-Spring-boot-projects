package com.einfochips.OCA_MockTest_Chapter5;

public interface Printable { 
       void show();
    }