package com.einfochips.OCA_MockTest_Chapter5;

interface Printable1 { 
    abstract int getNumberOfSections(); 
   } 
     abstract class Shape11 implements Printable1 { 
      abstract int getWidth(); 
    } 
    public class Rectangle11 extends Shape11 { 
     int getWidth() { return 6; }

	@Override
	public int getNumberOfSections() {
		// TODO Auto-generated method stub
		return 0;
	} 
     }
