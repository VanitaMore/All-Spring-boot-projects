package com.einfochips.OCA_MockTest_Chapter5;

class Shape22 { 
    public Shape22(int edge) { 
       System.out.print("Shape"); 
    } 
     } 
  public class Rectangle2 extends Shape { 
      public Rectangle2() { 
       System.out.print("Rectangle"); 
    } 
      public static void main(String[] args) { 
        new Shape22(5); 
      } 
     } 
