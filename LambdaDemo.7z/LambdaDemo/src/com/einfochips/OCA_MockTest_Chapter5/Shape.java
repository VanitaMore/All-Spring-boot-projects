package com.einfochips.OCA_MockTest_Chapter5;

interface Printable { 
       public default int getPageNumber(int input) { return 2; } 
     } 

    public class Shape implements Printable { 
    	
       public String getPageNumber()
       { return "4"; 
       } 
      public String getPageNumber(int input) 
      { return "6";
      } 
      
       public static void main(String[] args) { 
       System.out.println(new Shape().getPageNumber(-1)); 
      } 
    } 
