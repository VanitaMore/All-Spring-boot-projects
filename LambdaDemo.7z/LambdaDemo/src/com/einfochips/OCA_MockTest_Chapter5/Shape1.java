package com.einfochips.OCA_MockTest_Chapter5;

abstract class Shape1 { 
       public final void print() { System.out.println("Shape prints");  } 
       
      public static void main(String[] args) { 
        Shape1 shape = new Rectangle11(); 
       shape.print(); 
      } 
     } 
     class Rectangle extends Shape { 
       public void print() { System.out.println("Rectangle prints"); } 
   } 
