package com.einfochips.OCA_MockTest_Chapter5;

public abstract class Shape13 { 
      public abstract void draw() {}; 
      public static void main(String[] args) { 
         Shape13 s = new Rectangle14(); 
      s.draw(); 
     } 
     } 
    class Rectangle14 extends Shape13 { 
      public void draw(int depth) { System.out.println("Rectangle draw"); }

	 
     }
