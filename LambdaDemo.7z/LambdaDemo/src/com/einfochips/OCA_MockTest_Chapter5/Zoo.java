package com.einfochips.OCA_MockTest_Chapter5;

public class Zoo {
	public static void main(String[] args) {
		
		public int indexOf(String[] names, String name) {
			 for (int i = 0; i < names.length; i++) {
			 if (names[i].equals(name)) { return i; }
			 }
			 return -1;
			
		} 
	}

}
