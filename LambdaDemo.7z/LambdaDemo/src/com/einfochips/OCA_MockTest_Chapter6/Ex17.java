package com.einfochips.OCA_MockTest_Chapter6;

public class Ex17 {

	/*
	 * public static void main(String[] args) { try { System.out.println("AAA"); }
	 * catch ( StackOverflowError e) { } catch (RuntimeException e) { } }
	 */
    public void go() {
		    System.out.print("A");
		    try {// w  w w . j  a  va 2 s .c  o  m
		      stop();
		    } catch (ArithmeticException e) {
		      System.out.print("B");
		    } finally {
		      System.out.print("C");
		    }
		    System.out.print("D");
		  }

		  public void stop() {
		    System.out.print("E");
		    String x = null;
		    x.toString();
		    System.out.print("F");
		  }
		  public static void main(String[] args) {
		    new Ex17().go();
		  }
}

