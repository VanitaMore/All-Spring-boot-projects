package com.einfochips.OCA_MockTest_Chapter6;

public class Ex18 {
	
	public void go() {
	    System.out.print("A");
	    try {
	      stop();
	    } catch (ArithmeticException e) {
	      System.out.print("B");
	    } finally {
	      System.out.print("C");
	    }
	    System.out.print("D");
	  }

	  public void stop() {
	    System.out.print("E");
	    String x = null;
	    x.toString();
	    System.out.print("F");
	  }
	  public static void main(String[] args) {
	    new Ex18().go();
	  }

}
