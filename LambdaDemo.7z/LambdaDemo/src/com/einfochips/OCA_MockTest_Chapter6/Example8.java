package com.einfochips.OCA_MockTest_Chapter6;

public class Example8 {
	
	/*
	 * public String name; //from w w w .jav a 2s . co m public void parseName() {
	 * System.out.print("1"); try { System.out.print("2"); int x =
	 * Integer.parseInt(name); System.out.print("3"); } catch (NullPointerException
	 * e) { System.out.print("4"); } }
	 * 
	 * public static void main(String[] args) { Example8 r = new Example8(); r.name
	 * = "4322"; r.parseName(); System.out.print("5"); }
	 */
	
	public static void main(String[] args) {
		int a = 0;
        int b = 0;
         try { 
           return a / b; 
        } catch (RuntimeException e) { 
         return -1; 
        } catch (ArithmeticException e) { 
          return 0; 
        } finally { 
      System.out.print("done"); 
	}
	}
	}


