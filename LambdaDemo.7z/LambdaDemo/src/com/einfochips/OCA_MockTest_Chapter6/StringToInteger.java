package com.einfochips.OCA_MockTest_Chapter6;

public class StringToInteger {

	public static void main(String[] args) {
		String s= "fdsdg";
		int num=Integer.parseInt(s);
		System.out.println(num);
		
	}

}
