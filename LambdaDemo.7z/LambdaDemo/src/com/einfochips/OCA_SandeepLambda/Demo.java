package com.einfochips.OCA_SandeepLambda;


/*interface Interf1 {

	public void methodOne();
}

public class Demo implements Interf1 {

	public void methodOne() {

		System.out.println("method one executio");
	}

	public static void main(String[] args) {
		Interf1 i = new Demo();
		i.methodOne();
	}

}*/

interface Interf {
	public void methodOne();
	}

	public class Demo {
		
		public static void main(String[] args) {
			Interf i = () ->System.out.println("MethodOne Execution"); 
			i.methodOne();  
			}
		}


