package com.einfochips.OCA_Test3;

class A
{
	public A()
	{
		System.out.print("A");
	}
}
class B extends A
{
	public B()
	{
		//line-1
		System.out.print("B");
	}
}
class C extends B
{
	public C()
	{
		//line-2
		System.out.print("C");
	}
	public static void  main(String[] args)
	{
		C c = new C();
	}
}
