package com.einfochips.OCA_Test3;

public class CheckingAccount {

	public int amount;
	public  CheckingAccount()
	{
		//this.amount=100;
		//line-1
	}


	public static void main(String[] args) {
		CheckingAccount acct= new CheckingAccount();
		acct.amount=100;
		System.out.println(acct);
	}
}
