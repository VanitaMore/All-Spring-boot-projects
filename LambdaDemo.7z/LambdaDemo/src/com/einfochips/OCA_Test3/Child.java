package com.einfochips.OCA_Test3;

abstract class Parent
{
	protected void resolve()//Line-1
	{
	}
	abstract void rotate();//Line-2
}
class Child extends Parent
{
	 void resolve()//Line-3
	{
	}
	protected void rotate()//Line-4
	{
	}
}
