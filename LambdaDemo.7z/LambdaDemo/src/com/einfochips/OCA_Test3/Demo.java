package com.einfochips.OCA_Test3;

public abstract class Demo {
	public  void m();

}
