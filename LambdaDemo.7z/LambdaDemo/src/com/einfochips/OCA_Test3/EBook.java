package com.einfochips.OCA_Test3;

interface Writable
{
	public void writeBook();
	public void setBookMark();
}
abstract class Book implements Writable //Line-1
{
	public void writeBook();
	//Line-2
	public abstarct void setBookMark();
}
class EBook extends Book  //Line-3
{
	public void writeBook(){}
	//Line-4

	
}
