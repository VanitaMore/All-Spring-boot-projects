package com.einfochips.OCA_Test3;

public abstract class Example14 {

	public abstract void m1() {}
	public abstract void m2();
}
