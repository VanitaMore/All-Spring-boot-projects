package com.einfochips.OCA_Test3;

public class Example15 {
	/*
	 * public static void main(String[] args) { Short s1 = 200; Integer s2= 400;
	 * Long s3 = (long)s1+s2;//Line-1 Long s4 = (Long)(s3*s2);//Line-2
	 * System.out.println(s3); }
	 */

	public static void sum(Integer x,Integer y)
	{
		System.out.println("Integer sum is:"+(x+y));
	}
	public static void sum(double x,double y)
	{
		System.out.println("double sum is:"+(x+y));
	}

	/*
	 * public static void sum(float x,float y) {
	 * System.out.println("float sum is:"+(x+y)); }
	 */
	/*
	 * public static void sum(int x,int y) {
	 * System.out.println("int sum is:"+(x+y)); }
	 */
	public static void main(String[] args)
	{
		sum(10,20);
		sum(10.0,20.0);
	}
}
