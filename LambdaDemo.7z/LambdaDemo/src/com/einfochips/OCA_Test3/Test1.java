package com.einfochips.OCA_Test3;

public class Test1 {

	/*
	 * public void a(){
	 * 
	 * final int a; } int a;
	 */
	
	public static void main(String[] args) {
		String[] s={"A","B","C","D"};
		for(int i =0; i<s.length;i++)
		{
			System.out.print(s[i]+" ");
			if (s[i].equals("C"))
			{
				continue;
			}
			System.out.println("Done");
			break;
		}
	}

}
