package com.einfochips.OCA_Test3;

class Animal
{
	String type="Canine";
	int maxSpeed=60;
	Animal(){}
	Animal(String type,int maxSpeed)
	{
		this.type=type;
		this.maxSpeed=maxSpeed;
	}
}
class WildAnimal extends Animal
{
	String bounds;
	WildAnimal(String bounds)
	{
		//line-1
	}
	WildAnimal(String type,int maxSpeed,String bounds)
	{
		//line-2
		super();
		this.bounds=bounds;
	}
}
