package com.einfochips.UdemyTest4_1;

import java.util.ArrayList;

public class Bunny {

	public static void main(String[] args) {
		/*
		 * ArrayList<String> l= new ArrayList<String>(); l.add("Robb"); l.add("Bran");
		 * l.add("Rick"); l.add("Bran"); l.add("gg");
		 * 
		 * if(l.remove("Bran")){
		 * 
		 * l.remove("Rick"); } System.out.println(l); //[Robb, Rick, Bran, gg]
		 */	
		
	

		static double area;
		int b=30,h=40;
		public static void main(String[] args) 
		{
			double p,b,h;// Line-1
			if(area ==0)
			{
				b=3;
				h=4;
				p=0.5;
			}
			area=p*b*h;// Line-2
			System.out.println(area);
		}
	}

}
