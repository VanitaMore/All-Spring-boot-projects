package com.einfochips.UdemyTest4_1;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.Month;

public class DateExample {

	public static void main(String[] args) {
		/*
		 * LocalDate date1 = LocalDate.of(2015, Month.JANUARY, 20); LocalDate date2 =
		 * LocalDate.of(2015, 1, 20);
		 * 
		 * LocalDate d= LocalDate.of(2000, 7, 7);
		 * 
		 * LocalTime time1 = LocalTime.of(6, 15); // hour and minute LocalTime time2 =
		 * LocalTime.of(6, 15, 30); // + seconds LocalTime time3 = LocalTime.of(6, 15,
		 * 30, 200); System.out.println(time1+" "+time2+""+time3);
		 */
		
		//LocalDate d2 = new LocalDate(); 
		//LocalDate.of(2015, Month.JANUARY, 32) ;
		
		 LocalDate date = LocalDate.of(2014, Month.JANUARY, 20);
		  System.out.println(date); // 2014-01-20
		  date = date.plusDays(2);
		  System.out.println(date); // 2014-01-22
		  
		  date = date.plusWeeks(1);
		  System.out.println(date); // 2014-01-29
		  
		 date = date.plusMonths(1);
		   System.out.println(date); // 2014-02-28
		   
		   date = date.plusYears(5);
		   System.out.println(date); 
		   
		   LocalDate date4= LocalDate.of(2020, Month.JANUARY, 20);
		   date4.plusDays(10);
		   System.out.println(date4);
		   
		   LocalDate dat = LocalDate.of(2020, Month.JANUARY, 20);
		   date = dat.plusMinutes(1); 
		  
	}

}
