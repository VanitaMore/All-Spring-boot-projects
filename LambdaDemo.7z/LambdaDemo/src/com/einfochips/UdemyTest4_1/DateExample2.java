package com.einfochips.UdemyTest4_1;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Month;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;

public class DateExample2 {

	public static void main(String[] args) {
		/*
		 * LocalDate date = LocalDate.of(2015, 1, 20); LocalTime time = LocalTime.of(6,
		 * 15); LocalDateTime dateTime = LocalDateTime.of(date, time); Period period =
		 * Period.ofMonths(1); System.out.println(date.plus(period)); // 2015-02-20
		 * System.out.println(dateTime.plus(period)); // 2015-02-20T06:15
		 * System.out.println(time.plus(period));
		 * 
		 * Period p=Period.ofMonths(5);
		 */
		 
		/*
		 * LocalDate date = LocalDate.of(2019, Month.JUNE, 29);
		 * System.out.println(date.getDayOfWeek()); // MONDAY
		 * System.out.println(date.getMonth()); // JANUARY
		 * System.out.println(date.getYear()); // 2020
		 * System.out.println(date.getDayOfYear());
		 */
		 
		LocalDate date = LocalDate.of(2020, Month.JANUARY, 20);
		LocalTime time = LocalTime.of(11, 12, 34);
		LocalDateTime dateTime = LocalDateTime.of(date, time);
		
		System.out.println(date.format(DateTimeFormatter.ISO_LOCAL_DATE));
		System.out.println(time.format(DateTimeFormatter.ISO_LOCAL_TIME));
		System.out.println(dateTime.format(DateTimeFormatter.ISO_LOCAL_DATE_TIME));
		
		DateTimeFormatter shortDateTime =DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM);
		System.out.println(shortDateTime.format(dateTime)); // 1/20/20
		System.out.println(shortDateTime.format(date)); // 1/20/20
		//System.out.println(shortDateTime.format(time)); 
		
		/*
		 * DateTimeFormatter shortDateTime
		 * =DateTimeFormatter.ofLocalizedDate(FormatStyle.SHORT);
		 * System.out.println(dateTime.format(shortDateTime));
		 * System.out.println(date.format(shortDateTime));
		 * System.out.println(time.format(shortDateTime));
		 */
		
		DateTimeFormatter f = DateTimeFormatter.ofPattern("MM dd yyyy");
		LocalDate date44 = LocalDate.parse("01 02 2015", f);
		LocalTime time44 = LocalTime.parse("11:22");
		System.out.println(date44); // 2015-01-02
		System.out.println(time44); // 11:22
	}

}
