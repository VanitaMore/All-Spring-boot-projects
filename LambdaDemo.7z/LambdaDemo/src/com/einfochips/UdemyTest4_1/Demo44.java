package com.einfochips.UdemyTest4_1;

public class Demo44 {

	int count;
	public static void display()
	{
		count++;//Line-1
		System.out.println("Welcome Visit Count:"+count);//Line-2
	}
	public static void main(String[] args)
	{
		Demo44.display();//Line-3
		Demo44.display();//Line-4	
	}
	}
	
  

