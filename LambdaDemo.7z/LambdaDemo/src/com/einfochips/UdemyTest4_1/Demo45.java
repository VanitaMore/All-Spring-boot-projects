package com.einfochips.UdemyTest4_1;

public class Demo45 {

	int x;
	int y;
	public void doStuff(int x,int y)
	{
		this.x=x;
		y=this.y;
	}
	public void print()
	{
		System.out.print(x+":"+y+":");
	}
	public static void main(String[] args) 
	{
		Demo45 t1=new Demo45();
		t1.x=100;
		t1.y=200;
 
		Demo45 t2 = new Demo45();
		t2.doStuff(t1.x,t1.y);
		t1.print();
		t2.print();
	}
}
