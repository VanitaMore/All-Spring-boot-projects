package com.einfochips.UdemyTest4_1;

public class Dummy {

	public static void main(String[] args) {
		/*
		 * int n[] = new int[2]; int n1[]; n= new int[2]; n[0]=10; n[1]=20;
		 * 
		 * for(int a:n) { System.out.println(" "+a); }
		 */
		
		
		/*
		 * System.out.println( 4+5); System.out.println("Result B:"+ (4+5));
		 */
		

		String color="Blue";
		switch(color)
		{
			case "Red":
				System.out.println("Red");
			case "Blue":
				System.out.println("Blue");
			        break;
			case "Green":
				System.out.println("Green");
			        //break;
			default:
				System.out.println("Default");
		}
	}

}
