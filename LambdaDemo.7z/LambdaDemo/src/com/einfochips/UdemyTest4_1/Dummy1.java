package com.einfochips.UdemyTest4_1;

public class Dummy1 {

	
	public static final int MIN=1;
	public static void main(String[] args) 
	{
		/*
		 * String s="Color"; String result=null; if(s.equals("Color")) { result="Blue";
		 * } else if(s.equals("Wall")) { result="Regular"; } else { result="No Result";
		 * } System.out.println(result);
		 */
		
		/*
		 * int[] data={10,20,30,40,50,30}; int k= 30; int count=0; for(int x : data) {
		 * if( x!= k) { continue;
		 * 
		 * } count++; } System.out.println(count);
		 */
		
		/*
		 * int[] x= {1,2,3,4}; int i =0; do { System.out.print(x[i]+" "); i++; } while
		 * (i<x.length);
		 */
		int a[][]= {{10,20,30},{4,3,5}};
		for(int b[]:a)
		{
			for(int c:b)
			{
				System.out.print(c+" ");
			}
			System.out.println();
		}
		
		/*
		 * int[][] x = new int[2][4]; x[0]= new int[]{2,4,6,8}; x[1]= new int[]{2,4};
		 * for(int[] x1: x) { for(int x2 :x1) { System.out.print(x2+" "); }
		 * System.out.println(); }
		 */
	}
}
