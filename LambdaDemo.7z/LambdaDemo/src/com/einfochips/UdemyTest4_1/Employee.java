package com.einfochips.UdemyTest4_1;

public class Employee {

	String name;
	boolean contract;
	double salary;
	Employee()
	{
		this.name=new String("ads");
		this.contract=new Boolean(true);
		this.salary=new Double(23.9f);
		//line-1
	}
	public String toString()
	{
		return name+":"+contract+":"+salary;
	}
	public static void main(String[] args)
	{
		Employee e = new Employee();
		//Line-2
		System.out.println(e);
	}
}
