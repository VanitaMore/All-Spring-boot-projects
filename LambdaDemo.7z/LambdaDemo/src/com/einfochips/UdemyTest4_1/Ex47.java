package com.einfochips.UdemyTest4_1;

public class Ex47 {
	
	public static void main(String[] args) {
		/*
		 * int[][] x = new int[2][4]; x[0]= new int[]{2,4,6,8}; x[1]= new int[]{2,4};
		 * for(int[] x1: x) { for(int x2 :x1) { System.out.print(x2+" "); }
		 * System.out.println(); }
		 */
		
		String[][] colors=new String[2][2];
		colors[0][0]="red";
		colors[0][1]="blue";
		colors[1][0]="green";
		colors[1][1]="yellow";
	}

}
