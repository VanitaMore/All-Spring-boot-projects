package com.einfochips.UdemyTest4_1;

public class Example15 {

	public static void main(String[] args) {
		/*
		 * int x =100; int a = x++; int b = ++x; int c =x++; int
		 * d=(a<b)?(a<c)?a:(b<c)?b:c; System.out.println(d);
		 */
		
		/*
		 * String[][] colors=new String[2][2]; colors[0][0]="red"; colors[0][1]="blue";
		 * colors[1][0]="green"; colors[1][1]="yellow";
		 */
		
		/*
		 * int[] x = {10,20,30,40,50}; for(int i=0:x) { System.out.print(x[i]+" "); }
		 */
		
		int x =10;
		final int y =20;
		switch(x+1)//Line-1
		{
			case 10:
				System.out.println(10);
			case y://Line-2
				System.out.println(20);
			        break;
			case 11:
				System.out.println(11);
		}
	}

}
