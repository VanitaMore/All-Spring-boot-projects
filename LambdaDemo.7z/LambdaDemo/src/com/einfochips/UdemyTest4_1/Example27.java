package com.einfochips.UdemyTest4_1;

public class Example27 {

	public static void main(String[] args) {
		try
		{
			int n=10;
			int d=0;
			int ans=n/d;
		}
		catch (ArithmeticException e)
		{
			System.out.println("sdf");
		}
		catch(Exception e)
		{
			System.out.println("Invalid Calculation");
		}
		//System.out.println("Answer="+ans);//Line-2
	}

}
