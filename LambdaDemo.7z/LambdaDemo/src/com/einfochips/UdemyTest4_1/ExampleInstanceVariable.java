package com.einfochips.UdemyTest4_1;

public class ExampleInstanceVariable {
	
	static int a=10;
	int b=20;

	public static void main(String[] args) {
		ExampleInstanceVariable v= new ExampleInstanceVariable();
		System.out.println(a);
	}

}
