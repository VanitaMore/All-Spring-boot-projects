package com.einfochips.UdemyTest4_1;

public class ExampleLocalVariable {

	/*
	 * static double area; int b=30,h=40; public static void main(String[] args) {
	 * double p=1,b=2,h=3;// Line-1 if(area ==0) { b=3; h=4; p=0.5; } area=p*b*h;//
	 * Line-2 System.out.println(area); }
	 */
	
	/*
	 * int count; public static void display() { count++;//Line-1
	 * System.out.println("Welcome Visit Count:"+count);//Line-2 } public static
	 * void main(String[] args) { ExampleLocalVariable.display();//Line-3
	 * ExampleLocalVariable.display();//Line-4 }
	 */
	
	/*
	 * public static void main(String[] args) { int x=1; if (args.length>0) { x=10;
	 * } System.out.println(x); }
	 */
	
	

}
