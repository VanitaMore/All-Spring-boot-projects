package com.einfochips.UdemyTest4_1;

interface Animal 
{ public  abstract String getName();

}
interface Mammal {
	public abstract String getName(); 
	
	}
abstract class Otter implements Mammal, Animal {}
