package com.einfochips.UdemyTest4_1;


	 class Mammal67 {
		 
		 public Mammal67(int age) {
		  System.out.print("Mammal");
		 }
	 }
		   class Platypus extends Mammal67 {
		  public Platypus() {
		  System.out.print("Platypus");
		  }
		  public static void main(String[] args) {
		  new Mammal67(5);
		  }
		   }
	 

