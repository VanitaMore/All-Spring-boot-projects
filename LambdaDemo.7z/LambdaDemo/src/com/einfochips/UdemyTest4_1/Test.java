package com.einfochips.UdemyTest4_1;

import java.io.IOException;

class X 
{
	public void printFileContent() throws IOException
	{
		throw new IOException();//Line-1
	}
}
public class Test
{
	public static void main(String[] args) throws IOException//Line-2
	{
		X x= new X();
		x.printFileContent();//Line-3
		//Line-4
		
	}
}
