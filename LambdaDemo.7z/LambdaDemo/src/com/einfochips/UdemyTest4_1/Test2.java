package com.einfochips.UdemyTest4_1;

public class Test2 {

	public static void main(String[] args) {
		/*
		 * int n[]; n= new int[2]; n[0]=100; n[1]=200;
		 * 
		 * n = new int[4]; n[2]=300; n[3]=400;
		 * 
		 * for(int x : n) { System.out.print(" "+x); }
		 */
		
		/*
		 * System.out.println("Result A:"+ 4+5); System.out.println("Result B:"+
		 * (4)+(5));
		 */
		
		
	}

}
