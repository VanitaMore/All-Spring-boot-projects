package com.einfochips.UdemyTest4_1;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public class Test22 {
	

		/*
		 * String
		 * date=LocalDate.parse("2014-05-04").format(DateTimeFormatter.ISO_DATE_TIME);
		 * System.out.println(date);
		 */
		
		/*
		 * String s1="123"; String s2="drgdf"; Integer i1=Integer.parseInt(s1); Boolean
		 * b1= Boolean.parseBoolean(s2); System.out.println(i1+".."+b1);
		 * 
		 * int i2= Integer.valueOf(s1); boolean b2=Boolean.valueOf(s2);
		 * System.out.println(i2+".."+b2);
		 */
		

		/*
		 * String s="HelloWorld"; s.trim(); int i1=s.indexOf(" ");
		 * System.out.println(i1);
		 */
		
		
		public class MyException extends RuntimeException
		{
		}
		 
		public class Test
		{
			public static void main(String[] args)
			{
				try
				{
					m1();
				}
				catch (MyException e)
				{
					System.out.print("A");
				}
			}
			public static void m1()
			{
				try
				{
					throw Math.random() > 0.5 ? new Exception():new MyException();
				}
				catch (RuntimeException e)
				{
					System.out.println("B");
				}
			}
		}
	}
	
	

