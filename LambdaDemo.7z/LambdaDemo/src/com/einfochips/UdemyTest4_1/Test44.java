package com.einfochips.UdemyTest4_1;

public class Test44 {

	public static void main(String[] args) {
		CheckingAccount acct=new CheckingAccount((int)(Math.random()*1000));
		acct.changeAmount(acct.getAmount());;
		System.out.println(acct.getAmount());
	}

}
