package com.einfochips.UdemyTest4_1;

public abstract class Whale {

	public abstract void dive();
	 public static void main(String[] args) {
 //Whale whale = new Orca();
	 //System.out.println(new Orca.d);
	 }
}
class Orca extends Whale {
 public void dive(int depth) { System.out.println("Orca diving"); }

@Override
public void dive() {
	System.out.println("jnk");
}
}