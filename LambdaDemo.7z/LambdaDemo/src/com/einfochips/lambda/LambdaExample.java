package com.einfochips.lambda;

public class LambdaExample{

	public static void main(String[] args) {
			
		  MyInterface mylambda =(int text,int text2)-> text2;
		           
			                       
				  
		int a=  mylambda.apply(1,3);
		 
		 System.out.println(a);
		
		//Anonymous inner class
		
		/*
		 * MyInterface obj = new MyInterface() {
		 * 
		 * @Override public void apply() { System.out.println("hello anonymous lambda");
		 * }
		 * 
		 * @Override public void apply1() {
		 * System.out.println("hello anonymous lambda"); }
		 * 
		 * };
		 * 
		 * obj.apply(); obj.apply1();
		 */
		 
	}

	/*
	 * @Override public void apply() { System.out.println("hjnkjki"); }
	 */
}
