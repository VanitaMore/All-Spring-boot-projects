package com.einfochips.lambda;

public interface MyInterface {
	
	public int apply(int text, int text2);
	//public void apply1();
	 
	

}
