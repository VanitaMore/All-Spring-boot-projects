package com.einfochips.lambdaDemo2;

/*
 * public class LambdaExample implements MyInterface1 {
 * 
 * @Override public void show() { System.out.println("Hello Lambda Expression");
 * }
 * 
 * public static void main(String[] args) { LambdaExample obj = new
 * LambdaExample(); obj.show(); }
 * 
 * }
 */

//By Using Anonymous inner class

/*
 * class LambdaExample { public static void main(String[] args) { MyInterface1
 * obj= new MyInterface1() {
 * 
 * @Override public void show() { System.out.println("Hello Lambda"); }
 * 
 * }; obj.show(); } }
 */

//By Using Lambda Expression
class LambdaExample { 
	public static void main(String[] args) 
	{ 
	  MyInterface1 obj= ()-> System.out.println("Hello Lambda Expression");
	  obj.show();
	  }
	}
	 

