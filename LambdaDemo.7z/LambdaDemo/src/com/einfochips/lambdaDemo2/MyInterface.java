package com.einfochips.lambdaDemo2;

 interface MyInterface1 {

	 public void show();
}
