package com.einfochips.model;

import java.util.ArrayList;

public class ArraayListExample {

	public static void main(String[] args) {
		ArrayList<Integer> al= new ArrayList<>();
		al.add(12);
		al.add(16);
		al.add(17);
		al.add(124);
		al.add(20);
		
		/*
		 * for(Integer i:al) {
		 * 
		 * 
		 * al.add(50); System.out.println(i); }
		 */
		al.forEach(n->System.out.println(n));
		
	}

}
