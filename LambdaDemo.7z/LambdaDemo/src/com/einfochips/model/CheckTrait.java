package com.einfochips.model;

public interface CheckTrait {
	
	boolean test(Animal a);

}
