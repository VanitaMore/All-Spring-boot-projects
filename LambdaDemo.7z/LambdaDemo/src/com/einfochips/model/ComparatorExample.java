package com.einfochips.model;

import java.util.Comparator;

public class ComparatorExample {
	public static void main(String[] args) {


		Comparator<String> comp = new Comparator<String>() {

			@Override
			public int compare(String o1, String o2) {
				return o1.compareTo(o2);
			}

		};
		/*
		 * int comparison=comp.compare("hello", "world");
		 * System.out.println(comparison);
		 */
		Comparator<String> stringLambda = (String o1,String o2)-> {
			return o1.compareTo(o2); 
			};

		int comparisonlambda=comp.compare("hello", "world");
		System.out.println(comparisonlambda);

	}
}
