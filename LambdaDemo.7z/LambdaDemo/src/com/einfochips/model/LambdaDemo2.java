package com.einfochips.model;

import java.util.ArrayList;

public class LambdaDemo2 {

	interface Game{
		void play();
	}
	interface Game2{
		void show();
	}
	
	public static void main(String[] args) {
     
		Game football = new Game()
		{
			public void play()
			{
				System.out.println("I am playing football");
			}
			
		};
		football.play();
		
		ArrayList<String> player= new ArrayList<String>();
		player.add("sachin");
		player.add("rahul");
		player.add("kohli");
		player.add("dravid");
		player.add("gaguli"); 
		
		/*
		 * for(String all: player) { if(all.equals("kohli")) {
		 * System.out.println("yes kohli is present"); }
		 * 
		 * }
		 */
		
		
		player.forEach(n->{ if(n.equals("sa"))
			System.out.println("yes kohli is present");
		});
		
		Game2 g= ()->System.out.println("game2");
		g.show();
		
	}
		
	}


