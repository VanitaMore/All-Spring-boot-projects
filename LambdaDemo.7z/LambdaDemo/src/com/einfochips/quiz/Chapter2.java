package com.einfochips.quiz;

public class Chapter2 {
	public static void main(String[] args) {
	  final char a = 'A', d = 'D'; 
      char grade = 'B'; 
      switch(grade) { 
      case  a: 
       case 'B': System.out.print("B"); 
       case 'C': System.out.print("C"); break; 
       case  d: 
      case 'F': System.out.print("F"); 
     } 
	}

}
