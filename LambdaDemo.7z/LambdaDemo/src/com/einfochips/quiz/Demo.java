package com.einfochips.quiz;

public class Demo {
	public static void main(String[] args) {
		
		/*
		 * try { int abc[]= new int[10]; System.out.println(abc[11]);
		 * 
		 * } catch(ArrayIndexOutOfBoundsException e)
		 * 
		 * { System.out.println("oops identified exception::"+e);
		 * 
		 * }
		 */
		 
		/*
		 * int array[]= new int[-2]; System.out.println(array);
		 */
		/*
		 * java.util.List<Integer> list = new java.util.ArrayList<Integer>();
		 * list.add(1); list.add(2); for(int x : list) { System.out.print(x + ", ");
		 * break; }
		 */
		//int array[]= new int[10]; 
		
		/*
		 * int[][] myComplexArray = {{5,2,1,3},{3,9,8,9},{5,7,12,7}}; for(int[]
		 * mySimpleArray : myComplexArray) { for(int i=0; i<mySimpleArray.length; i++) {
		 * System.out.print(mySimpleArray[i]); } System.out.println(); }
		 */
		
		/*
		 * int x = 5; System.out.println(x < 2 ? x > 4 ? 10 : 8 : 7);
		 */
		
		/*
		 * int x = 1, y = 5; while (x < 8) { y--; x++; } System.out.println(x+", "+y);
		 */
		
		/*
		 * byte a = 40, b = 50; byte sum = (byte) (a + b); System.out.println(sum);
		 */
		
		for(int i=0; i<10 ;i++ ) { 
 
		       System.out.println("Hello World"); 
		    } 
	}

}
