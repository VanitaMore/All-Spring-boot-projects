package com.example.demo.service;

import com.example.demo.model.user.User;

public interface UserService {

	User insertUser(User user);
	

}
