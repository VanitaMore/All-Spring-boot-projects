package com.einfochips.Accenture;

public class ExampleThread extends Thread {

	public void start() {

		System.out.println("start");
	}

	public void run() {
		System.out.println("run");
	}

	public static void main(String[] args) {
		ExampleThread t = new ExampleThread();
		t.start();
		t.run();

	}

}
