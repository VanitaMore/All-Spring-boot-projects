package com.einfochips.Accenture;

public class Test {

	public static void main(String[] args) {
		Thread t=Thread.currentThread();
		System.out.println(t);

	}

}
