package com.einfochips.Accenture;

public final class Test2 {

	public static void main(String[] args) {
		Test2 t=new Test2();
		System.out.println(t);

	}

}
