package com.einfochips.Capgemini;
class A{
	public int x=4;
	
	public void hello() {
		System.out.println("hello");
		
	}
}
class B extends A{
	public int x=8;
	public void hello() {
		System.out.println("helli from b");
	}
}
public class Test {
public static void main(String[] args) {
	 A t=new B();
	 System.out.println(t.hello());
	 
	 
}
	
	 
}
