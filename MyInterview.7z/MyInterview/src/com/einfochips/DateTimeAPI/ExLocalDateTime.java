package com.einfochips.DateTimeAPI;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;

public class ExLocalDateTime {

	public static void main(String[] args) {
		//LocalDateTime d=LocalDateTime.of(1992, 02, 22, 12, 59);
		//System.out.println(d.plusMonths(6));
		
		LocalDate birthday=LocalDate.of(1991, 10, 13);
		LocalDate today=LocalDate.now();
		
		Period p=Period.between(birthday, today);
		System.out.println(p.getYears()+" "+p.getMonths()+" "+p.getDays());
	}

}
