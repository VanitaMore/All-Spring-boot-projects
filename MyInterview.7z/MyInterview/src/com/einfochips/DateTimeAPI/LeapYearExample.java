package com.einfochips.DateTimeAPI;

import java.time.Year;
import java.util.Scanner;

public class LeapYearExample {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("enter no.");
        int num=s.nextInt();
        Year y=Year.of(num);
        if(y.isLeap()) {
        	System.out.println("year is leap year");
        }else {
        	System.out.println("year is not leap year");
        }
	}

}
