package com.einfochips.DefaultMethod;

public interface MyInterface {
	
 	  default void m1() {
		System.out.println("parent1");
		
	}
	
}
