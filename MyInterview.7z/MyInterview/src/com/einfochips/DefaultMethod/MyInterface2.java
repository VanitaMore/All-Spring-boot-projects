package com.einfochips.DefaultMethod;

public interface MyInterface2 {

	default void m1() {
		System.out.println("parent2");
	}
}
