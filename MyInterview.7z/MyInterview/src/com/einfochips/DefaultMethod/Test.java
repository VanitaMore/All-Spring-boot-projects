package com.einfochips.DefaultMethod;

public class Test implements MyInterface,MyInterface2 {

	public static void main(String[] args) {
		Test t = new Test();
		t.m1();

	}

	@Override
	public void m1() {
		
		MyInterface.super.m1();
	}


}
