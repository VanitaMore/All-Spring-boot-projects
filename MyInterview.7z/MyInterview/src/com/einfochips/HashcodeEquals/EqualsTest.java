package com.einfochips.HashcodeEquals;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class EqualsTest {
	public static void main(String[] args) {
		Employee e1 = new Employee(2);
		Employee e2 = new Employee(2);

		// e1.setId(100);
		// e2.setId(100);
		System.out.println(e1.hashCode() + " " + e2.hashCode());
		System.out.println(e1.equals(e2)); // false

		Set<Employee> employees = new HashSet<Employee>();
		employees.add(e1);
		employees.add(e2);

		System.out.println("hashset size is " + employees.size()); // Prints two objects
		System.out.println("hashset element present "+employees.contains(new Employee(2)));

		ArrayList<Employee> empList = new ArrayList<Employee>();
		empList.add(e1);
		empList.add(e2);
		System.out.println("arraylist size is " + empList.size());

		System.out.println(" element is contain " + empList.contains(new Employee(2)));
	}

}
