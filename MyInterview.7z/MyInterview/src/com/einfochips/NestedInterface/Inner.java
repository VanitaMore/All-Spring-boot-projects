package com.einfochips.NestedInterface;

public class Inner implements sample.myInterface {
		public void demo() {
			System.out.println("Welcome to Tutorialspoint");
		}
	    public void display() {
	    	System.out.println("dispaly");
	    }

	public static void main(String args[]) {
		Inner obj = new Inner();
		obj.demo();
		obj.display();
	}
}
