package com.einfochips.NestedInterface;

interface sample {

	 void display(); 
	interface myInterface {
		void demo();
	}
}
