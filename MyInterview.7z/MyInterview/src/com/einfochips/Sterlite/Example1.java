package com.einfochips.Sterlite;

public class Example1 {

	public static void main(String[] args) {
		int MAX=5;
		int i,j;
		int a[][]=new int [MAX][MAX],b[]=new int [MAX*MAX];
		for(j=0;j<MAX;j++)
			for(i=0;i<MAX;i++)
				a[i][j]=i+j;
		
		for(i=4;i>=0;i--)
			for(j=4;j>=0;j--)
				b[MAX*i+j]=a[i][j];
		
		for(i=0;i<MAX*MAX;i++)
			System.out.println(b[i]+" ");

	}

}
