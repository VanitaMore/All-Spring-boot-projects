package com.einfochips.StreamExamples;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class EmployeeTest {

	public static void main(String[] args) {
		ArrayList<Employee> al=new ArrayList<Employee>();
		
		al.add(new Employee(2,"vanita",344323));
		al.add(new Employee(1,"anita",100));
		al.add(new Employee(32,"sandy",4364576));
		al.add(new Employee(62,"poo",2000));
		al.add(new Employee(6,"anita",600));
		
		List<Employee> al2=al.stream().filter(a->a.getSalary()>1000).collect(Collectors.toList());
		//System.out.println(al2);
		
		al.stream().sorted().limit(3).forEach(System.out::println);
		
		LocalDate d=LocalDate.now();
		//System.out.println(d.getDayOfYear());
		
		int date=d.getDayOfMonth();
		//System.out.println(date);
		
		Map<Object, List<Employee>> collect = al.stream().collect(Collectors.groupingBy(a->a.getName()));
		//System.out.println(collect);
	}

}
