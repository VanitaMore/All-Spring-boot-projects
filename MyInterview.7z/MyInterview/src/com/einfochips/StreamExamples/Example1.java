package com.einfochips.StreamExamples;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Example1 {

	public static void main(String[] args) {
		String[] str= {"vanita","guddi","abc","java","sandeep","abc"};
		//Stream.of(str).sorted().forEach(System.out::println);
		///Stream.of(str).filter(a->a.startsWith("s")).forEach(System.out::print);
        
		Stream<String> streamarray = Stream.of(str);
		//streamarray.filter(a->(!a.startsWith("s"))).collect(Collectors.toList()).forEach(System.out::println);
		streamarray.distinct().forEach(System.out::println);
		
	//	streamarray.filter(c->c.startsWith("d")).forEach(System.out::print);
		Stream<Integer> stream = Stream.of(54,63,6,2,5,6,7,8,9,10);
		//stream.filter(e->e%2==0).forEach(System.out::print);
		//stream.forEach(System.out::print);
	}

}
