package com.einfochips.StreamExamples;

import java.util.stream.IntStream;
import java.util.stream.Stream;

public class Test {

	public static void main(String[] args) {
		
		Stream<Integer> s=Stream.of(3,5,7,2,1);

		s.map(a->a*a).forEach(System.out::println);
	}

}
