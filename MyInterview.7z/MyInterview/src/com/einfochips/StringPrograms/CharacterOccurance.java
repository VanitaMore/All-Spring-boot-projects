package com.einfochips.StringPrograms;

public class CharacterOccurance {

	public static void main(String[] args) {
		String dups = "aabbccacaaaccccdddaabbbccc";
		int lastIndexOf = dups.lastIndexOf("c");
		int startindex = dups.indexOf("c");

		String subs = dups.substring(startindex, lastIndexOf);
		System.out.println(startindex);

		char[] a = subs.toCharArray();
		for (int i = 0; i < a.length; i++) {
			int count = 0;
			for (int j = 0; j < a.length; j++) {
				if (j < i && a[i] == a[j]) {
					break;
				}

				if (a[i] == a[j]) {
					count++;

				}
				if (j == a.length - 1) {
					System.out.println(a[i] + "  " + count);
				}

			}

		}

	}
}