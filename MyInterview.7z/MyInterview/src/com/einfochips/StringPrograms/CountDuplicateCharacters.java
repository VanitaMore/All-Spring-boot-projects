package com.einfochips.StringPrograms;

import java.util.HashMap;
import java.util.Map;

public class CountDuplicateCharacters {

	 public static Map<Character, Integer> countDuplicateCharactersV1(String str) {

	      
	        Map<Character, Integer> result = new HashMap<>();                

	        // or use for(char ch: str.toCharArray()) { ... }
	        for (int i = 0; i < str.length(); i++) {
	            char ch = str.charAt(i);

	            result.compute(ch, (k, v) -> (v == null) ? 1 : ++v);
	        }

	        return result;
	        
	    }
	public static void main(String[] args) {
		String s="sqarweter";
		countDuplicateCharactersV1(s);

	}

}
