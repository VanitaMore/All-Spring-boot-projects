package com.einfochips.StringPrograms;

abstract class ExAbstract {


	int salary;
	String name;

	ExAbstract(int salary, String name) {
		this.salary = salary;
		this.name = name;
	}

	@Override
	public String toString() {
		return "ExAbstract [salary=" + salary + ", name=" + name + "]";
	}

}
