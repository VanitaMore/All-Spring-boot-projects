package com.einfochips.StringPrograms;

public class Temp extends ExAbstract {
	int rollno;

	

	Temp(int salary, String name, int rollno) {
		super(salary, name);
		this.rollno = rollno;
	}

	public static void main(String[] args) {
		Temp t = new Temp(22000,"vanita",5);
        System.out.println(t.name+" "+t.salary+" "+t.rollno);
	}
	@Override
	public String toString() {
		return "Temp [rollno=" + rollno + "]";
	}

}
