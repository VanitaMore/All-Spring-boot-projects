package com.einfochips.StringPrograms;

public class myTest {

	 static final int a;
}
