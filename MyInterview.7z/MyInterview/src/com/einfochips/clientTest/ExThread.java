package com.einfochips.clientTest;

class ExThread implements Runnable {
	@Override
	public void run() {
		System.out.println("run");
	}

	public static void main(String[] args) {

		ExThread x = new ExThread();
		Thread t = new Thread(x);
		t.start();

		System.out.println("main");
		t.run();
		System.out.println("main2");
	}

}
