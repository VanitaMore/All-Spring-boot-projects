package com.einfochips.clientTest;

import java.util.Comparator;

import com.einfochips.model.Person;

public class SortByIDComparator implements Comparator<Person> {

	@Override
	public int compare(Person p1, Person p2) {
		
		return p1.getId().compareTo(p2.getId());
	}

}
