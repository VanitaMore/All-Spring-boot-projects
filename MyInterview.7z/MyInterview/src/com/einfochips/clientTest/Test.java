package com.einfochips.clientTest;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import com.einfochips.model.Employee;
import com.einfochips.model.Person;

public class Test {

	public static void main(String[] args) {
		List<Employee> emp=new ArrayList<Employee>();
		emp.add(new Employee(4,"vanita",20000));
		emp.add(new Employee(1,"sonal",40000));
		emp.add(new Employee(3,"priya",60000));
		emp.add(new Employee(8,"deepa",80000));
		
		
		//emp.stream().map(String::toLowerCase).filter(x->x.startsWith("s")).sorted().collect(Collectors.toList()).forEach(System.out::println);
		
		
		/*
		 * for(Employee e:emp) { System.out.println(e); }
		 */
		
		
		Collections.sort(emp);
		//emp.forEach(System.out::println);
		
		List<Person> personList=new ArrayList<Person>();
		personList.add(new Person(5,"anita","abc"));
		personList.add(new Person(1,"john","pune"));
		personList.add(new Person(7,"gary","latyue"));
		personList.add(new Person(2,"amir","ausa"));
		Collections.sort(personList,new Comparator<Person>() {

			@Override
			public int compare(Person o1, Person o2) {
				
				return o1.getName().compareTo(o2.getName());
			}
		});
		//personList.forEach(System.out::println);
		Collections.sort(personList, new SortByIDComparator());
		personList.forEach(System.out::println);
	}

}
