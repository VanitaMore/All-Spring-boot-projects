package com.einfochips.examples;

import java.util.Optional;

public class DefaultMethodExample {

	 public static void main(String[] args) {
		
		 Optional<Integer> i=Optional.empty();
		 Optional<Integer> i2=Optional.of(2);
		// System.out.println(i.isPresent());
		 Optional<Integer> i3=Optional.ofNullable(6);
		 
		 Optional<Integer> possible = Optional.of(8);
		// possible.ifPresent(System.out::println);
		 possible.isPresent();
		// possible.ifPresent(System.out::print);
		 //possible.orElseThrow(IllegalAccessException);
		 
		 Integer val1=null;
		 Integer val2=new Integer(4);
		 
		 Optional<Integer> op1=Optional.ofNullable(val1);
		
		 Optional<Integer> op2=Optional.of(val2);
		System.out.println(sum(op1,op2)); 
	}

	private static Integer sum(Optional<Integer> a, Optional<Integer> b) {
		
	Integer val11=	a.orElse(new Integer(8));
	Integer val12=b.get();
	return val11+val12;
	
	}
}
