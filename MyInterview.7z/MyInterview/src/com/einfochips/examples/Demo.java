package com.einfochips.examples;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Demo {

	public static void main(String[] args) {
		
		/*
		 * ArrayList al =new ArrayList(); al.add(10); al.add("ratan"); al.add("anu");
		 * al.add('a'); al.add(10); al.add(null);
		 * System.out.println("ArrayList data="+al);
		 * System.out.println("ArrayList size-->"+al.size());
		 */
		  String[] str= new String[50]; 
		  str[0]="ratan"; 
		  str[1]="anu";
		 
		 // System.out.println(str[0]);
		 
		/*
		 * ArrayList a=new ArrayList(); a.add("abc"); a.add("vanu"); a.add(33);
		 */
		 //String s=(String) a.get(2);
		 
		 ArrayList a2=new ArrayList();
		 a2.add("aa");
		 List synchronizedList = Collections.synchronizedList(a2);
		 System.out.println(synchronizedList);
		 
		 List<String> al = new ArrayList<String>();
		 al.add("anu");
		 al.add("Sravya");
		 al.add("ratan");
		 al.add("natraj");
		 String[] a = new String[al.size()];
		 al.toArray(a);
		 //for-each loop to print the data
		 for (String s:a)
		 {System.out.println(s);
		 }
	}

}
