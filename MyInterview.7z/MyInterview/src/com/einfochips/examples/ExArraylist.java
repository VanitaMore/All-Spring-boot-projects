package com.einfochips.examples;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class ExArraylist {

	public static void main(String[] args) {
		List<String> al = new ArrayList<String>();
		al.add("anu");
		al.add("Sravya");
		al.add("ratan");
		al.add("natraj");
		
		ListIterator<String> s=al.listIterator();
		while(s.hasNext()) {
			if(s.next().equals("ratan")) {
				s.set("java");
				
			}


		}
		
		for(String ss:al) {
			System.out.println(ss);
		}
	}

}
