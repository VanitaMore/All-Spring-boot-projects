package com.einfochips.examples;

public class ExDaemaonThread extends Thread {

	void message(String str) {
		try {
			System.out.println("message=" + str);
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public void run() {
		if (Thread.currentThread().isDaemon()) {
			while (true) {
				System.out.println("print hi ratan");
				
			}
		}
	}

	public static void main(String[] args) {
		ExDaemaonThread t=new ExDaemaonThread();
		t.setDaemon(true);
		t.start();
		System.out.println("main thread completed");
	}
}
