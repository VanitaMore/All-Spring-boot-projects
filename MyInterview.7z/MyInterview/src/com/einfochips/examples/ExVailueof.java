package com.einfochips.examples;

public class ExVailueof {

	public static void main(String[] args) {
		int a=100;
		Integer s=Integer.valueOf(a);
		System.out.println(s);
	}

}
