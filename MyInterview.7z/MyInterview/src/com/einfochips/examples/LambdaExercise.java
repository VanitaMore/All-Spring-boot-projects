package com.einfochips.examples;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.sound.midi.SysexMessage;

public class LambdaExercise {

	public static void main(String[] args) {
		List<String> list=new ArrayList<String>();
		list.add("vanita");
		list.add("Sandeep");
		list.add("aanita");
		list.add("svDFGhine");
		list.add("pooja");
		list.add("survan");
		
		list.stream().sorted().collect(Collectors.toList()).forEach(System.out::println);;
	}

}
