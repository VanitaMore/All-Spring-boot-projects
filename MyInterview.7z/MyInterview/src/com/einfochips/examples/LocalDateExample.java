package com.einfochips.examples;

import java.time.LocalDate;

public class LocalDateExample {

	public static void main(String[] args) {
		LocalDate d=LocalDate.now();
		System.out.println(d);
	}

}
