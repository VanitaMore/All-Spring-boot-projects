package com.einfochips.examples;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class StreamExample {

	public static void main(String[] args) {
		//System.out.println(IntStream.range(1, 9).sum());
		
		//Stream.of("vanita","sandeep","chiku").sorted().findFirst().ifPresent(System.out::print);
		
		String[] s= {"sad","asds","dsfsg","rtret"};
		Arrays.stream(s)
		.filter(a->a.startsWith("d"))
		
		.forEach(System.out::println);
		
		List<String> list=new ArrayList<String>();
		list.add("vanita");
		list.add("Sandeep");
		list.add("aanita");
		list.add("svDFGhine");
		list.add("pooja");
		list.add("survan");
		
		//list.stream().map(String::toLowerCase).filter(a->a.startsWith("pooja")).forEach(System.out::print);
		list.forEach(System.out::println);
		Stream<Integer> i=Stream.of(10,2,4,6,7,9);
		i.sorted().forEach(System.out::print);
	}

}
