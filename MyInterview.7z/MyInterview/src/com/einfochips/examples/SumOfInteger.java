package com.einfochips.examples;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public class SumOfInteger {

	public static void main(String[] args) {
		List<Integer> list=new ArrayList<Integer>();
		list.add(4);
		list.add(3);
		list.add(11);
		list.add(34);
		
		int result=list.stream().filter(a->a>10).mapToInt(b->b).sum();
		System.out.println(result);
		Iterator<Integer> i=list.iterator();
		int sum=0;
		while(i.hasNext()) {
			int num=i.next();
			if(num>10) {
				sum=sum+num;
			}
		}
		//System.out.print(sum);
		
		String[] s= {"ss","trtyr","edgrt","ewqrw"};
		Arrays.stream(s).filter(a->a.startsWith("e")).forEach(System.out::print);
	}

}
