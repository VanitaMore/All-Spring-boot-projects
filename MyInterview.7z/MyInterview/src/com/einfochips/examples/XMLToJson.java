package com.einfochips.examples;

public class XMLToJson {

	public static void main(String[] args) {
		String xml_data = "<student><name>Neeraj Mishra</name><age>22</age></student>";
		 
		//converting xml to json
		JSONObject obj = XML.toJSONObject(xml_data);
		
		System.out.println(obj.toString());
	}

}
