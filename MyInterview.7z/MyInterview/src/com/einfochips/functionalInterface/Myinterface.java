package com.einfochips.functionalInterface;

@FunctionalInterface
public interface Myinterface {
	//public int m1(String s);

	public int square(int x);
	public default void m2() {
		System.out.println("xdcgdx");
	}

	public default void m3() {

	}

	public default void m4() {

	}

	public static void m5() {

	}
}
