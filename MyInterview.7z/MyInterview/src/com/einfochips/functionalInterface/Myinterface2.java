package com.einfochips.functionalInterface;
@FunctionalInterface
public interface Myinterface2 extends Myinterface {
	
	public void m1();

}
