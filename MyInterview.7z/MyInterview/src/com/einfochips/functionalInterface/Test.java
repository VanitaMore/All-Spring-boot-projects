package com.einfochips.functionalInterface;

public class Test{

	public static void main(String[] args) {
		
		Myinterface i=s-> s*s;
        System.out.println( i.square(9));
	}



}
