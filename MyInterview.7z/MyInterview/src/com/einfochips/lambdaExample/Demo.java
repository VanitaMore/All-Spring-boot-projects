package com.einfochips.lambdaExample;

import java.util.ArrayList;
import java.util.Arrays;

public class Demo {

	public static void main(String[] args) {
		ArrayList<Employee2> al=new ArrayList<Employee2>();
		al.add(new Employee2("cs", 1200, Arrays.asList(new Employee2("sfs", 44, ))));
		al.add(new EmployeeSalary(1, "abhi", 5));
		al.add(new EmployeeSalary(4, "sandi", 2));
		al.add(new EmployeeSalary(7, "piku", 88));
}
