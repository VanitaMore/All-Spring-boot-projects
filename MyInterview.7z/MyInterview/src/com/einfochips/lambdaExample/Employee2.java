package com.einfochips.lambdaExample;

import java.util.List;

public class Employee2 {

	public String department;
	public int salary;
	List<Employee> allEmployees;
	
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public List<Employee> getAllEmployees() {
		return allEmployees;
	}
	public void setAllEmployees(List<Employee> allEmployees) {
		this.allEmployees = allEmployees;
	}
	public Employee2(String department, int salary, List<Employee> allEmployees) {
		super();
		this.department = department;
		this.salary = salary;
		this.allEmployees = allEmployees;
	}
	@Override
	public String toString() {
		return "Employee2 [department=" + department + ", salary=" + salary + ", allEmployees=" + allEmployees + "]";
	}
	
	
}
