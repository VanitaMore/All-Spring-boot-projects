package com.einfochips.lambdaExample;

public class Greeter {
	
	public void greet(Greeting gt) {
		gt.perform();
	}

	public static void main(String[] args) {
		Greeting g=()->System.out.println("dfsdf");
		//g.perform();
		
		Greeting gg=new Greeting() {
			
			@Override
			public void perform() {
				System.out.println("annonymous");
			}
		};
		gg.perform();
	}

}
interface A{
	void show();
}