package com.einfochips.lambdaExample;

public interface Greeting {

	public void perform();
}
