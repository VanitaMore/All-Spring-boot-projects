package com.einfochips.lambdaExample;

public class HelloWorldGreeting implements Greeting {

	@Override
	public void perform() {
		System.out.println("hello world");
	}

}
