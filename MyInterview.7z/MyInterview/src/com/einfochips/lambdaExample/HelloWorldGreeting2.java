package com.einfochips.lambdaExample;

public class HelloWorldGreeting2 implements Greeting {

	@Override
	public void perform() {
		System.out.println("hello world 2");
	}

}
