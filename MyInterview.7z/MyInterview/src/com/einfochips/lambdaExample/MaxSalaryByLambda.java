package com.einfochips.lambdaExample;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.stream.Collectors;

public class MaxSalaryByLambda {

	public static void main(String[] args) {
		ArrayList<EmployeeSalary> al=new ArrayList<EmployeeSalary>();
		al.add(new EmployeeSalary(2, "vanu", 27));
		al.add(new EmployeeSalary(1, "abhi", 5));
		al.add(new EmployeeSalary(4, "sandi", 2));
		al.add(new EmployeeSalary(7, "piku", 88));
		
		/*
		 * for(EmployeeSalary e:al) { System.out.println(e); }
		 */
		
		//al.stream().forEach(System.out::print);
		
		Comparator<EmployeeSalary> c=Comparator.comparing(EmployeeSalary::getAge);
		EmployeeSalary	max=al.stream().max(c).get();
		EmployeeSalary	min=al.stream().min(c).get();
		
		//System.out.println("max salary is"+max);
		//System.out.println("min salary is"+min);
		
		 EmployeeSalary maxsalary=al.stream()
				 .collect(Collectors.maxBy(Comparator.comparingInt(EmployeeSalary::getAge)))
				 .get();
		 System.out.println("Total Employees Salary : " + maxsalary);
	}

}
