package com.einfochips.methodOverloading;
class SuperClass {
	   SuperClass get() {
	      System.out.println("SuperClass");
	      return this;
	   }
	}
public class CovariantExample extends SuperClass{

	CovariantExample get() {
	      System.out.println("SubClass");
	      return this;
	   }
	   public static void main(String[] args) {
		   CovariantExample tester = new CovariantExample();
	      tester.get();
	   }
}
