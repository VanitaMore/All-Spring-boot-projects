package com.einfochips.methodOverloading;

class Test {
	 void marry() {
		System.out.println("parent static method");
	}
}

class ExampleOne extends Test {

	 void marry() {
		System.out.println("child static method");
	}

	void sum(int a, int b) {
		System.out.println("int arguments method");
		System.out.println(a + b);
	}

	void sum(long a, long b) {
		System.out.println("long arguments method");
		System.out.println(a + b);
	}

	void sum(int a, long b) {
		System.out.println("int,long arguments method");
		System.out.println(a + b);
	}

	void sum(long a, int b) {
		System.out.println("long,int arguments method");
		System.out.println(a + b);
	}

	public static void main(String[] args) {
		Test t = new ExampleOne();
		/*
		 * t.sum(1, 2); t.sum(10L, 20L); t.sum(100, 200L); t.sum(1000L, 2000);
		 */
		t.marry();
	}

}
