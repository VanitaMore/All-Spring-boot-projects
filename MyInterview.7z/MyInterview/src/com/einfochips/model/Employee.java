package com.einfochips.model;

public class Employee implements Comparable<Employee>{
	
	private Integer id;
	private String name;
	private int salary;
	
	
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", salary=" + salary + "]";
	}
	public Employee() {
		super();
		
	}
	public Employee(int id, String name, int salary) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
	}
	@Override
	public int compareTo(Employee o) {

		return this.getName().compareTo(o.getName());
	}
	
	/*
	 * @Override public int compareTo(Employee e) {
	 * if(this.getSalary()>e.getSalary()) { return 1;
	 * }if(this.getSalary()<e.getSalary()) { return -1; } return 0; }
	 */
	

}
