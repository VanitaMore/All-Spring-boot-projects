package com.einfochips.model;

public class MyThread extends Thread{
	@Override
	public void run() {
		System.out.println("run");
	}
	public static void main(String[] args) {
		MyThread t1=new MyThread();
		MyThread t2=new MyThread();
		
		t1.start();
		System.out.println("t1");
		t2.start();
		System.out.println("t2");
	}

}
