package com.einfochips.programs;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.Vector;

public class ArrayToList {

	public static void main(String[] args) {
		/*
		 * String[] s= {"vanita","sandeep","abc","pqr"}; ArrayList<String> al=new
		 * ArrayList<String>(Arrays.asList(s)); al.add("asdsa"); al.add("fgdfh");
		 * for(String ss:al) { System.out.println(ss); }
		 */
		/*
		 * Vector v = new Vector(); System.out.println(v.capacity());
		 * System.out.println(v.size());
		 */
		Set<String> al = new HashSet<String>();
		System.out.println();
		al.add("anu");
		al.add(null);
		al.add("Sravya");
		al.add("ratan");
		al.add("natraj");
		al.add(null);
		
		Iterator<String> itr=al.iterator();
		while(itr.hasNext()) {
			String next = itr.next();
			System.out.println(next);
		}
	}

}
