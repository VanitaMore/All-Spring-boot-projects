package com.einfochips.programs;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Stream;

public class DistinctCharacter {

	public static void main(String[] args) {
		String s = "VSACHEDEHPTCNOJG";

		String myString = s.substring(4, 11);
		System.out.println(myString);
		Map<Character, Integer> map = new HashMap<Character, Integer>();
		char[] charArray = myString.toCharArray();
		for (Character c : charArray) {
			if (map.containsKey(c)) {
				map.put(c, map.get(c) + 1);
			} else {
				map.put(c, 1);
			}
		}

		System.out.println(map);
	}

}
