package com.einfochips.programs;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

public class ExHashMap {

	public static void main(String[] args) {
		

		Map<String, String> myMap = new ConcurrentHashMap<String, String>();
		myMap.put("1", "abc");
		myMap.put("2", "def");
		myMap.put("3", "xyz");

		myMap.keySet().stream().collect(Collectors.toList()).forEach(System.out::println);
		myMap.entrySet().stream().collect(Collectors.toList()).forEach(System.out::println);
		
		Set it1 = myMap.entrySet();
		Iterator itr=it1.iterator();
		while (itr.hasNext()) {
			Map.Entry key = (Map.Entry)itr.next();
			System.out.println("Map Value:" + key.getKey()+" "+key.getValue());
			
		}
		ArrayList<Entry> s=new ArrayList<Entry>(myMap.entrySet());
		for(Entry e:s) {
			System.out.println(e);
		}
		System.out.println(s);
		/*
		 * Iterator<String> it1 = myMap.keySet().iterator(); while (it1.hasNext()) {
		 * String key = it1.next(); System.out.println("Map Value:" + myMap.get(key));
		 * if (key.equals("2")) { myMap.put("vzv", "fdgs");
		 * 
		 * } } System.out.println(myMap);
		 */
	}

}
