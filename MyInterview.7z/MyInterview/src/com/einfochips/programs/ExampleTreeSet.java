package com.einfochips.programs;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

public class ExampleTreeSet {

	public static void main(String[] args) {
		/*
		 * TreeSet t=new TreeSet();
		 * 
		 * t.add(null); //java.lang.NullPointerException //System.out.println(t);
		 */
		
		HashMap h = new HashMap();
		h.put(111,"ratan");
		h.put(222,"anu");
		h.put(333,"banu");
		
		Set entrySet = h.entrySet();
		Iterator itr=entrySet.iterator();
		while(itr.hasNext()) {
			Map.Entry next = (Map.Entry)itr.next();
			System.out.println(next.getKey()+" "+next.getValue());
		}
		
	}

}
