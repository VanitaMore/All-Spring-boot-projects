package com.einfochips.programs;

import java.util.HashMap;
import java.util.Map;

public class NumberOfOccurances {

	public static void main(String[] args) {
		/*
		 * Map<Character, Integer> map = new HashMap<Character, Integer>();
		 * System.out.println("size is " + map.size()); map.put('a', 2); map.put('b',
		 * 5); System.out.println("b is " + map.get('b')); for (Map.Entry<Character,
		 * Integer> data : map.entrySet()) {
		 * System.out.println(data.getKey()+" "+data.getValue()); }
		 */
		
		
		/*
		 * if(map.keySet().contains('v')) { System.out.println("present");
		 * 
		 * }else { System.out.println("absent"); }
		 */
		HashMap<Character, Integer> map=new HashMap<Character, Integer>();
		String s="deafasfasf";
		
		for(Character c:s.toCharArray()) {
			if(map.containsKey(c)) {
				map.put(c,map.get(c)+1);
			}else {
				map.put(c, 1);
			}
		}

		System.out.println(map);
	}

}
