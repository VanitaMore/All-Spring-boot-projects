package com.einfochips.programs;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class SynchronizedArrayList {

	public static void main(String[] args) {
		ArrayList<Integer> al = new ArrayList<Integer>();
		al.add(5);
		al.add(5);
		List<Integer> synchronizedList = Collections.synchronizedList(al);
		System.out.println(synchronizedList.size());

	}

}
