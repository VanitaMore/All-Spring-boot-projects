package com.einfochips.programs;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class TestProgram {

	public static void main(String[] args) {
		String s="vanita lives in pune";
		String rev="";
		char[] charArray = s.toCharArray();
		Map<String, String> map=new HashMap<String, String>();
		int length=s.length();
	    String[] str=s.split("\\s");
		
		
		
		for(int i=str.length-1;i>=0;i--) {
			rev=rev+str[i]+" ";
		}
		System.out.println(rev);

	}

}
