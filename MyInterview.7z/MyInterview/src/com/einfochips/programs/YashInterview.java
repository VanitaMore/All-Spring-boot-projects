package com.einfochips.programs;

import java.util.HashMap;

public class YashInterview {

	public static void main(String[] args) {
		HashMap<String, Integer> map=new HashMap<String, Integer>();
		map.put("abs", 8);
		map.put("adas", 9);
		System.out.println(map.size());

	}

}
