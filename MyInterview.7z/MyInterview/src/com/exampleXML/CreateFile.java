package com.exampleXML;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class CreateFile {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		/*
		 * File file=new File("D://aa/doc.txt");
		 * 
		 * BufferedReader br = new BufferedReader(new FileReader(file));
		 * 
		 * String st; while ((st = br.readLine()) != null) System.out.println(st);
		 */ 
		  
		  
		  FileReader fr = new FileReader("D://aa/doc.txt"); 
			  
			    int i; 
			    while ((i=fr.read()) != -1) 
			      System.out.print((char) i); 
			    
			    
			    
		  
	}

}
