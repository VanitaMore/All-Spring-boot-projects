package com.exampleXML;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class ReadXMLFile {

	public static void main(String[] args) throws Exception {

		File fXmlFile = new File("D://TestXml/employees.xml");

		// Get Document Builder
		DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();

		// Build Document
		Document document = documentBuilder.parse(fXmlFile);

		// Normalize the XML Structure; It's just too important !!
		document.getDocumentElement().normalize();

		// Here comes the root node
		System.out.println("Root element :" + document.getDocumentElement().getNodeName());

		NodeList nList = document.getElementsByTagName("employee");

		for (int i = 0; i < nList.getLength(); i++) {
			Node node = nList.item(i);
			System.out.println(""); //Just a separator
			
			if (node.getNodeType() == Node.ELEMENT_NODE) {
				
				//Print each employee's detail
				Element element = (Element) node;
				System.out.println("Employee id:"  + element.getAttribute("id"));
				System.out.println("First Name" + element.getElementsByTagName("firstName").item(0).getTextContent());
				System.out.println("Last Name : " + element.getElementsByTagName("lastName").item(0).getTextContent());
				System.out.println("Location : " + element.getElementsByTagName("location").item(0).getTextContent());
			}
		}

	}

}
