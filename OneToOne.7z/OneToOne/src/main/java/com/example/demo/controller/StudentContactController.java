package com.example.demo.controller;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Student;
import com.example.demo.model.StudentContact;
import com.example.demo.model.Userlog;
import com.example.demo.repository.StudentContactRepository;

@RestController
@RequestMapping("/test")
public class StudentContactController {
	
	@Autowired StudentContactRepository repo;
	
	@GetMapping("/con")
	public List<StudentContact> all(){
		return repo.findAll();
		
	}

	@GetMapping("/bb/{name}")
	public List<StudentContact> update(@PathVariable String name){
		
		StudentContact con=new StudentContact();
		Userlog log=new Userlog();
		log.setLog("my log");
		
		Userlog log2=new Userlog();
		log2.setLog("my youtube");
		
		
		
		Student s=new Student();
		s.setName(name)
		.setAddress("pune")
		.setSalary(22)
		.setUserLog(Arrays.asList(log,log2));
		con.setPhNo(23243);
		con.setStudent(s);
		repo.save(con);
		return repo.findAll();
	
		
	}
}
