package com.example.demo.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;



@Entity
@Table(name="Student")
public class Student {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="id")
	private int id;
	private String name;
	private String address;
	private int salary;
	
	@OneToMany(mappedBy = "userId",cascade = CascadeType.ALL)
	private List<Userlog> userLog;
	
	public List<Userlog> getUserLog() {
		return userLog;
	}
	public Student setUserLog(List<Userlog> userLog) {
		this.userLog = userLog;
		return this;
	}
	public int getId() {
		return id;
	}
	public Student setId(int id) {
		this.id = id;
		return this;
	}
	public String getName() {
		return name;
	}
	public Student setName(String name) {
		this.name = name;
		return this;
	}
	public String getAddress() {
		return address;
	}
	public Student setAddress(String address) {
		this.address = address;
		return this;
	}
	public int getSalary() {
		return salary;
	}
	public Student setSalary(int salary) {
		this.salary = salary;
		return this;
	}
	
	
}
