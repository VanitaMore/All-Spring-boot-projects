package com.example.demo.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="StudentContact")
public class StudentContact {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="id")
	private int id;
	private int phNo;
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="stu_id",referencedColumnName = "id")
	private Student student;
	
	
	public StudentContact() {
		
	}
	public int getId() {
		return id;
	}
	public StudentContact setId(int id) {
		this.id = id;
		return this;
	}
	public int getPhNo() {
		return phNo;
	}
	public StudentContact setPhNo(int phNo) {
		this.phNo = phNo;
		return this;
	}
	public Student getStudent() {
		return student;
	}
	public StudentContact setStudent(Student student) {
		this.student = student;
		return this;
	}
	
	
}
