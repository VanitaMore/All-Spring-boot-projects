package com.example.demo.model;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class UserContact implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="userContactID")
	private Integer userContactID;
	private Integer phoneNo;
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="userContactID",referencedColumnName = "userId")
	private Users user;
	
	public Integer getUserContactID() {
		return userContactID;
	}
	public void setUserContactID(Integer userContactID) {
		this.userContactID = userContactID;
	}
	public Integer getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(Integer phoneNo) {
		this.phoneNo = phoneNo;
	}
	public Users getUser() {
		return user;
	}
	public void setUser(Users user) {
		this.user = user;
	}
	
	
	
}
