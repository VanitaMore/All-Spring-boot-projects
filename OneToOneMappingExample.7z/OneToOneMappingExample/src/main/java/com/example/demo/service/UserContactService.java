package com.example.demo.service;

import java.util.List;

import com.example.demo.model.UserContact;

public interface UserContactService {

	List<UserContact> getDetails();

	UserContact createContactData(UserContact userContact);

}
