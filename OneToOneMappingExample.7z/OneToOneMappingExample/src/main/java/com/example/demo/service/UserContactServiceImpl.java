package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.UserContact;
import com.example.demo.model.Users;
import com.example.demo.repository.UserContactRepository;

@Service
public class UserContactServiceImpl implements UserContactService {

	@Autowired
	UserContactRepository userContactRepository;
	
	 @Autowired UsersService usersService;

	@Override
	public List<UserContact> getDetails() {
       return userContactRepository.findAll();
	}

	@Override
	public UserContact createContactData(UserContact userContact) {
		Users user=userContact.getUser();
		usersService.createUsers(user);
		 userContactRepository.save(userContact);
		 return userContact;
	}

}
