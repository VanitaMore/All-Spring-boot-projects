package com.example.demo.service;

import com.example.demo.model.Users;

public interface UsersService {

	Users createUsers(Users user);

	

}
