package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SeluthClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(SeluthClientApplication.class, args);
	}

}
