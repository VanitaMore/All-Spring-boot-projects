package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication

public class SiteMasterServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SiteMasterServiceApplication.class, args);
	}

}
