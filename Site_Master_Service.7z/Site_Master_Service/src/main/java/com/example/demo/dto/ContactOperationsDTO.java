package com.example.demo.dto;

import java.util.List;



public class ContactOperationsDTO {

	 private List<ContactDTO> createContact;
	    private List<ContactDTO> deleteContact;
	    private List<ContactDTO> updateContact;
	    /**
	     * @return the createContact
	     */
	    public List<ContactDTO> getCreateContact() {
	        return createContact;
	    }
	    /**
	     * @param createContact the createContact to set
	     */
	    public void setCreateContact(List<ContactDTO> createContact) {
	        this.createContact = createContact;
	    }
	    /**
	     * @return the deleteContact
	     */
	    public List<ContactDTO> getDeleteContact() {
	        return deleteContact;
	    }
	    /**
	     * @param deleteContact the deleteContact to set
	     */
	    public void setDeleteContact(List<ContactDTO> deleteContact) {
	        this.deleteContact = deleteContact;
	    }
	    /**
	     * @return the updateContact
	     */
	    public List<ContactDTO> getUpdateContact() {
	        return updateContact;
	    }
	    /**
	     * @param updateContact the updateContact to set
	     */
	    public void setUpdateContact(List<ContactDTO> updateContact) {
	        this.updateContact = updateContact;
	    }
}
