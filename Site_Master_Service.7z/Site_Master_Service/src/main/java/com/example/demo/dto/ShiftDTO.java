package com.example.demo.dto;

import java.sql.Time;

public class ShiftDTO {

	    private String shiftId;
	    private String shiftName;
	    private Time startTime;
	    private Time endTime;
	    
		public String getShiftId() {
			return shiftId;
		}
		public void setShiftId(String shiftId) {
			this.shiftId = shiftId;
		}
		public String getShiftName() {
			return shiftName;
		}
		public void setShiftName(String shiftName) {
			this.shiftName = shiftName;
		}
		public Time getStartTime() {
			return startTime;
		}
		public void setStartTime(Time startTime) {
			this.startTime = startTime;
		}
		public Time getEndTime() {
			return endTime;
		}
		public void setEndTime(Time endTime) {
			this.endTime = endTime;
		}
		
	    
	    
}
