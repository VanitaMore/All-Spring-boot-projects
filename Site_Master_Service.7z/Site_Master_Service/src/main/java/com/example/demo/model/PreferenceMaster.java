package com.example.demo.model;

import java.io.Serializable;
import javax.persistence.*;

import org.hibernate.annotations.GenericGenerator;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.Date;

/**
 * The persistent class for the preference_master database table.
 * 
 */
@Entity
@Table(name = "preference_master")
//@NamedQuery(name="PreferenceMaster.findAll", query="SELECT p FROM PreferenceMaster p")
public class PreferenceMaster implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(generator = "system-uuid")
	@GenericGenerator(name = "system-uuid", strategy = "uuid")
	private String id;

	@Column(name = "alarm_counter")
	private Integer alarmCounter;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "alarm_first_date_time")
	private Date alarmFirstDateTime;

	@Column(name = "created_by")
	private String createdBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_date")
	private Date createdDate;

	private Byte email;

	@Column(name = "machine_id")
	private String machineId;

	@Column(name = "modified_by")
	private String modifiedBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "modified_date")
	private Date modifiedDate;

	

	private Byte sms;

	private Integer threshold;

	@Column(name = "threshold_refresh_Integererval")
	private String thresholdRefreshIntegererval;

	@Column(name = "unit_id")
	private String unitId;

	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "business_id")
	@JsonIgnore
	private BusinessMaster businessMaster;

	

	public PreferenceMaster() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Integer getAlarmCounter() {
		return this.alarmCounter;
	}

	public void setAlarmCounter(Integer alarmCounter) {
		this.alarmCounter = alarmCounter;
	}

	public Date getAlarmFirstDateTime() {
		return this.alarmFirstDateTime;
	}

	public void setAlarmFirstDateTime(Date alarmFirstDateTime) {
		this.alarmFirstDateTime = alarmFirstDateTime;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Byte getEmail() {
		return this.email;
	}

	public void setEmail(Byte email) {
		this.email = email;
	}

	public String getMachineId() {
		return this.machineId;
	}

	public void setMachineId(String machineId) {
		this.machineId = machineId;
	}

	public String getModifiedBy() {
		return this.modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	

	public Byte getSms() {
		return this.sms;
	}

	public void setSms(Byte sms) {
		this.sms = sms;
	}

	public Integer getThreshold() {
		return this.threshold;
	}

	public void setThreshold(Integer threshold) {
		this.threshold = threshold;
	}

	public String getThresholdRefreshIntegererval() {
		return this.thresholdRefreshIntegererval;
	}

	public void setThresholdRefreshIntegererval(String thresholdRefreshIntegererval) {
		this.thresholdRefreshIntegererval = thresholdRefreshIntegererval;
	}

	public String getUnitId() {
		return this.unitId;
	}

	public void setUnitId(String unitId) {
		this.unitId = unitId;
	}

	public BusinessMaster getBusinessMaster() {
		return businessMaster;
	}

	public void setBusinessMaster(BusinessMaster businessMaster) {
		this.businessMaster = businessMaster;
	}

	@Override
	public String toString() {
		return "PreferenceMaster [id=" + id + ", alarmCounter=" + alarmCounter + ", alarmFirstDateTime="
				+ alarmFirstDateTime + ", createdBy=" + createdBy + ", createdDate=" + createdDate + ", email=" + email
				+ ", machineId=" + machineId + ", modifiedBy=" + modifiedBy + ", modifiedDate=" + modifiedDate
				+ ", sms=" + sms + ", threshold=" + threshold + ", thresholdRefreshIntegererval="
				+ thresholdRefreshIntegererval + ", unitId=" + unitId + ", businessMaster=" + businessMaster + "]";
	}

	
	

}