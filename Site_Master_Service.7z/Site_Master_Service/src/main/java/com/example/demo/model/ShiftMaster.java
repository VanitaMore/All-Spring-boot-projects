package com.example.demo.model;


import java.io.Serializable;
import javax.persistence.*;

import org.hibernate.annotations.GenericGenerator;

import java.sql.Time;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * The persistent class for the shift_master database table.
 * 
 */
@Entity
@Table(name="shift_master")
//@NamedQuery(name="ShiftMaster.findAll", query="SELECT s FROM ShiftMaster s")
public class ShiftMaster implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="shift_id")
	@GeneratedValue(generator="system-uuid")
	@GenericGenerator(name="system-uuid", strategy = "uuid")
	private String shiftId;
	
	@Column(name="created_by")
	private String createdBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="created_date",nullable = true)
	private Date createdDate;

	@Column(name="end_time")
	private Time endTime;

	@Column(name="modified_by")
	private String modifiedBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="modified_date")
	private Date modifiedDate;

	

	@Column(name="shift_name")
	private String shiftName;

	@Column(name="start_time")
	private Time startTime;

	//bi-directional many-to-one association to SiteMaster
	//@ManyToOne(cascade = CascadeType.ALL)
	//@JoinColumn(name="site_id")
	
	@ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "site_id")
	@JsonIgnore
	private SiteMaster siteMaster;
	

	public ShiftMaster() {
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Time getEndTime() {
		return this.endTime;
	}

	public void setEndTime(Time endTime) {
		this.endTime = endTime;
	}

	public String getModifiedBy() {
		return this.modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return this.modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getShiftId() {
		return this.shiftId;
	}

	public void setShiftId(String shiftId) {
		this.shiftId = shiftId;
	}

	public String getShiftName() {
		return this.shiftName;
	}

	public void setShiftName(String shiftName) {
		this.shiftName = shiftName;
	}

	public Time getStartTime() {
		return this.startTime;
	}

	public void setStartTime(Time startTime) {
		this.startTime = startTime;
	}

	public SiteMaster getSiteMaster() {
		return siteMaster;
	}

	public void setSiteMaster(SiteMaster siteMaster) {
		this.siteMaster = siteMaster;
	}

	@Override
	public String toString() {
		return "ShiftMaster [shiftId=" + shiftId + ", createdBy=" + createdBy + ", createdDate=" + createdDate
				+ ", endTime=" + endTime + ", modifiedBy=" + modifiedBy + ", modifiedDate=" + modifiedDate
				+ ", shiftName=" + shiftName + ", startTime=" + startTime + ", siteMaster=" + siteMaster + "]";
	}

	
}