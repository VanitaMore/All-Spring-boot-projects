package com.example.demo.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.demo.model.BusinessMaster;
import com.example.demo.model.PreferenceMaster;

@Repository
public interface PreferenceMasterRepository extends JpaRepository<PreferenceMaster, String>{

	

	@Query(value="select distinct PM.alarm_id,PM.role_id,RM.user_role ,PM.sms, PM.email, PM.threshold,PM.threshold_refresh_Integererval,PM.alarm_counter,\r\n" + 
			"AM.alarm_type,AM.alarm_name,AM.description \r\n" + 
			"from hydro.preference_master PM \r\n" + 
			"left join hydro.alarm_master AM on AM.alarm_id= PM.alarm_id \r\n" + 
			"left join hydro.role_master RM on RM.role_id=PM.role_id where PM.business_id =? and site_id is null;",nativeQuery = true)
	
	PreferenceMaster getPreferenceMasterDetails(String businessId);

	

	PreferenceMaster findByBusinessMaster(BusinessMaster businessMaster);
}