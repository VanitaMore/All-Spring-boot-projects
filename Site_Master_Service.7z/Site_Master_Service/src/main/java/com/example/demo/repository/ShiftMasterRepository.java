package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.model.ShiftMaster;
import com.example.demo.model.SiteMaster;

@Repository
public interface ShiftMasterRepository extends JpaRepository<ShiftMaster, String>{

	List<ShiftMaster> findShiftMasterBySiteMaster(SiteMaster siteMaster);
}
