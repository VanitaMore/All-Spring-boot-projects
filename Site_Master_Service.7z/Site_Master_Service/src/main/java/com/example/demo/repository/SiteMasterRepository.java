package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;

import com.example.demo.dto.SiteDTO;
import com.example.demo.model.BusinessMaster;
import com.example.demo.model.PreferenceMaster;
import com.example.demo.model.ShiftMaster;
import com.example.demo.model.SiteMaster;

@Repository
public interface SiteMasterRepository extends JpaRepository<SiteMaster, String> {

	//SiteDTO saveAll(List<ShiftMaster> shiftMasters);
	
	//String CHECK_COMPANY_PREFERENCE_EXIST = "select business_id from preference_master where business_id=?";
	
// List<PreferenceMaster> findByBusinessMaster(BusinessMaster businessMaster);
}
