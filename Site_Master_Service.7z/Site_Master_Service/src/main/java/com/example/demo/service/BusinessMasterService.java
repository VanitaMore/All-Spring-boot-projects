package com.example.demo.service;

import com.example.demo.model.BusinessMaster;

public interface BusinessMasterService {

	BusinessMaster createBusinessMaster(BusinessMaster businessMaster);

}
