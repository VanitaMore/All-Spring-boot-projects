package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.BusinessMaster;
import com.example.demo.model.PreferenceMaster;
import com.example.demo.repository.BusinessMasterRepository;
import com.example.demo.repository.PreferenceMasterRepository;

@Service
public class BusinessMasterServiceImpl implements BusinessMasterService {

	@Autowired BusinessMasterRepository businessMasterRepository;
	
	@Autowired PreferenceMasterRepository preferenceMasterRepository;

	@Override
	public BusinessMaster createBusinessMaster(BusinessMaster businessMaster) {
		
		List<PreferenceMaster> prefaranceList=businessMaster.getPreferenceMasters();
		//businessMaster.setPreferenceMasters(new ArrayList<PreferenceMaster>());
		BusinessMaster businessMasterNew= businessMasterRepository.save(businessMaster);
		
		prefaranceList.forEach(preferenceMasterNew->{
			preferenceMasterNew.setBusinessMaster(businessMasterNew);
			preferenceMasterRepository.save(preferenceMasterNew);
		});
		
		return businessMasterRepository.getOne(businessMasterNew.getBusinessId());
	}
}
