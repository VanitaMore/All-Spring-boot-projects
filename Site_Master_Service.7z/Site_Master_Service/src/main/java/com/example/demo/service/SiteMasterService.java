package com.example.demo.service;

import java.util.List;

import com.example.demo.dto.SiteDTO;
import com.example.demo.model.SiteMaster;

public interface SiteMasterService {

	List<SiteMaster> getSiteMasterDetail();

	//SiteMaster createNewSite(SiteMaster siteMaster);

	void siteDelete(String siteID);

	SiteDTO createNewSite(SiteDTO siteDTO);

	SiteDTO siteUpdateData(String siteID, SiteDTO siteDTO);

	

}
