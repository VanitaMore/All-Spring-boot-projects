package com.example.demo.service;

import java.util.ArrayList;

import java.util.List;
import java.util.Objects;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.info.ProjectInfoProperties.Build;
import org.springframework.stereotype.Service;

import com.example.demo.dto.ContactDTO;
import com.example.demo.dto.ShiftDTO;
import com.example.demo.dto.SiteDTO;
import com.example.demo.model.BusinessMaster;
import com.example.demo.model.ContactMaster;
import com.example.demo.model.PreferenceMaster;
import com.example.demo.model.ShiftMaster;
import com.example.demo.model.SiteMaster;
import com.example.demo.repository.BusinessMasterRepository;
import com.example.demo.repository.ContactMasterRepository;
import com.example.demo.repository.PreferenceMasterRepository;
import com.example.demo.repository.ShiftMasterRepository;
import com.example.demo.repository.SiteMasterRepository;

@Service
public class SiteMasterServiceImpl implements SiteMasterService {

	@Autowired
	SiteMasterRepository siteMasterRepository;
	@Autowired
	ShiftMasterRepository shiftMasterRepository;
	@Autowired
	BusinessMasterRepository businessMasterRepository;

	@Autowired
	PreferenceMasterRepository preferenceMasterRepository;

	@Autowired
	ContactMasterRepository contactMasterRepository;

	@Override
	public SiteDTO createNewSite(SiteDTO siteDTO) {
		List<ShiftDTO> shiftDTO = siteDTO.getShiftList();
		List<ShiftMaster> shiftMasterList = new ArrayList<ShiftMaster>();

		for (ShiftDTO shift : shiftDTO) {
			ShiftMaster shiftMasterNew = new ShiftMaster();
			BeanUtils.copyProperties(shift, shiftMasterNew);
			shiftMasterList.add(shiftMasterNew);

		}

		List<ContactDTO> createContact = siteDTO.getContactOperations().getCreateContact();
		List<ContactMaster> contactList = new ArrayList<ContactMaster>();

		for (ContactDTO dto : createContact) {
			ContactMaster conMaster = new ContactMaster();
			BeanUtils.copyProperties(dto, conMaster);
			contactList.add(conMaster);
		}

		// siteMasterSetData(shiftMasterList,siteDTO,contactList);

		SiteMaster saveSiteMaster = siteMasterRepository.save(siteMasterSetData(shiftMasterList, siteDTO, contactList));
		
		BusinessMaster businessMaster=businessMasterRepository.getOne("1122");
		//System.out.println("business master data"+businessMaster);
		PreferenceMaster preferenceMaster=preferenceMasterRepository.findByBusinessMaster(businessMaster);
		//System.out.println(preferenceMaster);
		
		if(Objects.nonNull(preferenceMaster)) {
		PreferenceMaster preferenceMasterCreate = preferenceMasterRepository.getPreferenceMasterDetails(preferenceMaster.getBusinessMaster().getBusinessId());
		preferenceMasterRepository.save(preferenceMasterCreate);
		}
		System.out.println(saveSiteMaster.getSiteId());
		siteDTO.setSiteId(saveSiteMaster.getSiteId());
		return siteDTO;

	}

	private SiteMaster siteMasterSetData(List<ShiftMaster> shiftMasterList, SiteDTO siteDTO,List<ContactMaster> contactList) {
		SiteMaster siteMaster = new SiteMaster();
		siteMaster.setShiftMasters(shiftMasterList);
		siteMaster.setContactMaster(contactList);

		siteMaster.setSiteName(siteDTO.getSiteName());
		siteMaster.setAddress1(siteDTO.getAddress1());
		siteMaster.setAddress2(siteDTO.getAddress2());
		// siteMaster.setAlertSetting(siteDTO.getAlertSetting());
		siteMaster.setCountry(siteDTO.getCountry());
		siteMaster.setCity(siteDTO.getCity());
		siteMaster.setCreatedBy(siteDTO.getCreatedBy());
		// siteMaster.setZipcode(siteDTO.getZipcode());
		siteMaster.setDescription(siteDTO.getDescription());
		siteMaster.setMetricUnit(siteDTO.getMetricUnit());
		siteMaster.setState(siteDTO.getState());
		// siteMaster.setStreamingEnabled(siteDTO.getStreamingEnabled());
		siteMaster.setTimeZone(siteDTO.getTimeZone());
		// siteMaster.setTunnelEfficiencyThreshold(siteDTO.getTunnelEfficiencyThreshold());
		siteMaster.setTunnelIdleMinute(siteDTO.getTunnelIdleMinute());
		// siteMaster.setWasherEfficiencyThreshold(siteDTO.getWasherEfficiencyThreshold());
		siteMaster.setTunnelTurnMinute(siteDTO.getTunnelTurnMinute());
		siteMaster.setWasherTurnMinute(siteDTO.getWasherTurnMinute());
		return siteMaster;
	}

	@Override
	public List<SiteMaster> getSiteMasterDetail() {
		return siteMasterRepository.findAll();
	}

	@Override
	public void siteDelete(String siteID) {
		siteMasterRepository.deleteById(siteID);
	}

	@Override
	public SiteDTO siteUpdateData(String siteID, SiteDTO siteDTO) {
		// TODO Auto-generated method stub
		return null;
	}

}
