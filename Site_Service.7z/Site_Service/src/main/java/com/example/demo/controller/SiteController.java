package com.example.demo.controller;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.example.demo.model.SiteMaster;
import com.example.demo.service.SiteService;
import org.springframework.http.HttpMethod;

@RestController
@RequestMapping(value="/ss")
public class SiteController {
	private final Logger LOG = LoggerFactory.getLogger(SiteController.class);
	
	@Autowired  SiteService siteService;
	
	
	
	@GetMapping(value="/allSiteServiceDetail")
	public List<SiteMaster> getAllData(){
		return siteService.getAllData();
	}
	
	@GetMapping(value="/siteServiceDetailById/{site_id}")
	public Optional<SiteMaster> getSiteMasterById(@PathVariable(value="site_id") String site_id) {
		return siteService.getSiteMasterById(site_id);
	}
	

}
