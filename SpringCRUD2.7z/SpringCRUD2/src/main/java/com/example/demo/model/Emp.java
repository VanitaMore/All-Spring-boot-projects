package com.example.demo.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedNativeQuery;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "Employee")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor

/*
 * @NamedNativeQuery(name = "Emp.getEmployeeByEmpName", query =
 * "SELECT * FROM Employee WHERE emp_name=?1",resultClass = Emp.class)
 */
public class Emp implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int empId;
	private String empName;
	private String empAddr;
	private String empCity;

	@Override
	public String toString() {
		return "Emp [empId=" + empId + ", empName=" + empName + ", empAddr=" + empAddr + ", empCity=" + empCity + "]";
	}

}
