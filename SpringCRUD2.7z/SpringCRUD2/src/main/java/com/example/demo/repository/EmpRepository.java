package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.model.Emp;

@Repository
public interface EmpRepository extends CrudRepository<Emp, Integer> {

	@Query(value = "SELECT e FROM Emp e WHERE e.empName=?1")
	List<Emp> getEmployeeByEmpName(String name);
	
	List<Emp> findByempNameAndEmpCity(String name,String city);

	/*
	 * @Query("select e from Employee e where e.name like %?1") List<Emp>
	 * findByEmpNameEndsWith(String chars);
	 */
}
