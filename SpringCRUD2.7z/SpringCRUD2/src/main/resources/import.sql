
INSERT INTO ticket(passenger_name,booking_date,source_station,dest_station,email) VALUES('Sean','2017/07/14','Patna','Delhi','sean.s2017@yahoo.com');