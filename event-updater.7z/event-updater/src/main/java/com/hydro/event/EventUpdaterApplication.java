package com.hydro.event;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import com.hydro.event.service.EventerService;




@SpringBootApplication
public class EventUpdaterApplication {

	Logger log = LoggerFactory.getLogger(EventUpdaterApplication.class);

	public static void main(String[] args) throws Exception {

		ApplicationContext ctx = SpringApplication.run(EventUpdaterApplication.class, args);

		EventerService eService = ctx.getBean(EventerService.class);

		eService.updateEvent();
	}


}
