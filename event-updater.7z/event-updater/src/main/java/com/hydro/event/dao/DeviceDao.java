package com.hydro.event.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.hydro.event.model.Equipment;



@Repository
public class DeviceDao {

	Logger log = LoggerFactory.getLogger(DeviceDao.class);
	@Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	public List<Equipment> getEquipmentDetalis(List<String> fileIdList) {

		final String FETCH_EQUIPMENTDTL_BY_FILEIDS = "select * from equipment_master where file_id in (:fileIds) ";
		
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("fileIds", fileIdList);
		
		log.info("FETCH_EQUIPMENTDTL_BY_FILEIDS {} " , fileIdList);
		
		List<Equipment> equipmentList = (List<Equipment>) namedParameterJdbcTemplate.query(FETCH_EQUIPMENTDTL_BY_FILEIDS, parameters, new EquipmentMapper());
		return equipmentList;
	}

	public String getSiteId(String siteName) {

		final String CONFIG_GET_SITE_ID = "select site_id from site_master where site_Name= :siteName ";
		
		String siteId = null;
		Map<String, String> parameters = new HashMap<String, String>();
		parameters.put("siteName", siteName);

		siteId = (String) namedParameterJdbcTemplate.queryForObject(CONFIG_GET_SITE_ID, parameters, String.class);
		return siteId;

	}

	public List<String> getSiteIds() {
		final String CONFIG_GET_SITE_ID = "select site_id from site_master";

		return namedParameterJdbcTemplate.query(CONFIG_GET_SITE_ID, new RowMapper<String>() {

			@Override
			public String mapRow(ResultSet rs, int rowNum) throws SQLException {

				return rs.getString("site_id");
			}

		});

	}

	public List<String> getFileIds(String siteId) {
		final String CONFIG_GET_SITE_ID = "select file_id from file_master where site_id = :siteId and is_active=1 ";

		Map<String, String> parameters = new HashMap<String, String>();
		parameters.put("siteId", siteId);
		return namedParameterJdbcTemplate.query(CONFIG_GET_SITE_ID, parameters, new RowMapper<String>() {

			@Override
			public String mapRow(ResultSet rs, int rowNum) throws SQLException {

				return rs.getString("file_id");
			}

		});

	}

	public String getDeviceId(String eventSiteId, String eventLm2Sequence, String ipAddress) {
		
		final String CONFIG_GET_DEVICE_ID = "select device_id from equipment_master where site_id =:siteId  and lm2_seq=:lm2seq and ip_address =:ipAddress";
		String deviceId = null;
		
		Map<String, String> parameters = new HashMap<String, String>();
		parameters.put("siteId", eventSiteId);
		parameters.put("lm2seq", eventLm2Sequence);
		parameters.put("ipAddress", ipAddress);

		deviceId = (String) namedParameterJdbcTemplate.queryForObject(CONFIG_GET_DEVICE_ID, parameters, String.class);
		return deviceId;
	}
}

class EquipmentMapper implements RowMapper<Equipment> {

	@Override
	public Equipment mapRow(ResultSet rs, int rowNum) throws SQLException {
		Equipment equipment = new Equipment();
		equipment.setEquipmentId(rs.getString("equipment_id"));
		equipment.setIpAddress(rs.getString("ip_address"));
		equipment.setSiteId(rs.getString("site_id"));
		equipment.setLm2Seq(rs.getInt("lm2_seq"));
		equipment.setEquipmentType(rs.getString("equipment_type"));
		equipment.setDeviceId(rs.getString("device_id"));
		return equipment;
	}

}
