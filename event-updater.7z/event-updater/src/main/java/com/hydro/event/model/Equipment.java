package com.hydro.event.model;

import java.io.Serializable;



public class Equipment implements  Serializable{
	
	private String equipmentId;
    private Integer lm2Seq;
    private String siteId;
    private String ipAddress;
    private String equipmentType;
    private String deviceId;
    
	public String getEquipmentId() {
		return equipmentId;
	}
	public void setEquipmentId(String equipmentId) {
		this.equipmentId = equipmentId;
	}
	public Integer getLm2Seq() {
		return lm2Seq;
	}
	public void setLm2Seq(Integer lm2Seq) {
		this.lm2Seq = lm2Seq;
	}
	public String getSiteId() {
		return siteId;
	}
	public void setSiteId(String siteId) {
		this.siteId = siteId;
	}
	public String getIpAddress() {
		return ipAddress;
	}
	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}
	public String getEquipmentType() {
		return equipmentType;
	}
	public void setEquipmentType(String equipmentType) {
		this.equipmentType = equipmentType;
	}
	public String getDeviceId() {
		return deviceId;
	}
	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}
	
	@Override
	public String toString() {
		return "Equipment [equipmentId=" + equipmentId + ", lm2Seq=" + lm2Seq + ", siteId=" + siteId + ", ipAddress="
				+ ipAddress + ", equipmentType=" + equipmentType + ", deviceId=" + deviceId + "]";
	}
    
    
    
}
