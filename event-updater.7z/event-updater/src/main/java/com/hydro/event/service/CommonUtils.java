package com.hydro.event.service;
import java.io.IOException;

import org.apache.commons.codec.binary.Base64;
import org.apache.http.Header;
import org.apache.http.HttpHost;
import org.apache.http.message.BasicHeader;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.RestHighLevelClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import io.searchbox.client.JestClient;
import io.searchbox.client.JestClientFactory;
import io.searchbox.client.JestResult;
import io.searchbox.client.config.HttpClientConfig;
import io.searchbox.core.Search;
import io.searchbox.core.SearchResult;
import io.searchbox.core.SearchScroll;
import io.searchbox.params.Parameters;

public class CommonUtils {

	JestClientFactory factory = new JestClientFactory();
	String username = "elastic";
	String password = "#Welcome@123";
	String hostValue = "52.171.214.22";
	int port = 9200;

	String basicAuth = new Base64().encodeAsString(new String(username + ":" + password).getBytes());
	Header[] headers = { new BasicHeader("Authorization", "Basic " + basicAuth) };
	HttpHost host = new HttpHost(hostValue, port);
	RestHighLevelClient client = new RestHighLevelClient(
			RestClient.builder(host).setDefaultHeaders(headers).setMaxRetryTimeoutMillis(9000000));

	public CommonUtils() throws Exception {
		init();
	}

	JestClient jestClient;

	private void init() throws Exception {
		JestClientFactory factory = new JestClientFactory();
		factory.setHttpClientConfig(new HttpClientConfig.Builder("http://" + hostValue + ":" + port).multiThreaded(true)
				.connTimeout(30000).readTimeout(500000).defaultCredentials(username, password).build());
		jestClient = factory.getObject();
	}

	public SearchResult startScrollSearch(String type, String query) throws IOException {
		Search search = new Search.Builder(query).addType(type).setParameter(Parameters.SIZE, 5000)
				.setParameter(Parameters.SCROLL, "5m").build();
		SearchResult searchResult = jestClient.execute(search);
		return searchResult;
	}

	public JestResult readMoreFromSearch(String scrollId) throws IOException {
		SearchScroll scroll = new SearchScroll.Builder(scrollId, "5m").build();
		JestResult searchResult = jestClient.execute(scroll);
		return searchResult;
	}

	public void jestClientClose() {
		try {
			jestClient.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void restClientClose() {
		try {
			client.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public RestHighLevelClient client() {
		return client;

	}
}
