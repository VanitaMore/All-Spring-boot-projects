package com.hydro.event.service;

import java.io.FileReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;


import org.elasticsearch.action.bulk.BulkRequest;
import org.elasticsearch.action.bulk.BulkResponse;
import org.elasticsearch.action.update.UpdateRequest;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestTemplate;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.hydro.event.dao.DeviceDao;
import com.hydro.event.model.Equipment;

import io.searchbox.client.JestResult;
import io.searchbox.core.SearchResult;

@Service
public class EventerService {

	private DeviceDao deviceDao;



	@Value("${device.management.host}")
	private String deviceManagementHost;

	@Value("${advance.device.search}")
	private String advanceDeviceSearch;
	
	
	@Value("${site.ids}") 
	private String[] sites;
	
	@Value("${spring.profiles.active}")
	private String activeProfile;
	
	@Value("${elasticsearch.username}")
	private String esusername;
	
	@Value("${elasticsearch.password}")
	private String espassword;
	
	@Value("${elasticsearch.hostValue}")
	private String eshostValue;
	
	@Value("${elasticsearch.port}")
	private String esport;

	Logger log = LoggerFactory.getLogger(EventerService.class);

	@Autowired
	public EventerService(DeviceDao deviceDao) {
		this.deviceDao = deviceDao;
	
	}

	public void updateEvent() throws Exception {
		List<String> siteList = null;
		
		if("uat".equalsIgnoreCase(activeProfile)) {
			 siteList = deviceDao.getSiteIds();
		
		}else {
			siteList = new ArrayList<String>(Arrays.asList(sites));
		}


		CommonUtils comm = new CommonUtils();
		for (String siteId : siteList) {

			List<String> fileIdList = new ArrayList<String>();
			fileIdList = deviceDao.getFileIds(siteId);
			List<Equipment> equipmentList = deviceDao.getEquipmentDetalis(fileIdList);
			BulkRequest request = new BulkRequest();

			if (!CollectionUtils.isEmpty(equipmentList)) {

				boolean executeBulkRequest = false;

				for (Equipment equipment : equipmentList) {
					log.info("equipment{}",equipment);
					// getEvents for siteid
					List<JsonObject> eventList = getEventsForSite(equipment.getSiteId(), equipment.getEquipmentType(),
							comm);
					int eventCounter = eventList.size();
					log.info("total events for site {} with EquipmentType{} is {}", siteId,
							equipment.getEquipmentType(), eventList.size());

					for (JsonObject event : eventList) {
						log.info("event" + event);
						 
						String deviceId =equipment.getDeviceId();
						
						/*
						  if(StringUtils.isEmpty(deviceId)) { 
						  deviceId =getDeviceId(siteId,equipment.getIpAddress());
						   }
						 */
						
						if (!StringUtils.isEmpty(deviceId)) {
							executeBulkRequest = true;
							request.add(createUpdateRequest(event, deviceId));
						}
						eventCounter--;
						log.info("total events remainning{} for site{} with EquipmentType{}", eventCounter, siteId,
								equipment.getEquipmentType());
					}
				}
				if (executeBulkRequest) {
					BulkResponse bulkResponse = comm.client().bulk(request);
					log.info("Total events updated::{} for site::" + request.numberOfActions(), siteId);
					
					if (bulkResponse.hasFailures()) {
						log.info("Has Failure on site::{}", siteId);
					} else {
						log.info("Successfully updated events data for site:: {}", siteId);
					}
				} else {
					log.info("No device found for site:: {}", siteId);
				}
			}

		}
	}

	

	



	public UpdateRequest createUpdateRequest(JsonObject event, String deviceId) {
		String index = event.get("_index").getAsString();
		String type = event.get("_type").getAsString();
		String id = event.get("_id").getAsString();
		return new UpdateRequest(index, type, id).doc("device_id", deviceId.trim());
	}

	private List<JsonObject> getEventsForSite(String siteId, String equipmentType, CommonUtils comm) throws Exception {
		JsonParser parser = new JsonParser();
		Object object = parser.parse(new FileReader("src/main/resources/UpdateMDBEvents.json"));
		JsonObject jobject = (JsonObject) object;
		String scrollId;
		String query = jobject.toString();
		List<JsonObject> eventList = new ArrayList<JsonObject>();
		JsonArray hitsArray;
		query = query.replace("SITE_ID_VAL", siteId);
		query = query.replace("EQUIPMENT_TYPE_VAL", equipmentType);
		log.info("Query::" + query);
		SearchResult responseObject = comm.startScrollSearch("hydro-events", query);

		scrollId = responseObject.getJsonObject().get("_scroll_id").getAsString();
		log.info("scrollId::" + scrollId);
		hitsArray = responseObject.getJsonObject().get("hits").getAsJsonObject().get("hits").getAsJsonArray();
		// Processing data obtained from scroll result.
		for (int i = 0; i < hitsArray.size(); i++) {
			JsonObject event = hitsArray.get(i).getAsJsonObject();
			eventList.add(event);
		}

		JestResult scrollResult;
		do {
			System.out.println("inside do-while block");
			scrollResult = comm.readMoreFromSearch(scrollId);
			scrollId = scrollResult.getJsonObject().get("_scroll_id").getAsString();
			System.out.println("scroll result::" + scrollResult.getJsonObject());
			hitsArray = scrollResult.getJsonObject().get("hits").getAsJsonObject().get("hits").getAsJsonArray();
			for (int i = 0; i < hitsArray.size(); i++) {
				JsonObject event = hitsArray.get(i).getAsJsonObject();
				System.out.println("event::" + event);
				eventList.add(event);
			}
		} while (hitsArray.size() > 0);

		return eventList;
	}

	

	
}
