package com.dover.hydro.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dover.hydro.tunnel.entites.EstadisticaTunnel;
import com.dover.hydro.tunnel.repositories.TunnelRepository;
import com.dover.hydro.washer.entites.Estadistica;
import com.dover.hydro.washer.repositories.WasherRepository;

@Service
public class EventService {

    @Autowired
    private WasherRepository washerRepository;

    @Autowired
    private TunnelRepository tunnelRepository;

    public List<Estadistica> findAll() {
	List<Estadistica> aaa = washerRepository.findAll();
	for (Estadistica aa : aaa) {
	    System.out.println(aa);
	}
	return aaa;
    }

    public List<EstadisticaTunnel> findTunnelEvents() {
	List<EstadisticaTunnel> aaa = tunnelRepository.findAll();

	return aaa;
    }

    public List<Estadistica> findWasherByDate(String startDate, String endDate) throws ParseException {
	List<Estadistica> washerEvents = washerRepository.getAllBetweenEventDates(
		new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(startDate),
		new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(endDate));

	return washerEvents;
    }

    public List<EstadisticaTunnel> findTunnelEventsByDate(String startDate, String endDate) throws ParseException {
	List<EstadisticaTunnel> tunnelEvents = tunnelRepository.getAllBetweenEventDates(
		new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(startDate),
		new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(endDate));
	for (EstadisticaTunnel aa : tunnelEvents) {
	    System.out.println(aa);
	}
	return tunnelEvents;
    }

    public List<EstadisticaTunnel> findTunnelEventsSentStatus(String status) {
	List<EstadisticaTunnel> tunnelEvents = new ArrayList<EstadisticaTunnel>();
	if ("OK".equalsIgnoreCase(status)) {
	    tunnelEvents = tunnelRepository.findByModSendStatus(status);
	} else {
	    tunnelEvents = tunnelRepository.findByModSendStatusIsNull();
	}
	return tunnelEvents;
    }

    public List<Estadistica> getWasherEventsSentStatus(String status) {
	List<Estadistica> washerEvents = new ArrayList<Estadistica>();
	if ("OK".equalsIgnoreCase(status)) {
	    washerEvents = washerRepository.findByModSendStatus(status);
	} else {
	    washerEvents = washerRepository.findByModSendStatusIsNull();
	}
	return washerEvents;
    }
//
//    public List<EstadisticaTunnel> findTunnelEventsByDateAndStatus(String startDate, String endDate, String status)
//	    throws ParseException {
//	List<EstadisticaTunnel> tunnelEvents = tunnelRepository.getAllByStatusAndBetweenEventDates(status,
//		new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(startDate),
//		new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(endDate));
//	return tunnelEvents;
//    }
}
