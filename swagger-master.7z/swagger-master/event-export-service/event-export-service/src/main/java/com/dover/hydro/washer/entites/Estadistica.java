package com.dover.hydro.washer.entites;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * The persistent class for the estadisticas database table.
 * 
 */

@Entity
@Table(name = "estadisticas")
//@NamedQuery(name = "Estadistica.findAll", query = "SELECT e FROM Estadistica e")
public class Estadistica implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    private String id;

    private int alarm;

    private int channel;

    @Column(name = "cost_estimated")
    private BigDecimal costEstimated;

    @Column(name = "cost_informula")
    private BigDecimal costInformula;

    @Column(name = "cost_real")
    private BigDecimal costReal;

    private int customer;

    private int cycle;

    private BigDecimal dose;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "event_date")
    private Date eventDate;

    @Column(name = "event_type")
    private int eventType;

    @Column(name = "formula_cost")
    private BigDecimal formulaCost;

    @Column(name = "formula_id")
    private int formulaId;

    @Column(name = "formula_name")
    private String formulaName;

    @Column(name = "formula_phases")
    private int formulaPhases;

    @Column(name = "gr_informula")
    private int grInformula;

    @Column(name = "gr_real")
    private int grReal;

    private int info;

    @Column(name = "laundry_id")
    private BigInteger laundryId;

    @Column(name = "ml_estimated")
    private int mlEstimated;

    @Column(name = "ml_real")
    private int mlReal;

    @Column(name = "mod_send_status")
    private String modSendStatus;

    private int phase;

    @Column(name = "product_id")
    private int productId;

    @Column(name = "product_name")
    private String productName;

    @Column(name = "product_price")
    private BigDecimal productPrice;

    @Column(name = "real_kg")
    private int realKg;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "send_date")
    private Date sendDate;

    @Column(name = "time_estimated")
    private BigDecimal timeEstimated;

    @Column(name = "time_real")
    private BigDecimal timeReal;

    @Column(name = "unit_id")
    private BigInteger unitId;

    @Column(name = "washerextractor_id")
    private int washerextractorId;

    @Column(name = "washerextractor_kg")
    private int washerextractorKg;

    @Column(name = "washerextractor_name")
    private String washerextractorName;

    public Estadistica() {
    }

    public String getId() {
	return id;
    }

    public void setId(String id) {
	this.id = id;
    }

    public int getAlarm() {
	return alarm;
    }

    public void setAlarm(int alarm) {
	this.alarm = alarm;
    }

    public int getChannel() {
	return channel;
    }

    public void setChannel(int channel) {
	this.channel = channel;
    }

    public BigDecimal getCostEstimated() {
	return costEstimated;
    }

    public void setCostEstimated(BigDecimal costEstimated) {
	this.costEstimated = costEstimated;
    }

    public BigDecimal getCostInformula() {
	return costInformula;
    }

    public void setCostInformula(BigDecimal costInformula) {
	this.costInformula = costInformula;
    }

    public BigDecimal getCostReal() {
	return costReal;
    }

    public void setCostReal(BigDecimal costReal) {
	this.costReal = costReal;
    }

    public int getCustomer() {
	return customer;
    }

    public void setCustomer(int customer) {
	this.customer = customer;
    }

    public int getCycle() {
	return cycle;
    }

    public void setCycle(int cycle) {
	this.cycle = cycle;
    }

    public BigDecimal getDose() {
	return dose;
    }

    public void setDose(BigDecimal dose) {
	this.dose = dose;
    }

    public Date getEventDate() {
	return eventDate;
    }

    public void setEventDate(Date eventDate) {
	this.eventDate = eventDate;
    }

    public int getEventType() {
	return eventType;
    }

    public void setEventType(int eventType) {
	this.eventType = eventType;
    }

    public BigDecimal getFormulaCost() {
	return formulaCost;
    }

    public void setFormulaCost(BigDecimal formulaCost) {
	this.formulaCost = formulaCost;
    }

    public int getFormulaId() {
	return formulaId;
    }

    public void setFormulaId(int formulaId) {
	this.formulaId = formulaId;
    }

    public String getFormulaName() {
	return formulaName;
    }

    public void setFormulaName(String formulaName) {
	this.formulaName = formulaName;
    }

    public int getFormulaPhases() {
	return formulaPhases;
    }

    public void setFormulaPhases(int formulaPhases) {
	this.formulaPhases = formulaPhases;
    }

    public int getGrInformula() {
	return grInformula;
    }

    public void setGrInformula(int grInformula) {
	this.grInformula = grInformula;
    }

    public int getGrReal() {
	return grReal;
    }

    public void setGrReal(int grReal) {
	this.grReal = grReal;
    }

    public int getInfo() {
	return info;
    }

    public void setInfo(int info) {
	this.info = info;
    }

    public BigInteger getLaundryId() {
	return laundryId;
    }

    public void setLaundryId(BigInteger laundryId) {
	this.laundryId = laundryId;
    }

    public int getMlEstimated() {
	return mlEstimated;
    }

    public void setMlEstimated(int mlEstimated) {
	this.mlEstimated = mlEstimated;
    }

    public int getMlReal() {
	return mlReal;
    }

    public void setMlReal(int mlReal) {
	this.mlReal = mlReal;
    }

    public String getModSendStatus() {
	return modSendStatus;
    }

    public void setModSendStatus(String modSendStatus) {
	this.modSendStatus = modSendStatus;
    }

    public int getPhase() {
	return phase;
    }

    public void setPhase(int phase) {
	this.phase = phase;
    }

    public int getProductId() {
	return productId;
    }

    public void setProductId(int productId) {
	this.productId = productId;
    }

    public String getProductName() {
	return productName;
    }

    public void setProductName(String productName) {
	this.productName = productName;
    }

    public BigDecimal getProductPrice() {
	return productPrice;
    }

    public void setProductPrice(BigDecimal productPrice) {
	this.productPrice = productPrice;
    }

    public int getRealKg() {
	return realKg;
    }

    public void setRealKg(int realKg) {
	this.realKg = realKg;
    }

    public Date getSendDate() {
	return sendDate;
    }

    public void setSendDate(Date sendDate) {
	this.sendDate = sendDate;
    }

    public BigDecimal getTimeEstimated() {
	return timeEstimated;
    }

    public void setTimeEstimated(BigDecimal timeEstimated) {
	this.timeEstimated = timeEstimated;
    }

    public BigDecimal getTimeReal() {
	return timeReal;
    }

    public void setTimeReal(BigDecimal timeReal) {
	this.timeReal = timeReal;
    }

    public BigInteger getUnitId() {
	return unitId;
    }

    public void setUnitId(BigInteger unitId) {
	this.unitId = unitId;
    }

    public int getWasherextractorId() {
	return washerextractorId;
    }

    public void setWasherextractorId(int washerextractorId) {
	this.washerextractorId = washerextractorId;
    }

    public int getWasherextractorKg() {
	return washerextractorKg;
    }

    public void setWasherextractorKg(int washerextractorKg) {
	this.washerextractorKg = washerextractorKg;
    }

    public String getWasherextractorName() {
	return washerextractorName;
    }

    public void setWasherextractorName(String washerextractorName) {
	this.washerextractorName = washerextractorName;
    }

    public static long getSerialversionuid() {
	return serialVersionUID;
    }

    @Override
    public String toString() {
	return "Estadistica [id=" + id + ", alarm=" + alarm + ", channel=" + channel + ", costEstimated="
		+ costEstimated + ", costInformula=" + costInformula + ", costReal=" + costReal + ", customer="
		+ customer + ", cycle=" + cycle + ", dose=" + dose + ", eventDate=" + eventDate + ", eventType="
		+ eventType + ", formulaCost=" + formulaCost + ", formulaId=" + formulaId + ", formulaName="
		+ formulaName + ", formulaPhases=" + formulaPhases + ", grInformula=" + grInformula + ", grReal="
		+ grReal + ", info=" + info + ", laundryId=" + laundryId + ", mlEstimated=" + mlEstimated + ", mlReal="
		+ mlReal + ", modSendStatus=" + modSendStatus + ", phase=" + phase + ", productId=" + productId
		+ ", productName=" + productName + ", productPrice=" + productPrice + ", realKg=" + realKg
		+ ", sendDate=" + sendDate + ", timeEstimated=" + timeEstimated + ", timeReal=" + timeReal + ", unitId="
		+ unitId + ", washerextractorId=" + washerextractorId + ", washerextractorKg=" + washerextractorKg
		+ ", washerextractorName=" + washerextractorName + "]";
    }

}